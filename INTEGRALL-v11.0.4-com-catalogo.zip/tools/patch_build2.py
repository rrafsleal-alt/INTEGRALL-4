import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# --- 1) corrige nomes colados pelo OCR do cafe ("CafeDarosi" -> "Café da Rosi")
old = '''        name = titleize(re.sub(r"\\bDa\\b", "da", re.sub(r"\\bDo\\b", "do", name), flags=re.I)) \\
            .replace("Irmao", "Irmão").replace("Rosie", "Rosi")'''
new = '''        name = re.sub(r"(?i)^cafe\\s*(da|do|das|dos)(?=[A-ZÀ-Ú])", r"cafe \\1 ", name)
        name = re.sub(r"(?i)\\bdarosi\\b", "da Rosi", name)
        name = titleize(re.sub(r"\\bDa\\b", "da", re.sub(r"\\bDo\\b", "do", name), flags=re.I)) \\
            .replace("Irmao", "Irmão")'''
assert old in s, "padrao de nome do cafe nao encontrado"
s = s.replace(old, new)

# --- 2) devolve o parser de importados
IMPORT = '''
# ============================================== IMPORTADOS (codigo na imagem)
def parse_importados():
    """Um produto por "CÓD nnn". O nome esta na etiqueta (imagem) -> OCR.

    So o bloco de texto "Volume/Teor/Castas" e por pagina, entao ele e aplicado
    a todos os codigos daquela pagina e marcado como duvidoso no relatorio.
    """
    doc = pymupdf.open(f"{PDF}/Vinhos importados_compressed.pdf")
    ocr = {}
    try:
        ocr = {x["page"]: x["lines"] for x in json.load(open(f"{EXTRACT}/vinhosimportados.ocr.json"))}
    except Exception:
        pass
    products, ids = [], set()
    for page in doc:
        pn = page.number + 1
        vec = dedupe_lines(raw_lines(page))
        ocr_lines = sorted(ocr.get(pn, []), key=lambda z: z["y0"])
        anchors, seen = [], set()
        for l in sorted(vec + ocr_lines, key=lambda z: (round(z["x0"] / 60), z["y0"])):
            m = re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*([0-9]{3})", clean(l["t"]))
            if not m or m.group(1) in seen:
                continue
            seen.add(m.group(1))
            anchors.append({"code": m.group(1), "x": (l["x0"] + l["x1"]) / 2, "y": l["y0"]})
        if not anchors:
            continue
        kvv, _ = kv(vec)
        alltext = " ".join(l["t"] for l in vec)
        producer = ""
        m = re.search(r"(Vidigal ?Wines|Adega de Cantanhede|Cantina Galasso|Castillo de Andrade|"
                      r"Cono Sur|Stormhoek|Amareleza|Martha'?s|Bodega RPB|Lopez Morenas|"
                      r"Esencia Wines|Azienda Ricchi|Bodega Kinast|Global Wines|3 Autores|"
                      r"Vinícola [A-ZÀ-ÿ ]{3,25}|Bodega [A-ZÀ-ÿ ]{3,25})", alltext, re.I)
        if m:
            producer = clean(m.group(1))
        country = ""
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"), (r"\\bFRAN[ÇC]A\\b|FRANCE", "França"),
                     (r"\\bCHILE\\b", "Chile"), (r"\\bESPANHA\\b", "Espanha"),
                     (r"\\bITALIA\\b", "Itália"), (r"\\bARGENTINA\\b", "Argentina"),
                     (r"AFRICA ?DO ?SUL", "África do Sul")):
            if re.search(k, alltext, re.I):
                country = c
                break
        region = ""
        m = re.search(r"(D\\.?O\\.? ?VALLE CENTRAL|VALLE CENTRAL|DOC DAO|\\bDAO\\b|BEIRA ATLANTICO|"
                      r"LANGUEDOC ?ROUSSILLON|COTES ?DU ?RHONE|EXTREMADURA|WESTERN CAPE|MENDOZA|"
                      r"ABRUZZO|LOMBARDIA|VENETO|SICILIA|DOCVERDE|DOC VERDE|ALENTEJO|DOURO|LISBOA|"
                      r"BAIRRADA|CANTANHEDE)", alltext, re.I)
        if m:
            region = titleize(clean(m.group(1)).replace("DOCVERDE", "DOC Verde"))
        imgs = page_images(page)
        for a in anchors:
            near = [l for l in ocr_lines
                    if abs((l["x0"] + l["x1"]) / 2 - a["x"]) < 100 and a["y"] - 140 <= l["y0"] <= a["y"] + 45]
            label = clean(" ".join(l["t"] for l in near))
            label = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", label, flags=re.I)
            label = re.sub(r"(?i)(teor ?alco|volume ?[:\\d]|origem[:\\s]|\\bcastas\\b|uvas[:\\s]).*$", " ", label)
            label = clean(re.sub(r"[^A-Za-zÀ-ÿ0-9.,%()&'\\s/\\-]", " ", label))
            label = re.sub(r"\\s+", " ", label)
            trusted = bool(re.search(r"[A-Za-zÀ-ÿ]{4,}\\s+\\S", label))
            if trusted and len(label) >= 5:
                name = titleize(label[:120])
            else:
                name = f"{titleize(producer) if producer else 'Vinho importado'} — código {a['code']}"
            pid = f"pdf-imp-{a['code']}"
            if pid in ids:
                continue
            ids.add(pid)
            im = match_image(page, imgs, a["x"], a["y"] + 80, band=100_000)
            img = crop_save(page, im["bbox"], f"importado-{a['code']}") if im else None
            attrs = {}
            if kvv.get("grape"):
                attrs["grape"] = clean(kvv["grape"])[:100]
            if kvv.get("alcohol"):
                attrs["alcohol"] = clean(kvv["alcohol"])[:60]
            if kvv.get("volume"):
                attrs["volume"] = clean(kvv["volume"])[:80]
            if region:
                attrs["origin"] = region[:100]
            m = re.search(r"([0-9]{1,2}\\s*x\\s*[0-9]{2,4}\\s*ml)", alltext, re.I)
            unit = clean(m.group(1)) if m else "750ml"
            if m:
                attrs["volume"] = attrs.get("volume") or unit
                attrs["quantity"] = re.sub(r"\\s+", " ", unit)
            desc = (f"{name}. " if trusted else
                    f"Rótulo do catálogo de importados, código {a['code']}. ")
            desc += ("Origem e especificações lidas por OCR da etiqueta — conferir antes de publicar."
                     if trusted else
                     "Nome não identificado no PDF (etiqueta é imagem sem texto); complete no Admin.")
            products.append({
                "id": pid, "name": name[:150], "department": "vinhos",
                "subcategory": "Vinhos Importados",
                "brand": titleize(producer)[:110], "sku": a["code"],
                "imported": True, "country": country, "region": region, "price": 0,
                "unit": f"Garrafa {unit}" if "x" in unit else unit,
                "description": clean(desc)[:1200],
                "images": [img] if img else [], "attributes": attrs,
                "weightGrams": 1450, "lengthCm": 9, "widthCm": 9, "heightCm": 31,
                "stock": None, "stockMin": None,
                "available": False, "hidden": False, "featured": False,
                "madeToOrder": False, "seasonal": False, "giftEnabled": True,
                "source": "pdf:importados", "sourcePage": pn,
                "_needsReview": (not trusted),
            })
    return products


'''
marker = 'if __name__ == "__main__":'
assert marker in s
s = s.replace(marker, IMPORT.lstrip() + marker)
open(p, "w").write(s)
print("build2.py atualizado")
