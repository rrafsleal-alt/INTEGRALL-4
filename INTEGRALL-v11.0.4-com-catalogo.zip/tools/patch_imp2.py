import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

start = s.index('# ============================================== IMPORTADOS (codigo na imagem)')
end = s.index('if __name__ == "__main__":')

new = '''# ============================================== IMPORTADOS (codigo na imagem)
IMP_SKIP = re.compile(r"PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICADOSUL|"
                      r"LISBOA|VERDE|DOURO|\\bDAO\\b|BEIRA|ATLANTICO|CANTANHEDE|LEIRIA|"
                      r"ALENTEJO|BAIRRADA|LANGUEDOC|ROUSSILLON|RHONE|EXTREMADURA|WINES|"
                      r"VINICOLA|ADEGA|BODEGA|GLOBAL|CENTRAL|VALLE|\\bDOC\\b|D\\.O\\.|WESTERN|"
                      r"CAPE|MENDOZA|ABRUZZO|LOMBARDIA|VENETO|SICILIA|COLHEITA|SELECIONADA", re.I)
IMP_NOISE = re.compile(r"^\\s*(C[ÓO]D|Volume|Vol|Teor|Castas|Uvas|Origem|Regi|Safra|Produtor|"
                       r"ESPEC|D\\.O\\.|Baixas|Vinicola|Adega|Bodega|CHILE|PORTUGAL|FRANCA|"
                       r"ESPANHA|ITALIA|ARGENTINA|AFRICA|WINE|VIN|PRODUTO|PREMIOS|AWARDS)", re.I)


def parse_importados():
    """Um produto por codigo.

    Prioridade do nome:
      1) texto vetorial da propria pagina (paginas de detalhe trazem
         "NOME DO ROTULO" na linha imediatamente antes de "C[ÓO]D nnn", e a
         ficha tecnica logo depois) -> confiavel;
      2) OCR da etiqueta (usado so quando o rotulo parece limpo);
      3) marca/linha da pagina + codigo, marcado para revisao.
    """
    doc = pymupdf.open(f"{PDF}/Vinhos importados_compressed.pdf")
    ocr = {}
    try:
        ocr = {x["page"]: x["lines"] for x in json.load(open(f"{EXTRACT}/vinhosimportados.ocr.json"))}
    except Exception:
        pass
    products, ids = [], set()
    for page in doc:
        pn = page.number + 1
        vec = dedupe_lines(raw_lines(page))
        if not vec:
            continue
        lines = sorted(vec, key=lambda z: (round(z["y0"] / 6), z["x0"]))
        cod_idx = [(i, re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*([0-9]{3})", l["t"])) for i, l in enumerate(lines)]
        cod_idx = [(i, m.group(1)) for i, m in cod_idx if m]
        if not cod_idx:
            continue
        # --- pagina de detalhe: nome vetorial antes do codigo + ficha depois ---
        detail = []
        for k, (i, code) in enumerate(cod_idx):
            prev = lines[i - 1]["t"] if i else ""
            if prev and not IMP_NOISE.match(prev) and re.search(r"[A-Za-zÀ-ÿ]{4}", prev) \\
               and not IMP_SKIP.fullmatch(prev.upper().strip()):
                nxt = []
                stop = cod_idx[k + 1][0] if k + 1 < len(cod_idx) else len(lines)
                for l in lines[i + 1:stop]:
                    if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", l["t"]):
                        break
                    nxt.append(l)
                detail.append({"code": code, "name": clean(prev), "spec": nxt,
                               "x": (lines[i]["x0"] + lines[i]["x1"]) / 2, "y": lines[i]["y0"]})
        codes = sorted({d["code"] for d in detail})
        seen, anchors = set(), []
        if len(detail) >= 2:
            for d in detail:
                if d["code"] in seen:
                    continue
                seen.add(d["code"]); anchors.append(d)
            mode = "vector"
        else:
            mode = "ocr"
            for l in sorted(vec + sorted(ocr.get(pn, []), key=lambda z: z["y0"]),
                            key=lambda z: (round(z["x0"] / 60), z["y0"])):
                m = re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*([0-9]{3})", clean(l["t"]))
                if not m or m.group(1) in seen:
                    continue
                seen.add(m.group(1))
                anchors.append({"code": m.group(1), "name": "", "spec": [],
                                "x": (l["x0"] + l["x1"]) / 2, "y": l["y0"]})
        alltext = " ".join(l["t"] for l in vec)
        producer = ""
        m = re.search(r"(Vidigal ?Wines|Vidigal|Adega de Cantanhede|Cantina Galasso|"
                      r"Castillo de Andrade|Cono Sur|Stormhoek|Amareleza|Martha'?s|"
                      r"Bodega RPB|Lopez Morenas|Esencia Wines|Azienda Ricchi|"
                      r"Bodega Kinast|Global Wines|3 Autores|Vinícola [A-ZÀ-ÿ ]{3,25}|"
                      r"Bodega [A-ZÀ-ÿ ]{3,25})", alltext, re.I)
        if m:
            producer = clean(m.group(1))
        line_brand = ""
        for l in sorted(vec, key=lambda z: z["y0"])[:4]:
            raw = clean(l["t"]).upper()
            if "." not in raw or len(raw) < 12:
                continue
            tail = [x.strip() for x in re.split(r"[.]+", raw) if x.strip() and not IMP_SKIP.search(x)]
            if tail:
                line_brand = clean(" ".join(tail[:2]))
                break
        country = ""
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"), (r"FRAN[ÇC]A|FRANCE", "França"),
                     (r"\\bCHILE\\b", "Chile"), (r"\\bESPANHA\\b", "Espanha"),
                     (r"\\bITALIA\\b", "Itália"), (r"\\bARGENTINA\\b", "Argentina"),
                     (r"AFRICA ?DO ?SUL", "África do Sul")):
            if re.search(k, alltext, re.I):
                country = c
                break
        region = ""
        m = re.search(r"(VALLE CENTRAL|DOC DAO|BEIRA ATLANTICO|LANGUEDOC ?ROUSSILLON|"
                      r"COTES ?DU ?RHONE|EXTREMADURA|WESTERN CAPE|MENDOZA|ABRUZZO|LOMBARDIA|"
                      r"DOC ?VERDE|ALENTEJO|DOURO|LISBOA|BAIRRADA|CANTANHEDE)", alltext, re.I)
        if m:
            region = titleize(clean(m.group(1)))
        imgs = page_images(page)
        ocr_lines = sorted(ocr.get(pn, []), key=lambda z: z["y0"])
        for a in anchors:
            trusted = mode == "vector"
            name = a["name"] if trusted else ""
            spec = a["spec"]
            if not trusted:
                near = [l for l in ocr_lines
                        if abs((l["x0"] + l["x1"]) / 2 - a["x"]) < 100
                        and a["y"] - 150 <= l["y0"] <= a["y"] + 45]
                lab = clean(" ".join(l["t"] for l in near))
                lab = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", lab, flags=re.I)
                lab = re.sub(r"(?i)\\b(teor|volume|origem|castas|uvas|gradua|alco[o6ú]ol|"
                             r"produtor|regiao|safra|premio|award|medal|pts)\\w*.*$", " ", lab)
                lab = re.sub(r"\\d{1,2}[.,]\\d\\s*%?", " ", lab)
                lab = re.sub(r"\\d{1,2}\\s*[xX]\\s*\\d{3}\\s*ml", " ", lab, flags=re.I)
                lab = re.sub(r"[^A-Za-zÀ-ÿ()'&./\\- ]", " ", lab)
                lab = clean(re.sub(r"\\s+", " ", lab))
                # aceita OCR so quando parece rotulo de verdade: 2+ palavras, sem lixo
                if len(lab) >= 6 and len(lab) <= 58 and re.search(r"[A-Za-zÀ-ÿ]{4,}\\s+\\S", lab) \\
                   and not re.search(r"(?i)(wine|blanc|rouge|produto|sinieee|pbeter|hosi|sl\\b|a01)", lab):
                    name, trusted = lab, False  # ainda marcado como OCR
            fb = titleize(producer or line_brand or "")
            if name:
                nm = titleize(re.sub(r"\\s*\\.\\s*", ". ", name)[:120])
            elif fb:
                nm = f"{fb} — código {a['code']}"
            else:
                nm = f"Vinho importado — código {a['code']}"
            pid = f"pdf-imp-{a['code']}"
            if pid in ids:
                continue
            ids.add(pid)
            im = match_image(page, imgs, a["x"], a["y"] + 80, band=100_000)
            img = crop_save(page, im["bbox"], f"importado-{a['code']}") if im else None
            spec_text = " ".join(l["t"] for l in spec) if spec else alltext
            attrs = {}
            for lab, rx, cap in (("grape", r"Castas\\s*Uvas\\s*:?\\s*(.+?)(?=\\s+(?:D\\.O\\.|C[ÓO]D|Teor|$))", 100),
                                  ("alcohol", r"Teor\\s*alco[óo]lico\\s*:?\\s*([0-9]+(?:,[0-9]+)?\\s*%[vVwW/]*)", 40),
                                  ("volume", r"Volume\\s*:?\\s*([0-9]{1,2}\\s*[xX]\\s*[0-9]{2,4}\\s*ml|[0-9]+(?:[.,][0-9]+)?\\s*(?:ml|L))", 40),
                                  ("origin", r"(?:Origem|Regi[ãa]o)\\s*:?\\s*([A-ZÀ-Ú][A-Za-zÀ-ÿ ]{3,40})", 60)):
                m = re.search(rx, spec_text, re.I)
                if m:
                    attrs[lab] = clean(m.group(1))[:cap]
            unit = attrs.get("volume") or "750ml"
            if attrs.get("volume") and "x" in attrs["volume"].lower():
                attrs["quantity"] = attrs["volume"]
            if region and "origin" not in attrs:
                attrs["origin"] = region
            src = "texto do PDF" if trusted else "OCR da etiqueta"
            desc = (f"{nm}. " if name else
                    f"Rótulo do catálogo de importados, código {a['code']}"
                    + (f" (linha {fb})" if fb else "") + ". ")
            desc += (f"Especificações lidas do catálogo ({src})."
                     if name else
                     "Nome não recuperado do PDF (etiqueta sem texto); complete no Admin.")
            products.append({
                "id": pid, "name": nm[:150], "department": "vinhos",
                "subcategory": "Vinhos Importados", "brand": titleize(producer or line_brand)[:110],
                "sku": a["code"], "imported": True, "country": country, "region": region,
                "price": 0, "unit": f"Caixa {unit}" if "x" in unit.lower() else f"Garrafa {unit}",
                "description": clean(desc)[:1200],
                "images": [img] if img else [], "attributes": attrs,
                "weightGrams": 1450, "lengthCm": 9, "widthCm": 9, "heightCm": 31,
                "stock": None, "stockMin": None,
                "available": False, "hidden": False, "featured": False,
                "madeToOrder": False, "seasonal": False, "giftEnabled": True,
                "source": f"pdf:importados ({src})", "sourcePage": pn,
                "_needsReview": (not trusted),
            })
    return products


'''
s = s[:start] + new + s[end:]
open(p, "w").write(s)
print("parse_importados reescrito")
