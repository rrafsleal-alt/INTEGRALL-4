import re

p = "/home/user/work/tools/assemble.py"
s = open(p).read()

old = '''            key = norm(p["name"])
            hit = seen_names.get(key)
            if hit:
                # ja existe na loja: so completa campos vazios
                changed = []
                if p.get("sku") and not hit.get("sku"):
                    hit["sku"] = p["sku"]; changed.append("sku")
                for k in ("country", "region", "unit", "brand"):
                    if p.get(k) and not hit.get(k):
                        hit[k] = p[k]; changed.append(k)
                for k, v in (p.get("attributes") or {}).items():
                    if v and not (hit.get("attributes") or {}).get(k):
                        hit.setdefault("attributes", {})[k] = v
                        changed.append(f"attributes.{k}")
                if not hit.get("images") and p.get("images"):
                    hit["images"] = p["images"]; changed.append("images")
                enriched.append((hit["name"], p["name"], ", ".join(changed) or "nada"))
                continue'''
new = '''            key = norm(p["name"])
            hit = seen_names.get(key)
            codes = re.findall(r"\\b[0-9]{3}\\b", str(p.get("sku") or ""))
            hit_codes = set(re.findall(r"\\b[0-9]{3}\\b", " ".join(
                str(x) for x in [hit.get("sku"), hit.get("name"),
                                 json.dumps(hit.get("variants") or [])] if x))) if hit else set()
            # so e o MESMO produto se o nome bate E nao ha codigo novo na ficha do
            # PDF. Antes bastava o nome e duas garrafas diferentes (ex. 750 ml e
            # 187 ml do mesmo rotulo) se anulavam e um SKU se perdia.
            if hit and (not codes or set(codes) <= hit_codes):
                changed = []
                if p.get("sku") and not hit.get("sku"):
                    hit["sku"] = p["sku"]; changed.append("sku")
                for k in ("country", "region", "unit", "brand"):
                    if p.get(k) and not hit.get(k):
                        hit[k] = p[k]; changed.append(k)
                for k, v in (p.get("attributes") or {}).items():
                    if v and not (hit.get("attributes") or {}).get(k):
                        hit.setdefault("attributes", {})[k] = v
                        changed.append(f"attributes.{k}")
                if not hit.get("images") and p.get("images"):
                    hit["images"] = p["images"]; changed.append("images")
                enriched.append((hit["name"], p["name"], ", ".join(changed) or "nada"))
                continue
            if hit:
                # produto diferente com o mesmo nome: mantem os dois, mas o nome
                # do site precisa ser unico (o validador exige), entao marcamos o
                # codigo e avisamos no relatorio para voce fundir no Admin se quiser
                tag = f" (cód. {'/'.join(codes)})" if codes else ""
                p["name"] = (p["name"] + tag)[:150]
                p["description"] = ((p.get("description") or "") +
                    f" Atenção: existe “{hit['name']}” no catálogo; se for o mesmo "
                    "produto, funda os dois no Admin.").strip()[:1200]
                collisions.append((hit["name"], p["name"]))
                key = norm(p["name"])'''
assert old in s
s = s.replace(old, new)
s = s.replace('''    new_products, enriched, skipped = [], [], []''',
              '''    new_products, enriched, skipped, collisions = [], [], [], []''')
s = s.replace('''    rep["indisponiveis"] = sum(1 for p in new_products if p.get("available") is False)''',
'''    rep["indisponiveis"] = sum(1 for p in new_products if p.get("available") is False)
    rep["nomes_colidiram"] = collisions''')
s = s.replace('''    print("enriquecidos:", len(enriched))''',
'''    print("colisoes de nome mantidas como produtos separados:", len(collisions))
    for c in collisions[:12]:
        print("   ", c[0], "≠", c[1])
    print("enriquecidos:", len(enriched))''')
open(p, "w").write(s)
print("assemble: merge nao descarta mais SKU novo")
