import re

p = "/home/user/work/tools/assemble.py"
s = open(p).read()

# sabe quais ids sao da loja (seed) para decidir fundir x manter separado
s = s.replace('''    by_name = {}''', '''    seed_ids = {p0["id"] for p0 in existing}
    by_name = {}''')

old = '''            # so e o MESMO produto se o nome bate E nao ha codigo novo na ficha do
            # PDF. Antes bastava o nome e duas garrafas diferentes (ex. 750 ml e
            # 187 ml do mesmo rotulo) se anulavam e um SKU se perdia.
            if hit and (not codes or set(codes) <= hit_codes):'''
new = '''            # Colisao com produto DA LOJA (seed): e o mesmo produto — funde, mas
            # nunca sem registrar o codigo do PDF (antes o "Biscoito de Polvilho"
            # do site engoliu a ficha 961/960 e o SKU sumiu do cadastro).
            if hit and hit.get("id") in seed_ids:'''
assert old in s
s = s.replace(old, new)

# ao fundir, garante que todo codigo do PDF fique gravado
old2 = '''                changed = []
                if p.get("sku") and not hit.get("sku"):
                    hit["sku"] = p["sku"]; changed.append("sku")'''
new2 = '''                changed = []
                pdf_codes = re.findall(r"[0-9]{3}", str(p.get("sku") or ""))
                have = re.findall(r"[0-9]{3}", str(hit.get("sku") or ""))
                lost = [c for c in pdf_codes if c not in have]
                if lost:
                    hit["sku"] = ", ".join(have + lost)[:120]
                    changed.append("sku+" + "/".join(lost))
                    d0 = str(hit.get("description") or "")
                    if "códigos do catálogo" not in d0.lower():
                        hit["description"] = (d0 + f" Códigos do catálogo PDF: "
                                               f"{'/'.join(pdf_codes)}. "
                                               f"Formatos: {p.get('unit') or '—'}.").strip()[:1200]'''
assert old2 in s
s = s.replace(old2, new2)

# colidir com OUTRA ficha do PDF = produto diferente (codigo diferente), mantem os dois
s = s.replace('''            if hit:
                # produto diferente com o mesmo nome: mantem os dois, mas o nome''',
'''            if hit:
                # produto diferente com o mesmo nome: mantem os dois, mas o nome''')

open(p, "w").write(s)
print("assemble: seed funde (sem perder codigo); fichas do PDF ficam separadas")
