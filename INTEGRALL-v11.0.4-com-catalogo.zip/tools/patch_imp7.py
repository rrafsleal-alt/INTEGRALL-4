import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# ---- 1) nome da ficha: parear por coluna (mesma faixa de x), nao por linha vizinha global ----
old = '''        for k, (i, code) in enumerate(codes):
            prev, py = (lines[i - 1]["t"], lines[i - 1]["y0"]) if i else ("", 0)
            if not _imp_label_like(prev, page_top, py) and i + 1 < len(lines) \\
               and _imp_label_like(lines[i + 1]["t"], page_top, lines[i + 1]["y0"]):
                prev, py = lines[i + 1]["t"], lines[i + 1]["y0"]
            if not _imp_label_like(prev, page_top, py):
                continue'''
new = '''        cx = (lines[i]["x0"] + lines[i]["x1"]) / 2 if False else 0
        for k, (i, code) in enumerate(codes):
            ref = lines[i]
            cx = (ref["x0"] + ref["x1"]) / 2
            cy = ref["y0"]
            # as fichas ficam em colunas: o nome esta logo ACIMA (ou a esquerda)
            # do codigo DENTRO da mesma coluna, nao na linha anterior da pagina
            cand = [l for l in lines
                    if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and l is not ref
                    and -22 <= l["y0"] - cy <= 4 and _imp_label_like(l["t"], page_top, l["y0"])]
            cand.sort(key=lambda l: abs(l["y0"] - cy))
            if cand:
                prev, py = cand[0]["t"], cand[0]["y0"]
            else:
                below = [l for l in lines
                         if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and l is not ref
                         and 4 < l["y0"] - cy <= 26 and _imp_label_like(l["t"], page_top, l["y0"])]
                below.sort(key=lambda l: abs(l["y0"] - cy))
                prev, py = (below[0]["t"], below[0]["y0"]) if below else ("", 0)
            if not _imp_label_like(prev, page_top, py):
                continue'''
assert old in s
s = s.replace(old, new)
s = s.replace('''        cx = (lines[i]["x0"] + lines[i]["x1"]) / 2 if False else 0
        for k, (i, code) in enumerate(codes):''', '''        for k, (i, code) in enumerate(codes):''')

# spec: limitar ao bloco da coluna (ate a proxima linha de codigo da MESMA coluna)
old2 = '''            stop = codes[k + 1][0] if k + 1 < len(codes) else len(lines)
            spec = []
            for l in lines[i + 1:stop]:
                if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"])):
                    break
                spec.append(l)
            for l in lines[max(0, i - 3):i]:
                if _imp_label_like(l["t"], page_top, l["y0"]):
                    spec.append(l)'''
new2 = '''            spec = []
            for l in lines:
                if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"])):
                    continue
                if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and 2 <= l["y0"] - cy <= 70:
                    spec.append(l)'''
assert old2 in s
s = s.replace(old2, new2)

# ---- 2) nao vazar regiao/pais de uma secao para a seguinte ----
old3 = '''        m = re.search(r"(VIN[ÍI]COLA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|VINICOLA[A-ZÀ-Ú][A-ZÀ-ÿ ]{2,20}|'''
new3 = '''        if re.search(r"(?i)(PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA ?DO ?SUL)",
                     f"{head} {ocr_head}") and (head.strip() or ocr_head.strip()):
            # comeca uma secao nova: nada de herdar regiao do produtor anterior
            if not ctx.get("_sect") or ctx["_sect"] != clean(head)[:40]:
                ctx["region"] = ""
                ctx["_sect"] = clean(head)[:40]
        m = re.search(r"(VIN[ÍI]COLA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|VINICOLA[A-ZÀ-Ú][A-ZÀ-ÿ ]{2,20}|'''
assert old3 in s
s = s.replace(old3, new3)

# ---- 3) origin nao engole "Volume" e afins; brand sem CamelCase grudento / lixo ----
old4 = '''                    ("origin", r"^(?:Origem|Regi[ãa]o|D\\.O\\.?)\\s*:?\\s*([A-ZÀ-Ú][A-Za-zÀ-ÿ ]{3,40})", 60)):'''
new4 = '''                    ("origin", r"^(?:Origem|Regi[ãa]o|D\\.O\\.?)\\s*:?\\s*"
                              r"([A-ZÀ-Ú][A-Za-zÀ-ÿ ]{3,40}?)(?=\\s+(?:Volume|Teor|Castas|C[ÓO]D|\\bD\\.O\\b|$))", 60)):'''
assert old4 in s
s = s.replace(old4, new4)
s = s.replace('''            if "grape" in attrs:
                attrs["grape"] = titleize(re.split(r"(?i)\\bcastas\\b", attrs["grape"])[0])''',
'''            if "grape" in attrs:
                attrs["grape"] = titleize(re.split(r"(?i)\\bcastas\\b", attrs["grape"])[0])
            for kk in ("origin", "volume"):
                if attrs.get(kk):
                    attrs[kk] = re.sub(r"(?i)\\s+(volume|teor|castas|code)\\s*$", "", attrs[kk]).strip()''')

# marca: separa palavras coladas e descarta lixo
old5 = '''            fb = titleize(c["producer"] or c["line"] or "")'''
new5 = '''            raw_brand = c["producer"] or c["line"] or ""
            raw_brand = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", raw_brand)
            raw_brand = re.sub(r"(?i)[+,]? ?de ?[0-9]+[0-9 .]*", " ", raw_brand)
            raw_brand = titleize(re.sub(r"\\s+", " ", raw_brand)).strip()
            fb = "" if len(raw_brand) < 4 or re.fullmatch(r"[0-9\\W]*", raw_brand) else raw_brand[:110]'''
assert old5 in s
s = s.replace(old5, new5)
s = s.replace('''                        if m:
                            ctx["producer"] = clean(m.group(1)).title()''',
'''                        if m:
                            ctx["producer"] = clean(m.group(1)).title()''')
open(p, "w").write(s)
print("ok")
