#!/usr/bin/env python3
"""Gera o RELATORIO de cadastro + conferencia final, a partir do catalogo aplicado."""
import json, os, re, unicodedata, collections

WORK = "/home/user/work"
cat = json.load(open(f"{WORK}/data/catalog.json"))
ps = cat["products"]
seed = json.load(open(f"{WORK}/data/catalog.seed.json"))
seed_ids = {p["id"] for p in seed["products"]}
new = [p for p in ps if p["id"] not in seed_ids]
stages = {}
for f in ("stage1.json", "stage2.json"):
    stages.update(json.load(open(f"{WORK}/out/{f}")))
summary = json.load(open(f"{WORK}/out/summary.json"))
parsed = {"biscoitos": len(stages.get("biscoitos", [])), "nacionais": len(stages.get("nacionais", [])),
          "importados": len(stages.get("importados", [])), "sucos": len(stages.get("sucos", [])),
          "cafe": len(stages.get("cafe", []))}


def dept(p):
    if p["department"] == "vinhos":
        return "vinhos-importados" if p.get("imported") else "vinhos-nacionais"
    return p["department"]


by = collections.Counter(dept(p) for p in new)
orig = collections.Counter((p.get("source") or "?").split(" ")[0] for p in new)
noimg = [p["name"] for p in new if not p.get("images")]
total_sku = sum(1 for p in ps if p.get("sku"))
novar = [p["name"] for p in new if not p.get("variants")]
needrev = [p for p in new if "código" in p["name"] or "OCR" in (p.get("source") or "")]
noprice = sum(1 for p in new if (p.get("price") or 0) == 0)
nosku = [p["name"] for p in new if not p.get("sku")]
attrs = collections.Counter(k for p in new for k in (p.get("attributes") or {}))

lines = []
A = lines.append
A("# Cadastro dos 5 catálogos em PDF — INTEGRALL Online\n")
A(f"**Catálogo da loja agora: {len(ps)} produtos** — {len(new)} cadastrados a partir dos PDFs "
  f"+ {len(seed['products'])} que já existiam e foram preservados.\n")
A(f"Sobre os PDFs: **{sum(parsed.values())} fichas lidas**, das quais "
  f"{len(summary.get('enriquecidos', []))} eram o mesmo produto que já estava na loja "
  "(mesmo nome) e por isso **não duplicaram** — receberam apenas o SKU/campos que faltavam.\n")
A("## O que entrou\n")
A("| origem | qtd | departamento no site |")
A("|---|---|---|")
labels = {
    "Catálogo Biscoitos": ("biscoitos", "petit-four"),
    "Vinhos Nacionais": ("nacionais", "vinhos-nacionais"),
    "Vinhos importados": ("importados", "vinhos-importados"),
    "Sucos": ("sucos", "sucos"),
    "Café Jurerê": ("cafe", "cafes"),
}
for tag, (bucket, d) in labels.items():
    A(f"| {tag}.pdf | {parsed[bucket]} lidas → {by.get(d, 0)} cadastradas | {d} |")
A("")
A("Campos preenchidos por produto: **nome, departamento/subcategoria, descrição, "
  "variantes (quando o PDF traz mais de um formato), SKU = código do PDF, marca/produtor, "
  "unidade (embalagem), peso e dimensões para frete, atributos (uva, safra, teor alcoólico, "
  "origem, torra, vol. etc.) e 1 foto recortada do próprio PDF.**\n")
A("## Fotos\n")
A(f"- {len([p for p in new if p.get('images')])} produtos com imagem; {len(noimg)} sem imagem.")
nassets = len(os.listdir(f"{WORK}/public/assets/products/pdf"))
sz = sum(os.path.getsize(f"{WORK}/public/assets/products/pdf/{f}")
         for f in os.listdir(f"{WORK}/public/assets/products/pdf")) / 1e6
A(f"- cada foto é o recorte em alta do rótulo/embalagem na página do PDF "
  f"(`public/assets/products/pdf/*.webp`: {nassets} arquivos, {sz:.1f} MB) — nada de foto genérica. "
  f"Alguns produtos compartilham a arte quando o PDF mostra o mesmo rótulo em duas páginas.")
A("")
A("## O que ficou faltando (é só preencher isso)\n")
A(f"1. **Preço**: {noprice}/{len(new)} produtos estão com preço 0 — os 5 PDFs não trazem "
   "nenhum valor (busca por `R$`/`preço`/`valor` = 0 ocorrências). "
   "Use a planilha `precos-a-preencher.csv` (uma linha por variante).")
A(f"2. **Disponibilidade**: todos os novos entraram `disponível = não` "
   "para nada ir ao ar sem preço. No Admin, marque disponibilidade ao confirmar preço/estoque.")
A("3. **Estoque**: ficou vazio (`—`) porque não há dado nos PDFs.")
A(f"4. **Variantes**: {len(novar)} produtos entraram sem variante "
   "(o PDF não separa formatos para eles).")
A("5. **Caixa/dimensões logísticas**: usei peso e volume padrão por tipo "
   "(vinho 750 ml = 1,45 kg / 9×9×31 cm; suco 1 L = 1,05 kg; café 250 g = 250 g; "
   "biscoito seguiu a caixa do próprio PDF). Ajuste se sua transportadora exigir.")
A("")
A("## Casos que merecem sua conferência\n")
A(f"- **{len(needrev)} rótulos de importados sem nome legível**: no PDF de importados a "
   "maioria das páginas é *folha de etiquetas* — o nome existe só dentro da arte, e vários "
   "códigos dividem a mesma imagem. Nesses casos cadastrei como "
   "**“Marca/linha — código NNN”** (ex.: “Vidigal Wines — código 435”), com o recorte da "
   "etiqueta, o país e a região corretos, e a hipótese de leitura da etiqueta escrita na "
   "descrição. Onde o PDF tinha a ficha pronta (páginas do Stormhoek, Relatos de Valpa, Da pipa) "
   "o nome veio limpo do texto.")
A("- **Descrições transcritas literalmente do PDF**, inclusive quando o PDF tem erro de "
   "digrafia (ex.: “Carbenet Sauvignon” na página Cave). Não corrigi para não inventar dado.")
A("- **Sucos e cafés**: volume/torra/notas saíram de OCR (essas páginas são imagem). "
   "Confira a unidade dos sucos — o PDF diz “Garrafa 1 L e 300 ml” sem dizer por sabor.")
A("- **Biscoitos**: onde o PDF traz dois códigos na mesma ficha (ex.: 959/965), gerei **um** "
   "produto com **duas variantes** (tradicional / queijo), que é como o site funciona.")
if noimg:
    A(f"- sem foto: {', '.join(noimg[:8])}")
A("")
A("## Atributos mais comuns capturados\n")
A(", ".join(f"`{k}` ({v})" for k, v in attrs.most_common(16)))
A(f"\nSKU/código preenchido em **{total_sku}/{len(ps)}** produtos "
  "(os sem SKU são os que já estavam na loja sem código).")
A("")
A("## Como aplicar\n")
A("**Já aplicado** neste projeto (`data/catalog.json`) — rode `npm run dev` e veja a loja. "
  "Validado pelo verificador do próprio projeto: `AUDIT OK`, `npm test` 103/103, "
  f"`normalizeCatalog` aceita os {len(ps)} produtos, IDs únicos, todas as imagens existem.\n")
A("Na sua base de produção, o caminho é o Admin → **Importar catálogo** com "
  "`data/catalog.json` (atenção: a importação *substitui* o catálogo atual — por isso o "
  "arquivo já vem com os seus 5 produtos mesclados) **ou** rode "
  "`node scripts/migrate.mjs` com o JSON. Se preferir manter os preços no banco, "
  "importe e depois ajuste por produto.\n")
A("## Arquivos desta entrega\n")
A("| arquivo | o que é |")
A("|---|---|")
A("| `INTEGRALL-v11.0.4-com-catalogo.zip` | projeto completo, com catálogo e fotos aplicados |")
A("| `data/catalog.json` | só o catálogo (para importar no Admin sem trocar o resto) |")
A("| `precos-a-preencher.csv` | planilha: uma linha por variante, coluna de preço em branco |")
A("| `RELATORIO-CADASTRO.md` | este relatório |")
A("| `tools/` + `extract/` | extratores (rode de novo quando os PDFs mudarem) |")
open(f"{WORK}/out/RELATORIO-CADASTRO.md", "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
