import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# 1) limpar melhor o rotulo vindo do OCR (tirar "Teoralc6olico 12,5%", %, etc.)
old = '''            label = clean(" ".join(l["t"] for l in near))
            label = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", label, flags=re.I)
            label = re.sub(r"(?i)(teor ?alco|volume ?[:\\d]|origem[:\\s]|\\bcastas\\b|uvas[:\\s]).*$", " ", label)
            label = clean(re.sub(r"[^A-Za-zÀ-ÿ0-9.,%()&'\\s/\\-]", " ", label))
            label = re.sub(r"\\s+", " ", label)'''
new = '''            label = clean(" ".join(l["t"] for l in near))
            label = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", label, flags=re.I)
            # corta em qualquer bloco de ficha tecnica (OCR junta tudo: "Teoralc6olico")
            label = re.sub(
                r"(?i)\\b(teor|volume|origem|castas|uvas|gradua|alco[o6]ol|alco6ol|produtor|"
                r"vinicola|regiao|safra|colheita|premio|award|medal|pts|"
                r"branco\\s+|tinto\\s+)?(alc[o6ú]olic|volume|teor)\\b.*$", " ", label)
            label = re.sub(r"\\d{1,2}[,\\.]\\d\\s*%\\s*[vV]?/?[wW]?", " ", label)
            label = re.sub(r"\\d{1,2}\\s*[xX]\\s*\\d{3}\\s*ml", " ", label, flags=re.I)
            label = re.sub(r"[^A-Za-zÀ-ÿ0-9()'\\&./\\- ]", " ", label)
            label = re.sub(r"\\s*[..]\\s*", ". ", label)
            label = clean(re.sub(r"\\s+", " ", label))
            label = re.sub(r"(?i)^(e|de|do|a)\\b", "", label).strip(" .,-")
            # sobra so o que parece nome de rotulo (descarta restos de ficha)
            if re.search(r"(?i)^[a-zà-ÿ0-9 .'&/-]{4,}$", label) is None:
                label = ""'''
assert old in s
s = s.replace(old, new)

# 2) fallback de nome: usar a marca/linha do cabecalho da pagina em vez de generico
old2 = '''        country = ""
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"),'''
new2 = '''        # linha de topo do tipo "PORTUGAL.LISBOA.VERDE.VIDIGALWINES.PORTA6" -> marca
        line_brand = ""
        for l in sorted(vec, key=lambda z: z["y0"])[:4]:
            raw = clean(l["t"]).upper()
            if "." not in raw or len(raw) < 12:
                continue
            parts = [x.strip() for x in re.split(r"[.]+", raw) if x.strip()]
            skip = re.compile(r"PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA|"
                              r"LISBOA|VERDE|DOURO|DAO|BEIRA|ATLANTICO|CANTANHEDE|LEIRIA|"
                              r"ALENTEJO|BAIRRADA|LANGUEDOC|ROUSSILLON|RHONE|EXTREMADURA|"
                              r"WESTERN|CAPE|MENDOZA|ABRUZZO|LOMBARDIA|VENETO|SICILIA|"
                              r"WINES|VINICOLA|ADEGA|BODEGA|GLOBAL|CENTRAL|VALLE|DOC|D\\b", re.I)
            tail = [x for x in parts if not skip.search(x)]
            if tail:
                line_brand = clean(" ".join(tail[:2]))
                break
        country = ""
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"),'''
assert old2 in s
s = s.replace(old2, new2)

old3 = '''            if trusted and len(label) >= 5:
                name = titleize(label[:120])
            else:
                name = f"{titleize(producer) if producer else 'Vinho importado'} — código {a['code']}"'''
new3 = '''            fb = titleize(producer or line_brand or "")
            if trusted and len(label) >= 5:
                name = titleize(label[:120])
            elif fb:
                name = f"{fb} — código {a['code']}"
            else:
                name = f"Vinho importado — código {a['code']}"'''
assert old3 in s
s = s.replace(old3, new3)

# descricao: mencionar a marca quando o nome e por fallback
old4 = '''            desc = (f"{name}. " if trusted else
                    f"Rótulo do catálogo de importados, código {a['code']}. ")'''
new4 = '''            desc = (f"{name}. " if trusted else
                    f"Rótulo do catálogo de importados, código {a['code']}"
                    + (f" (linha {fb})" if fb else "") + ". ")'''
assert old4 in s
s = s.replace(old4, new4)

open(p, "w").write(s)
print("ok")
