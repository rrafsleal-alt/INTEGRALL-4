import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# 1) nao usar a linha de topo da pagina (cabecalho "PORTUGAL.LISBOA...") como nome
old = '''        detail = []
        for k, (i, code) in enumerate(cod_idx):
            prev = lines[i - 1]["t"] if i else ""
            if not label_like(prev) and i + 1 < len(lines) and label_like(lines[i + 1]["t"]):
                prev = lines[i + 1]["t"]
            if prev and label_like(prev):'''
new = '''        page_top = min(l["y0"] for l in lines) if lines else 0
        detail = []
        for k, (i, code) in enumerate(cod_idx):
            prev = lines[i - 1]["t"] if i else ""
            prev_y = lines[i - 1]["y0"] if i else 0
            if not label_like(prev) and i + 1 < len(lines) and label_like(lines[i + 1]["t"]):
                prev, prev_y = lines[i + 1]["t"], lines[i + 1]["y0"]
            # cabecalho de secao (primeiras linhas da pagina) nunca e nome de rotulo
            if prev and prev_y - page_top < 40 and re.search(r"\\.|PORTUGAL|CHILE|ESPANHA|ITALIA", prev, re.I):
                prev = ""
            if prev and label_like(prev):'''
assert old in s
s = s.replace(old, new)

# 2) pais/regiao/marca tambem saem do OCR da pagina (algumas paginas so tem texto na imagem)
old2 = '''        alltext = " ".join(l["t"] for l in vec)'''
new2 = '''        ocr_all = " ".join(l["t"] for l in sorted(ocr.get(pn, []), key=lambda z: z["y0"]))
        alltext = " ".join(l["t"] for l in vec) + " " + ocr_all[:900]'''
assert old2 in s
s = s.replace(old2, new2)

# 3) contexto: aceitar cabecalho tambem quando so o OCR o traz
old3 = '''        for l in top_lines[:4]:
            raw = clean(l["t"])
            if raw.count(".") < 2 or len(raw) < 12:
                continue'''
new3 = '''        for l in top_lines[:4] + [{"t": t, "y0": 1e9} for t in ocr_all.split(" | ")[:3]]:
            raw = clean(l["t"])
            if raw.count(".") < 2 and "." not in raw and len(raw.split()) < 3:
                continue'''
assert old3 in s
s = s.replace(old3, new3)

# 4) pais detectado por OCR costuma vir colado ("PORTUGAL.LISBOA...") entao os
#    padroes \\b funcionam; mas "FRANCA." vem sem C-cedilha — ja coberto.
open(p, "w").write(s)
print("ok")
