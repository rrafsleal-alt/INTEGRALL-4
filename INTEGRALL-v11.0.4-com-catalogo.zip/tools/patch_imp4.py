import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# --------------------------------------------------------------- contexto por pagina
old = '''    products, ids = [], set()
    for page in doc:
        pn = page.number + 1
        vec = dedupe_lines(raw_lines(page))
        if not vec:
            continue'''
new = '''    products, ids = [], set()
    # O PDF e organizado em fichas: uma pagina de abertura (país + vinicola +
    # texto) seguida das folhas de rotulos so com "C[ÓO]D nnn". As folhas herdam
    # o contexto da ultima abertura vista.
    ctx = {"producer": "", "line": "", "country": "", "region": ""}
    for page in doc:
        pn = page.number + 1
        vec = dedupe_lines(raw_lines(page))
        if not vec:
            continue'''
assert old in s
s = s.replace(old, new)

# extracao de contexto da pagina de abertura
old2 = '''        country = ""
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"), (r"FRAN[ÇC]A|FRANCE", "França"),'''
new2 = '''        top_lines = sorted(vec, key=lambda z: z["y0"])
        header = clean(" ".join(l["t"] for l in top_lines[:3]))
        m = re.search(r"([A-ZÀ-Ú][A-ZÀ-ÿ. ]{3,40}?VINICOLA|[A-ZÀ-Ú][A-ZÀ-ÿ. ]{3,40}?WINES|"
                      r"ADEGA DE [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|BODEGA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|"
                      r"AZIENDA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|CANTINE[A-ZÀ-ÿ ]{0,15}|"
                      r"CASTILLO DE [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,20})", header.upper(), re.I)
        if m:
            ctx["producer"] = clean(m.group(1))
        for l in top_lines[:4]:
            raw = clean(l["t"])
            if raw.count(".") < 2 or len(raw) < 12:
                continue
            parts = [x.strip() for x in re.split(r"[.]+", raw.upper()) if x.strip()]
            geo = re.compile(r"PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA|WESTERN|"
                             r"CAPE|LISBOA|VERDE|DOURO|DAO|BEIRA|ATLANTICO|CANTANHEDE|LEIRIA|"
                             r"ALENTEJO|BAIRRADA|LANGUEDOC|ROUSSILLON|RHONE|EXTREMADURA|WINES|"
                             r"VINICOLA|ADEGA|BODEGA|GLOBAL|CENTRAL|VALLE|DOC|D\\.O|AZIENDA|"
                             r"CANTINE|CASTILLO|MENDOZA|ABRUZZO|LOMBARDIA|VENETO|SICILIA")
            tail = [x for x in parts if not geo.search(x)]
            if tail:
                ctx["line"] = clean(" ".join(tail[:2]))
                break
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"), (r"FRAN[ÇC]A|FRANCE", "França"),'''
assert old2 in s
s = s.replace(old2, new2)

# pais/regiao atualizam o contexto
s = s.replace('''            if re.search(k, alltext, re.I):
                country = c
                break''',
'''            if re.search(k, alltext, re.I):
                country = c
                ctx["country"] = c
                break''')
s = s.replace('''        if m:
            region = titleize(clean(m.group(1)))
        imgs = page_images(page)''',
'''        if m:
            region = titleize(clean(m.group(1)))
            ctx["region"] = region
        producer = producer or ctx["producer"]
        line_brand = line_brand or ctx["line"]
        country = country or ctx["country"]
        region = region or ctx["region"]
        imgs = page_images(page)''')

# ficha tecnica linha a linha (primeira ocorrencia de cada rotulo)
old3 = '''            spec_text = " ".join(l["t"] for l in spec) if spec else alltext
            attrs = {}
            for lab, rx, cap in (("grape", r"Castas\\s*Uvas\\s*:?\\s*(.+?)(?=\\s+(?:D\\.O\\.|C[ÓO]D|Teor|$))", 100),
                                  ("alcohol", r"Teor\\s*alco[óo]lico\\s*:?\\s*([0-9]+(?:,[0-9]+)?\\s*%[vVwW/]*)", 40),
                                  ("volume", r"Volume\\s*:?\\s*([0-9]{1,2}\\s*[xX]\\s*[0-9]{2,4}\\s*ml|[0-9]+(?:[.,][0-9]+)?\\s*(?:ml|L))", 40),
                                  ("origin", r"(?:Origem|Regi[ãa]o)\\s*:?\\s*([A-ZÀ-Ú][A-Za-zÀ-ÿ ]{3,40})", 60)):
                m = re.search(rx, spec_text, re.I)
                if m:
                    attrs[lab] = clean(m.group(1))[:cap]'''
new3 = '''            src_lines = spec if spec else vec
            attrs = {}
            for lab, rx, cap in (
                    ("grape", r"^Castas\\s*Uvas\\s*:?\\s*(.+)$", 90),
                    ("alcohol", r"^Teor\\s*alco[óo]lico\\s*:?\\s*([0-9]+(?:,[0-9]+)?\\s*%[vVwW/]*)", 40),
                    ("volume", r"^Volume\\s*:?\\s*([0-9]{1,2}\\s*[xX]\\s*[0-9]{2,4}\\s*ml|[0-9]+(?:[.,][0-9]+)?\\s*(?:ml|L))", 40),
                    ("origin", r"^(?:Origem|Regi[ãa]o)\\s*:?\\s*([A-ZÀ-Ú][A-Za-zÀ-ÿ ]{3,40})", 60)):
                for l in src_lines:
                    m = re.match(rx, clean(l["t"]), re.I)
                    if m:
                        attrs.setdefault(lab, clean(m.group(1))[:cap])
                        break
            if "grape" in attrs:  # "100% Carménere" -> capitaliza sem gritar
                attrs["grape"] = titleize(attrs["grape"])'''
assert old3 in s
s = s.replace(old3, new3)

open(p, "w").write(s)
print("ok")
