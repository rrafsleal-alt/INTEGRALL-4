import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

old = '''    pages = {}          # numero -> {"lines": [...], "codes": [(i, code)], "ctx": {...}}
    for page in doc:
        vec = dedupe_lines(raw_lines(page))
        if not vec:
            continue
        lines = sorted(vec, key=lambda z: (round(z["y0"] / 6), z["x0"]))
        pages[page.number + 1] = {"lines": lines, "codes": _imp_code_lines(lines)}'''
new = '''    ocr_all = {}
    try:
        ocr_all = {x["page"]: x["lines"] for x in json.load(open(f"{EXTRACT}/vinhosimportados.ocr.json"))}
    except Exception:
        ocr_all = {}

    def as_lines(rows):
        out = []
        for l in rows:
            t = clean(l.get("t") or "")
            if not t or float(l.get("c") or 0) < 0.5:
                continue
            out.append({"t": t, "x0": l["x0"], "y0": l["y0"], "x1": l["x1"], "y1": l["y1"],
                        "size": max(6.0, (l["y1"] - l["y0"]) * 0.85)})
        return out

    # numero -> {"lines", "codes", "ctx"}; paginas cuja ficha esta DENTRO da
    # imagem (sem texto vetor) sao lidas pelo OCR, senao fichas inteiras como as
    # de Cabriz/Pesca Da/La Vache Espagnole ficavam sem produto
    pages = {}
    for page in doc:
        pn = page.number + 1
        vec = dedupe_lines(raw_lines(page))
        lines = sorted(vec, key=lambda z: (round(z["y0"] / 6), z["x0"]))
        codes = _imp_code_lines(lines)
        src = "vetor"
        if not codes and pn in ocr_all:
            lines = sorted(as_lines(ocr_all[pn]), key=lambda z: (round(z["y0"] / 6), z["x0"]))
            lines = dedupe_lines(lines)
            codes = _imp_code_lines(lines)
            src = "ocr"
            if len(codes) < 1:
                continue
        elif not vec:
            continue
        pages[pn] = {"lines": lines, "codes": codes, "src": src}'''
assert old in s
s = s.replace(old, new)

# contexto: usar as proprias linhas da pagina (que ja podem ser OCR) como cabeçalho
s = s.replace('''        ocr_lines = sorted(ocr.get(pn, []), key=lambda z: z["y0"])
        ocr_head = clean(" ".join(l["t"] for l in ocr_lines[:3]))
        alltext = f"{head} {ocr_head} " + " ".join(l["t"] for l in info["lines"])''',
'''        ocr_lines = sorted(ocr_all.get(pn, []), key=lambda z: z["y0"])
        ocr_head = clean(" ".join(l.get("t", "") for l in ocr_lines[:3]))
        alltext = f"{head} {ocr_head} " + " ".join(l["t"] for l in info["lines"])''')

# passada 1/2: nao assumir que so pagina vetor tem ficha
s = s.replace('''        if re.search(r"(?i)(PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA ?DO ?SUL)",
                     f"{head} {ocr_head}") and (head.strip() or ocr_head.strip()):''',
'''        if re.search(r"(?i)(PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA ?DO ?SUL)",
                     f"{head} {ocr_head}") and (head.strip() or ocr_head.strip()):''')

# a ficha do PDF de rotulos rasterizados vem "COD500" colado no OCR -> aceita sem espaco
s = s.replace('''def _imp_code_lines(lines):
    out = []
    for i, l in enumerate(lines):
        m = re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*([0-9]{3})", clean(l["t"]))''',
'''def _imp_code_lines(lines):
    out = []
    for i, l in enumerate(lines):
        m = re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*([0-9]{3})", clean(l["t"]).replace(" ", ""))''')
s = s.replace('''            if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"])):
                    continue''', '''            if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"]).replace(" ", "")):
                    continue''')
s = s.replace('''                         if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"]))''',
              '''                         if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"]).replace(" ", ""))''')

open(p, "w").write(s)
print("importados: paginas com ficha rasterizada entram pelo OCR")
