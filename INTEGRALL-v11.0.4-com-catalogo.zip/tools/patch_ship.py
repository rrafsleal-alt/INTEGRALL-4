import re

p = "/home/user/work/tools/assemble.py"
s = open(p).read()

fn = '''def apply_shipping_defaults(p):
    """Peso e dimensoes minimos para o calculo de frete bater com a realidade.

    O site descarta a `box` se peso/medidas forem zero (src/catalog.js) e ai
    `src/correios.js` cai no padrao de 300 g / 16x11x10 — para uma caixa de
    biscoito de 2 kg ou garrafa de vinho isso cotaria frete de carta. Os PDFs
    trazem o PESO (ex.: "Caixa: 2 kg"), entao ele e copiado de la; o que nao
    existe no PDF (as medidas da caixa) vira estimativa por formato, marcada no
    relatorio para voce ajustar se a transportadora exigir.
    """
    filled = []
    dept = p.get("department") or ""
    unit = f"{p.get('unit') or ''} {p.get('name') or ''}"
    ml = re.search(r"([0-9]{2,4})\\s*ml", unit, re.I)
    vol = int(ml.group(1)) if ml else None
    kg = re.search(r"([0-9]+(?:[.,][0-9]+)?)\\s*kg", unit, re.I)
    box_kg = float(kg.group(1).replace(",", ".")) if kg else None

    if not p.get("weightGrams"):
        if dept == "petit-four":
            w = int(round((box_kg or 1.0) * 1000))
        elif dept == "cafes":
            w = 250
        elif dept == "sucos":
            w = max(320, int((vol or 1000) * 1.05))
        else:  # vinhos e espumantes: garrafa cheia + capsula
            w = {187: 450, 200: 470, 375: 800, 660: 1000, 750: 1450}.get(vol, 1450)
            if vol and vol >= 1000:
                w = int(vol * 1.3)
        if w:
            p["weightGrams"] = w
            filled.append("weightGrams")
    if not (p.get("lengthCm") and p.get("widthCm") and p.get("heightCm")):
        w = p.get("weightGrams") or 1000
        if dept == "petit-four":
            if w <= 1200:
                l, wd, h = 30, 22, 10
            elif w <= 1800:
                l, wd, h = 32, 24, 11
            elif w <= 2600:
                l, wd, h = 33, 24, 11
            else:
                l, wd, h = 38, 28, 16
        elif dept == "cafes":
            l, wd, h = 12, 8, 22
        elif dept == "sucos":
            l, wd, h = (10, 10, 23) if (vol or 1000) >= 900 else (8, 8, 17)
        else:
            if w >= 5000:                      # bag in box / galao
                l, wd, h = 22, 18, 30
            elif vol in (187, 200, 375):        # meia-garrafa
                l, wd, h = 7, 7, 21
            elif vol == 660:
                l, wd, h = 8, 8, 26
            elif vol and vol >= 1000:            # garrafa de 1 L
                l, wd, h = 9, 9, 32
            else:
                l, wd, h = 9, 9, 31
        p["lengthCm"], p["widthCm"], p["heightCm"] = l, wd, h
        filled += ["lengthCm", "widthCm", "heightCm"]
    return filled


'''
s = s.replace("def main():", fn + "def main():")

# aplica nos produtos novos, na montagem
old = '''    next_pos = max([int(p.get("position") or 0) for p in existing] or [0])
    for p in new_products:'''
new = '''    ship = 0
    for p in new_products:
        if apply_shipping_defaults(p):
            ship += 1

    next_pos = max([int(p.get("position") or 0) for p in existing] or [0])
    for p in new_products:'''
assert old in s
s = s.replace(old, new)
s = s.replace('''    rep["nomes_colidiram"] = collisions''',
              '''    rep["nomes_colidiram"] = collisions
    rep["completados_para_frete"] = ship''')
open(p, "w").write(s)
print("assemble: defaults de peso/medidas")

# ---------- auditoria: atribuir pagina por NOME tambem (produtos sem SKU) ------
p2 = "/home/user/work/tools/audit_products.py"
s2 = open(p2).read()
old2 = '''    page_by_sku = {}
    for b, lst in stages.items():
        for p in lst:
            if p.get("sku"):
                page_by_sku[(b, p["sku"])] = p.get("sourcePage")'''
new2 = '''    page_by_sku, page_by_name = {}, {}
    for b, lst in stages.items():
        for p in lst:
            if p.get("sku"):
                page_by_sku[(b, p["sku"])] = p.get("sourcePage")
            page_by_name[(b, flat(p.get("name") or ""))] = p.get("sourcePage")'''
assert old2 in s2
s2 = s2.replace(old2, new2)
old3 = '''        gen = collections.Counter(page_by_sku.get((bucket, p.get("sku")), None) for p in prods if p.get("sku"))'''
new3 = '''        def src_page(p):
            pg = page_by_sku.get((bucket, p.get("sku"))) if p.get("sku") else None
            if pg is None:
                nm = flat(p.get("name") or "")
                nm = re.sub(r"\\s*\\(c[óo]d\\.[^)]*\\)$", "", nm)
                pg = page_by_name.get((bucket, nm))
            return pg
        gen = collections.Counter(src_page(p) for p in prods)'''
assert old3 in s2
s2 = s2.replace(old3, new3)
# "pagina sem produto" so e suspeita se ela tem FICHAS (codigo ou bloco de nome),
# nao se so tem arte de capa/departamento
old4 = '''            if gp == 0 and (ph or pc) and bucket in ("biscoitos", "nacionais"):'''
new4 = '''            if gp == 0 and (ph or pc) and pc > 0:'''
assert old4 in s2
s2 = s2.replace(old4, new4)
# e as paginas de capa, para transparencia, entram como nota (nao como alerta)
s2 = s2.replace('''        R["paginas"].append({"bucket": bucket, "pagina": pn, "fotos": ph, "codigos": pc,
                                     "observacao": "nenhum produto com sku desta pagina"})''',
'''        R["paginas"].append({"bucket": bucket, "pagina": pn, "fotos": ph, "codigos": pc,
                                     "observacao": "pagina sem ficha (capa/departamento)"})''')
s2 = s2.replace('''            if gp == 0 and (ph or pc) and pc > 0:''',
'''            if gp == 0 and (ph or pc) and pc > 0:
                R["paginas"].append({"bucket": bucket, "pagina": pn, "fotos": ph, "codigos": pc,
                                     "observacao": "TEM codigos e nenhuma ficha — PERDA REAL"})
            elif ph and gp == 0:
                continue''')
s2 = s2.replace('''                R["paginas"].append({"bucket": bucket, "pagina": pn, "fotos": ph, "codigos": pc,
                                     "observacao": "pagina sem ficha (capa/departamento)"})
''', '')
open(p2, "w").write(s2)
print("audit: atribuicao por nome + so alerta pagina com codigos")
