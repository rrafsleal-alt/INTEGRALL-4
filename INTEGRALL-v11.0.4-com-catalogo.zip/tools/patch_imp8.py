import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# --- A) bloco da ficha termina no proximo codigo da MESMA coluna ---
old = '''            spec = []
            for l in lines:
                if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"])):
                    continue
                if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and 2 <= l["y0"] - cy <= 70:
                    spec.append(l)'''
new = '''            col_codes = sorted((l["y0"] for l in lines
                                if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"]))
                                and abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and l["y0"] > cy + 2),
                               default=cy + 90)
            bottom = min(col_codes) - 2 if col_codes else cy + 90
            spec = [l for l in lines
                    if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and 2 <= l["y0"] - cy <= bottom - cy]'''
assert old in s
s = s.replace(old, new)

# --- B) origem/pais:先看 o bloco do proprio rotulo, depois a pagina, so ai o contexto ---
old2 = '''            if c["region"] and "origin" not in attrs:
                attrs["origin"] = c["region"]'''
new2 = '''            # regiao/pais do PROPRIO bloco quando existirem (o contexto da secao
            # pode vazar de uma pagina para a seguinte)
            geo_block = re.search(r"(?:D\\.O\\.?|DOC|DOCg)?\\s*("
                                  r"VALLE CENTRAL|MENDOZA|WESTERN CAPE|CANTANHEDE|BAIRRADA|BEIRA ATL[ÃA]NTICO|"
                                  r"ALLENDE RIBERA|EXTREMADURA|LANGUEDOC|COTES? DU RHONE|DOURO|VERDE|LISBOA|"
                                  r"ALENTEJO|ABRUZZO|LOMBARDIA|VENETO|SICILIA|MARGAUX|HAUT-MEDOC)",
                                  blob or "", re.I)
            if geo_block:
                attrs["origin"] = titleize(clean(re.sub(r"(?i)^D\\.O\\.?\\s*|^DOC\\s*", "", geo_block.group(1))))
            elif c["region"]:
                attrs.setdefault("origin", c["region"])'''
assert old2 in s
s = s.replace(old2, new2)

# country: bloco/pagina mandam sobre o contexto
old3 = '''                "sku": code, "imported": True, "country": c["country"], "region": c["region"],'''
new3 = '''                _ct = re.search(r"(?i)(PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA ?DO ?SUL)",
                                (blob or "") + " " + " ".join(l["t"] for l in pages[pn]["lines"]))
                _country = {"PORTUGAL": "Portugal", "FRANÇA": "França", "FRANCE": "França", "CHILE": "Chile",
                            "ESPANHA": "Espanha", "ITALIA": "Itália", "ARGENTINA": "Argentina",
                            "AFRICA DO SUL": "África do Sul"}.get(_ct.group(1).upper() if _ct else "", c["country"])
                "sku": code, "imported": True, "country": _country, "region": c["region"],'''
assert old3 in s
s = s.replace(old3, new3)

# --- C) produtores canonicos (o PDF os escreve; so uniformizamos caixa/espaco) ---
old4 = '''            raw_brand = c["producer"] or c["line"] or ""'''
new4 = '''            KNOWN = ["Vidigal Wines", "Adega de Cantanhede", "Bodega Cono Sur", "Stormhoek",
                    "Global Wines", "Da Pipa", "Castillo de Andrade", "Martha's", "Bodega RPB",
                    "Newroads", "3 Autores", "Porta 6", "Julia Florista", "Artolas", "Capricho",
                    "Intimista"]  # so nomes que de fato aparecem no texto/OCR do PDF
            raw_brand = c["producer"] or c["line"] or ""
            _flat = re.sub(r"[^A-Z]", "", raw_brand.upper())
            for _k in KNOWN:
                if re.sub(r"[^A-Z]", "", _k.upper()) in _flat:
                    raw_brand = _k
                    break'''
assert old4 in s
s = s.replace(old4, new4)

open(p, "w").write(s)
print("ok")
