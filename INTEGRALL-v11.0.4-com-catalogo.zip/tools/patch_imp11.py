import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# --- 1) off-by-one: a pagina de abertura vale para ELA MESMA, nao so para a seguinte
old = '''    for pn in sorted(pages):
        info = pages[pn]
        info["ctx"] = dict(ctx)
        top = sorted(info["lines"], key=lambda z: z["y0"])'''
new = '''    for pn in sorted(pages):
        info = pages[pn]
        top = sorted(info["lines"], key=lambda z: z["y0"])'''
assert old in s
s = s.replace(old, new)

old2 = '''        if m:
            ctx["region"] = titleize(clean(m.group(1)))

    # ------------------------------ passada 1: fichas'''
new2 = '''        if m:
            ctx["region"] = titleize(clean(m.group(1)))
        # o contexto vale daqui para frente; a pagina que traz o cabecalho usa o
        # cabecalho DELA (folhas de rotulo podem ser de outro pais)
        info["ctx"] = dict(ctx)

    # ------------------------------ passada 1: fichas'''
assert old2 in s
s = s.replace(old2, new2)
# se a pagina nao atualizou nada, garante que info["ctx"] exista
s = s.replace('''        if m:
            ctx["region"] = titleize(clean(m.group(1)))
        info["ctx"] = dict(ctx)
        producer = producer or ctx["producer"]''',
'''        if m:
            ctx["region"] = titleize(clean(m.group(1)))
        info["ctx"] = dict(ctx)
        producer = producer or ctx["producer"]''')
s = s.replace('''        m = re.search(r"(VALLE CENTRAL|BEIRA ATL[ÃA]NTICO''',
              '''        info.setdefault("ctx", dict(ctx))
        m = re.search(r"(VALLE CENTRAL|BEIRA ATL[ÃA]NTICO''')

# --- 2) pais/regiao: bloco do produto -> texto da pagina -> contexto da secao
old3 = '''            own = (d or {}).get("blk", "")
            # janela em volta do codigo: ha paginas com secoes de dois paises,
            # e "a pagina inteira" daria o pais errado para metade dos rotulos
            win = [l for l in pages[pn]["lines"]
                   if abs(l["x0"] - a["x"]) < 190 and -200 <= l["y0"] - a["y"] <= 130]
            own = (own + " " + " ".join(l["t"] for l in win)).strip()
            page_txt = own'''
new3 = '''            own = (d or {}).get("blk", "")
            # janela em volta do codigo: ha paginas com rotulos de dois paises,
            # entao "a pagina inteira" daria pais errado para metade deles
            win = [l for l in pages[pn]["lines"]
                   if abs(l["x0"] - a["x"]) < 190 and -200 <= l["y0"] - a["y"] <= 130]
            own = (own + " " + " ".join(l["t"] for l in win)).strip()
            page_txt = " ".join(l["t"] for l in pages[pn]["lines"])'''
assert old3 in s
s = s.replace(old3, new3)

# --- 3) se a PROPRIA pagina nomeia um pais, ele manda sobre o contexto herdado
old4 = '''                            own + " " + page_txt)'''
new4 = '''                            own or page_txt)'''
assert old4 in s
s = s.replace(old4, new4)

# regiao: window/block > pagina > ctx, e ctx so vale se nao ha regiao na pagina
old5 = '''            elif c["region"]:
                attrs.setdefault("origin", c["region"])'''
new5 = '''            else:
                geo_page = re.search(r"(?i)(VALLE CENTRAL|MENDOZA|WESTERN CAPE|CANTANHEDE|BAIRRADA|"
                                      r"BEIRA ATL[ÃA]NTICO|EXTREMADURA|LANGUEDOC|COTES? ?DU ?RHONE|DOURO|"
                                      r"VERDE|ALENTEJO|ABRUZZO|LOMBARDIA|VENETO|SICILIA|\\bDAO\\b)", page_txt)
                if geo_page:
                    attrs["origin"] = titleize(clean(geo_page.group(1)))
                elif c["region"]:
                    attrs["origin"] = c["region"]'''
assert old5 in s
s = s.replace(old5, new5)

open(p, "w").write(s)
print("ok")
