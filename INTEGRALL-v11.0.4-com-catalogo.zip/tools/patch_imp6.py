import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()
start = s.index("def parse_importados():")
end = s.index('if __name__ == "__main__":')

fn = '''def _imp_code_lines(lines):
    out = []
    for i, l in enumerate(lines):
        m = re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*([0-9]{3})", clean(l["t"]))
        if m:
            out.append((i, m.group(1)))
    return out


def _imp_label_like(t, page_top=1e9, y=0):
    t = clean(t)
    if not t or len(t) < 5 or len(t) > 70:
        return False
    if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", t, re.I):
        return False
    if IMP_NOISE.match(t) or IMP_SKIP.fullmatch(t.upper().strip()):
        return False
    # cabeçalho de seção ("PORTUGAL . BARRADA . ... . DA PIPA") nunca é nome de rótulo
    if y - page_top < 40 and re.search(r"\\.|PORTUGAL|CHILE|ESPANHA|ITALIA|ARGENTINA|FRAN", t, re.I):
        return False
    return bool(re.search(r"[A-Za-zÀ-ÿ]{4}", t))


def parse_importados():
    """Catálogo de importados.

    O PDF tem dois tipos de página:
      * "folha de etiquetas": grade de rótulos desenhados, cada um com um
        "C[ÓO]D nnn" embaixo — o país/vinícola está na página de abertura da
        seção (às vezes só na imagem);
      * página de ficha: "NOME DO RÓTULO" na linha ao lado do "C[ÓO]D nnn",
        seguido de Teor alcoólico / Volume / Castas Uvas.

    Duas passadas: primeiro juntamos as fichas (fonte confiável de nome),
    depois varremos todos os códigos de todas as páginas — assim um código que
    aparece na etiqueta E na ficha vira UM produto, com nome da ficha e foto da
    etiqueta. A foto de cada garrafa é recortada entre os pontos médios dos
    códigos vizinhos, porque a grade inteira é uma imagem só.
    """
    doc = pymupdf.open(f"{PDF}/Vinhos importados_compressed.pdf")
    ocr = {}
    try:
        ocr = {x["page"]: x["lines"] for x in json.load(open(f"{EXTRACT}/vinhosimportados.ocr.json"))}
    except Exception:
        pass

    pages = {}          # numero -> {"lines": [...], "codes": [(i, code)], "ctx": {...}}
    for page in doc:
        vec = dedupe_lines(raw_lines(page))
        if not vec:
            continue
        lines = sorted(vec, key=lambda z: (round(z["y0"] / 6), z["x0"]))
        pages[page.number + 1] = {"lines": lines, "codes": _imp_code_lines(lines)}

    # ---------- contexto por secao (pagina de abertura -> folhas seguintes) ----
    geo = re.compile(r"PORTUGAL|FRAN[ÇC]A|CHILE|ESPANHA|ITALIA|ARGENTINA|AFRICA|WESTERN|CAPE|"
                     r"LISBOA|VERDE|DOURO|\\bDAO\\b|BEIRA|ATLANTICO|CANTANHEDE|LEIRIA|ALENTEJO|"
                     r"BAIRRADA|LANGUEDOC|ROUSSILLON|RHONE|EXTREMADURA|WINES|VINICOLA|ADEGA|"
                     r"BODEGA|GLOBAL|CENTRAL|VALLE|\\bDOC\\b|D\\.O|AZIENDA|CANTINE|CASTILLO|"
                     r"MENDOZA|ABRUZZO|LOMBARDIA|VENETO|SICILIA|COLHEITA|SELECIONADA", re.I)
    ctx = {"producer": "", "line": "", "country": "", "region": ""}
    for pn in sorted(pages):
        info = pages[pn]
        info["ctx"] = dict(ctx)
        top = sorted(info["lines"], key=lambda z: z["y0"])
        head = clean(" ".join(l["t"] for l in top[:3]))
        ocr_lines = sorted(ocr.get(pn, []), key=lambda z: z["y0"])
        ocr_head = clean(" ".join(l["t"] for l in ocr_lines[:3]))
        alltext = f"{head} {ocr_head} " + " ".join(l["t"] for l in info["lines"])
        m = re.search(r"(VIN[ÍI]COLA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|VINICOLA[A-ZÀ-Ú][A-ZÀ-ÿ ]{2,20}|"
                      r"ADEGA DE [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|BODEGA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|"
                      r"AZIENDA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,25}|CASTILLO DE [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,20}|"
                      r"CANTINA [A-ZÀ-Ú][A-ZÀ-ÿ ]{2,20}|[A-ZÀ-Ú][A-ZÀ-ÿ ]{3,20}WINES)",
                      f"{head} {ocr_head}".upper(), re.I)
        if m:
            ctx["producer"] = clean(m.group(1)).title()
        for l in top[:4] + ocr_lines[:3]:
            raw = clean(l["t"])
            if raw.count(".") < 2 and len(raw.split()) < 3:
                continue
            parts = [x.strip() for x in re.split(r"[.]+", raw.upper()) if x.strip()]
            tail = [x for x in parts if not geo.search(x)]
            if tail:
                ctx["line"] = clean(" ".join(tail[:2])).title()
                break
        for k, c in ((r"\\bPORTUGAL\\b", "Portugal"), (r"FRAN[ÇC]A|FRANCE", "França"),
                     (r"\\bCHILE\\b", "Chile"), (r"\\bESPANHA\\b", "Espanha"),
                     (r"\\bITALIA\\b", "Itália"), (r"\\bARGENTINA\\b", "Argentina"),
                     (r"AFRICA ?DO ?SUL", "África do Sul")):
            if re.search(k, alltext, re.I):
                ctx["country"] = c
                break
        m = re.search(r"(VALLE CENTRAL|BEIRA ATL[ÃA]NTICO|LANGUEDOC ?ROUSSILLON|COTES ?DU ?RHONE|"
                      r"EXTREMADURA|WESTERN CAPE|MENDOZA|ABRUZZO|LOMBARDIA|DOC ?VERDE|ALENTEJO|"
                      r"\\bDOURO\\b|LISBOA|BAIRRADA|CANTANHEDE|\\bDAO\\b)", alltext, re.I)
        if m:
            ctx["region"] = titleize(clean(m.group(1)))

    # ------------------------------ passada 1: fichas -------------------------
    detail = {}
    for pn, info in pages.items():
        lines, codes = info["lines"], info["codes"]
        page_top = min(l["y0"] for l in lines) if lines else 0
        for k, (i, code) in enumerate(codes):
            prev, py = (lines[i - 1]["t"], lines[i - 1]["y0"]) if i else ("", 0)
            if not _imp_label_like(prev, page_top, py) and i + 1 < len(lines) \\
               and _imp_label_like(lines[i + 1]["t"], page_top, lines[i + 1]["y0"]):
                prev, py = lines[i + 1]["t"], lines[i + 1]["y0"]
            if not _imp_label_like(prev, page_top, py):
                continue
            stop = codes[k + 1][0] if k + 1 < len(codes) else len(lines)
            spec = []
            for l in lines[i + 1:stop]:
                if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", clean(l["t"])):
                    break
                spec.append(l)
            for l in lines[max(0, i - 3):i]:
                if _imp_label_like(l["t"], page_top, l["y0"]):
                    spec.append(l)
            attrs = {}
            for lab, rx, cap in (
                    ("grape", r"^Castas\\s*Uvas\\s*:?\\s*(.+)$", 90),
                    ("alcohol", r"^Teor\\s*alco[óo]lico\\s*:?\\s*([0-9]+(?:,[0-9]+)?\\s*%[vVwW/]*)", 40),
                    ("volume", r"^Volume\\s*:?\\s*([0-9]{1,2}\\s*[xX]\\s*[0-9]{2,4}\\s*ml|"
                              r"[0-9]{1,2}\\s*[xX]\\s*[0-9]{2,4}\\s*[cC][lL]|[0-9]+(?:[.,][0-9]+)?\\s*(?:ml|L))", 40),
                    ("origin", r"^(?:Origem|Regi[ãa]o|D\\.O\\.?)\\s*:?\\s*([A-ZÀ-Ú][A-Za-zÀ-ÿ ]{3,40})", 60)):
                for l in spec:
                    m = re.match(rx, clean(l["t"]), re.I)
                    if m:
                        attrs.setdefault(lab, clean(m.group(1))[:cap])
                        break
            blob = " ".join(clean(l["t"]) for l in spec)
            m = re.search(r"Teor\\s*alco[óo]lico\\s*:?\\s*([0-9]+(?:,[0-9]+)?\\s*%)", blob, re.I)
            if m and "alcohol" not in attrs:
                attrs["alcohol"] = clean(m.group(1))
            m = re.search(r"Volume\\s*:?\\s*([0-9]{1,2}\\s*[xX]\\s*[0-9]{2,4}\\s*ml)", blob, re.I)
            if m and "volume" not in attrs:
                attrs["volume"] = clean(m.group(1))
            if "grape" in attrs:
                attrs["grape"] = titleize(re.split(r"(?i)\\bcastas\\b", attrs["grape"])[0])
            name = titleize(re.sub(r"\\s*\\.\\s*", ". ", clean(prev))[:120])
            cur = detail.get(code)
            if not cur or (cur["name"].startswith(("Vinho", "Da pipa")) and not name.startswith("Vinho")):
                detail[code] = {"name": name, "attrs": attrs, "page": pn, "x": (lines[i]["x0"] + lines[i]["x1"]) / 2,
                                "trusted": True}

    # --------------------- passada 2: todo codigo vira 1 produto ---------------
    products, ids, seen_code = [], set(), set()
    for pn, info in pages.items():
        lines, codes = info["lines"], info["codes"]
        if not codes:
            continue
        c = info["ctx"]
        anchors = []
        for i, code in codes:
            if code in seen_code:
                continue
            seen_code.add(code)
            anchors.append({"code": code, "i": i,
                            "x": (lines[i]["x0"] + lines[i]["x1"]) / 2, "y": lines[i]["y0"]})
        if not anchors:
            continue
        imgs = page_images(doc[pn - 1])
        ocr_lines = sorted(ocr.get(pn, []), key=lambda z: z["y0"])
        sheet = len(anchors) >= 2
        for a in anchors:
            code = a["code"]
            d = detail.get(code)
            trusted = bool(d and d.get("trusted"))
            if trusted:
                nm, attrs = d["name"], dict(d["attrs"])
            else:
                nm = ""
                attrs = {}
            fb = titleize(c["producer"] or c["line"] or "")
            ocr_guess = ""
            if not nm:
                near = [l for l in ocr_lines
                        if abs((l["x0"] + l["x1"]) / 2 - a["x"]) < 90 and a["y"] - 130 <= l["y0"] <= a["y"] + 40]
                lab = clean(" ".join(l["t"] for l in near))
                lab = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", lab, flags=re.I)
                lab = re.sub(r"(?i)\\b(teor|volume|origem|castas|uvas|gradua|alco[o6ú]ol|produtor|"
                             r"regiao|safra|premio|award|medal)\\w*.*$", " ", lab)
                lab = re.sub(r"\\d{1,2}[.,]\\d\\s*%?", " ", lab)
                lab = re.sub(r"\\d{1,2}\\s*[xX]\\s*\\d{3}\\s*ml", " ", lab, flags=re.I)
                lab = clean(re.sub(r"[^A-Za-zÀ-ÿ()'&./\\- ]", " ", lab))
                if 6 <= len(lab) <= 55 and re.search(r"[A-Za-zÀ-ÿ]{4,}\\s+\\S", lab) \\
                   and not re.search(r"(?i)(wine|blanc|rouge|produto|importad|portugu)", lab):
                    ocr_guess = lab
                nm = f"{fb} — código {code}" if fb else f"Vinho importado — código {code}"
            pid = f"pdf-imp-{code}"
            if pid in ids:
                continue
            ids.add(pid)
            # ----- foto: na grade, recorta so a garrafa do codigo --------------
            img = None
            page = doc[pn - 1]
            if sheet and imgs:
                row = sorted([z for z in anchors if abs(z["y"] - a["y"]) < 60], key=lambda z: z["x"])
                col = sorted(anchors, key=lambda z: z["y"])
                bx = [min(i2["bbox"][0] for i2 in imgs), min(i2["bbox"][1] for i2 in imgs),
                      max(i2["bbox"][2] for i2 in imgs), max(i2["bbox"][3] for i2 in imgs)]
                k = row.index(a)
                left = bx[0] if k == 0 else (row[k - 1]["x"] + a["x"]) / 2
                right = bx[2] if k == len(row) - 1 else (a["x"] + row[k + 1]["x"]) / 2
                j = col.index(a)
                top = bx[1] if j == 0 else (col[j - 1]["y"] + a["y"]) / 2
                rect = pymupdf.Rect(max(bx[0], left - 8), max(bx[1], top - 6),
                                    min(bx[2], right + 8), min(bx[3], a["y"] + 16))
                if rect.width > 40 and rect.height > 40:
                    img = crop_save(page, tuple(rect), f"importado-{code}")
            if not img:
                im = match_image(page, imgs, a["x"], a["y"] - (120 if not sheet else 40), band=90_000)
                if im:
                    img = crop_save(page, im["bbox"], f"importado-{code}")
            unit = attrs.get("volume") or "750ml"
            if "x" in str(unit).lower():
                attrs["quantity"] = unit
                m = re.search(r"([0-9]{2,4})\\s*ml", str(unit), re.I)
                unit = f"{m.group(1)}ml" if m else "750ml"
            if c["region"] and "origin" not in attrs:
                attrs["origin"] = c["region"]
            desc = (f"{nm}. " if trusted else
                    f"Rótulo do catálogo de importados, código {code}"
                    + (f" (linha {fb})" if fb else "") + ". ")
            if trusted:
                bits = []
                for lab, key in (("Uva", "grape"), ("Teor alcoólico", "alcohol"),
                                 ("Volume", "volume"), ("Origem", "origin")):
                    if attrs.get(key):
                        bits.append(f"{lab}: {attrs[key]}")
                if c["country"]:
                    bits.append(f"País: {c['country']}")
                desc += "; ".join(bits) + "." if bits else "Especificações lidas do catálogo."
            else:
                desc += ("Nome não recuperado do PDF — a etiqueta é arte sem texto e vários "
                         "códigos dividem a mesma imagem.")
                if ocr_guess:
                    desc += f" Hipótese de leitura da etiqueta: “{ocr_guess}”."
                desc += " Ajuste o nome no Admin."
            products.append({
                "id": pid, "name": nm[:150], "department": "vinhos",
                "subcategory": "Vinhos Importados", "brand": fb[:110],
                "sku": code, "imported": True, "country": c["country"], "region": c["region"],
                "price": 0, "unit": f"Garrafa {unit}",
                "description": clean(desc)[:1200],
                "images": [img] if img else [], "attributes": attrs,
                "weightGrams": 1450, "lengthCm": 9, "widthCm": 9, "heightCm": 31,
                "stock": None, "stockMin": None,
                "available": False, "hidden": False, "featured": False,
                "madeToOrder": False, "seasonal": False, "giftEnabled": True,
                "source": f"pdf:importados ({'ficha do PDF' if trusted else 'marca da seção + código'})",
                "sourcePage": pn, "_needsReview": (not trusted),
            })
    return products


'''
s = s[:start] + fn + s[end:]
open(p, "w").write(s)
print("parse_importados reescrito:", len(fn.splitlines()), "linhas")
