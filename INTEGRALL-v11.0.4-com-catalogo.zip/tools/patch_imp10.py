import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

STYLE = r"(?i)^(tinto|branco|rose|ros[eé]|rosado|espumante|espalhante|demi|seco|suave|doce|dry|brut|extra\s*brut|tinto\s*seco|branco\s*seco)\.?$"

# ---------- A) nome: escolher a linha de ROTULO, nao a linha de estilo --------
old = '''            cand = [l for l in lines
                    if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and l is not ref
                    and -22 <= l["y0"] - cy <= 4 and _imp_label_like(l["t"], page_top, l["y0"])]
            cand.sort(key=lambda l: abs(l["y0"] - cy))
            if cand:
                prev, py = cand[0]["t"], cand[0]["y0"]
            else:'''
new = '''            cand = [l for l in lines
                    if abs((l["x0"] + l["x1"]) / 2 - cx) < 120 and l is not ref
                    and -60 <= l["y0"] - cy <= 4 and _imp_label_like(l["t"], page_top, l["y0"])]
            style = ""
            if any(re.match(STYLE, clean(l["t"]).strip()) for l in cand):
                style = next(clean(l["t"]) for l in cand if re.match(STYLE, clean(l["t"]).strip()))
                cand = [l for l in cand if not re.match(STYLE, clean(l["t"]).strip())]
            cand.sort(key=lambda l: l["y0"])          # o rotulo e a linha mais acima
            prev, py = (cand[-1]["t"], cand[-1]["y0"]) if cand else ("", 0)
            page_style = style
            if not cand:'''
assert old in s
s = s.replace(old, new)
s = s.replace('''                below.sort(key=lambda l: abs(l["y0"] - cy))
                prev, py = (below[0]["t"], below[0]["y0"]) if below else ("", 0)''',
'''                below.sort(key=lambda l: abs(l["y0"] - cy))
                prev, py = (below[0]["t"], below[0]["y0"]) if below else ("", 0)''')
# guarda o estilo (Tinto/Branco) na ficha
s = s.replace('''            detail[code] = {"name": name, "attrs": attrs, "page": pn,''',
'''            if page_style:
                attrs["wineType"] = titleize(clean(page_style))
            detail[code] = {"name": name, "attrs": attrs, "page": pn,''')
s = s.replace('''        for k, (i, code) in enumerate(codes):
            ref = lines[i]''', '''        page_style = ""
        for k, (i, code) in enumerate(codes):
            ref = lines[i]''')

# ---------- B) nomes colados pelo OCR: destacar palavras e siglas ------------
old2 = '''            name = titleize(re.sub(r"\\s*\\.\\s*", ". ", clean(prev))[:120])'''
new2 = '''            name = _imp_readable(prev, pages[pn].get("src") == "ocr")'''
assert old2 in s
s = s.replace(old2, new2)

helper = '''def _imp_readable(t, glued=False):
    """Arruma texto de rotulo: OCR cola as palavras ('Pescadabranco,docverde')."""
    t = clean(t)
    if glued:
        t = re.sub(r",", ", ", t)
        t = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", t)
        t = re.sub(r"(?i)\\bdoc\\b", "DOC", t)
        t = re.sub(r"(?i)\\bdao\\b", "Dão", t)
        t = re.sub(r"(?i)\\b(doc ?verde|verde)\\b", lambda m: "DOC Verde" if "doc" in m.group(1).lower() else m.group(1), t)
        t = re.sub(r"(?i)\\bcolheita ?selecionada\\b", "Colheita Selecionada", t)
        t = re.sub(r"(?i)\\b(la ?vache)\\b", "La Vache", t)
        t = re.sub(r"(?i)\\bespagnole\\b", "Espagnole", t)
        t = re.sub(r"(?i)\\bpesca ?da\\b", "Pesca Da", t)
        t = re.sub(r"(?i)\\bcabriz\\b", "Cabriz", t)
    t = re.sub(r"\\s*\\.\\s*", ". ", t)
    t = re.sub(r"\\s*\\|\\s*", " — ", t)
    t = re.sub(r"\\s+", " ", t).strip(" .,")
    out = titleize(t)
    for sig in ("DOC", "D.O.", "I.G.P.", "BIO", "VDP", "IGP"):
        out = re.sub(r"(?i)\\b" + re.escape(sig) + r"\\b", sig, out)
    out = re.sub(r"(?i)\\bdao\\b", "Dão", out)
    return out[:120]


'''
anchor = "def _imp_code_lines(lines):"
assert anchor in s
s = s.replace(anchor, helper + anchor, 1)

# ---------- C) pais/regiao do produto, nao da pagina (paginas sao mistas) ----
old3 = '''            own = (d or {}).get("blk", "")
            page_txt = " ".join(l["t"] for l in pages[pn]["lines"])'''
new3 = '''            own = (d or {}).get("blk", "")
            # janela em volta do codigo: ha paginas com secoes de dois paises,
            # e "a pagina inteira" daria o pais errado para metade dos rotulos
            win = [l for l in pages[pn]["lines"]
                   if abs(l["x0"] - a["x"]) < 190 and -200 <= l["y0"] - a["y"] <= 130]
            own = (own + " " + " ".join(l["t"] for l in win)).strip()
            page_txt = own'''
assert old3 in s
s = s.replace(old3, new3)

# fallback (sem ficha): nome a partir da linha de rotulo mais proxima na janela
old4 = '''                nm = f"{fb} — código {code}" if fb else f"Vinho importado — código {code}"'''
new4 = '''                if not nm:
                    near_lbl = [l for l in win if _imp_label_like(l["t"], 0, l["y0"] + 200)
                                and not re.match(STYLE_RE, clean(l["t"]).strip())
                                and abs((l["x0"] + l["x1"]) / 2 - a["x"]) < 150]
                    near_lbl.sort(key=lambda l: l["y0"])
                    if near_lbl:
                        nm = _imp_readable(near_lbl[-1]["t"], pages[pn].get("src") == "ocr")
                        trusted = False
                if not nm:
                    nm = f"{fb} — código {code}" if fb else f"Vinho importado — código {code}"'''
assert old4 in s
s = s.replace(old4, new4)
s = s.replace('''            if not nm:
                near = [l for l in ocr_lines''', '''            if not nm:
                near = [l for l in ocr_lines''')
s = s.replace("import re, os, sys, json, unicodedata",
              "import re, os, sys, json, unicodedata")
s = s.replace('''STYLE = ''', '''STYLE = ''')
# constante de estilo reutilizavel no modulo
s = s.replace("def _imp_readable(t, glued=False):",
              'STYLE_RE = re.compile(r"(?i)^(tinto|branco|rose|ros[eé]|espumante|demi|seco|suave|doce|dry|brut|extra brut)\\.?$")\n\n\ndef _imp_readable(t, glued=False):')
open(p, "w").write(s)
print("ok")
