import re

p = "/home/user/work/tools/build2.py"
s = open(p).read()

# --- 1) nome vetorial: aceita linha ANTES ou DEPOIS do "C[ÓO]D nnn" ---
old = '''        detail = []
        for k, (i, code) in enumerate(cod_idx):
            prev = lines[i - 1]["t"] if i else ""
            if prev and not IMP_NOISE.match(prev) and re.search(r"[A-Za-zÀ-ÿ]{4}", prev) \\
               and not IMP_SKIP.fullmatch(prev.upper().strip()):'''
new = '''        def label_like(t):
            t = clean(t)
            if not t or len(t) < 5 or len(t) > 70:
                return False
            if re.fullmatch(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", t, re.I):
                return False
            if IMP_NOISE.match(t) or IMP_SKIP.fullmatch(t.upper().strip()):
                return False
            return bool(re.search(r"[A-Za-zÀ-ÿ]{4}", t))

        detail = []
        for k, (i, code) in enumerate(cod_idx):
            prev = lines[i - 1]["t"] if i else ""
            if not label_like(prev) and i + 1 < len(lines) and label_like(lines[i + 1]["t"]):
                prev = lines[i + 1]["t"]
            if prev and label_like(prev):'''
assert old in s
s = s.replace(old, new)

# --- 2) modo "vector" vale a partir de 1 codigo com nome, nao 2 ---
s = s.replace('''        codes = sorted({d["code"] for d in detail})
        seen, anchors = set(), []
        if len(detail) >= 2:''',
'''        seen, anchors = set(), []
        if detail:''')

# --- 3) importados: nunca chutar nome por OCR; usar marca da pagina + codigo ---
old3 = '''            if not trusted:
                near = [l for l in ocr_lines
                        if abs((l["x0"] + l["x1"]) / 2 - a["x"]) < 100
                        and a["y"] - 150 <= l["y0"] <= a["y"] + 45]
                lab = clean(" ".join(l["t"] for l in near))
                lab = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", lab, flags=re.I)
                lab = re.sub(r"(?i)\\b(teor|volume|origem|castas|uvas|gradua|alco[o6ú]ol|"
                             r"produtor|regiao|safra|premio|award|medal|pts)\\w*.*$", " ", lab)
                lab = re.sub(r"\\d{1,2}[.,]\\d\\s*%?", " ", lab)
                lab = re.sub(r"\\d{1,2}\\s*[xX]\\s*\\d{3}\\s*ml", " ", lab, flags=re.I)
                lab = re.sub(r"[^A-Za-zÀ-ÿ()'&./\\- ]", " ", lab)
                lab = clean(re.sub(r"\\s+", " ", lab))
                # aceita OCR so quando parece rotulo de verdade: 2+ palavras, sem lixo
                if len(lab) >= 6 and len(lab) <= 58 and re.search(r"[A-Za-zÀ-ÿ]{4,}\\s+\\S", lab) \\
                   and not re.search(r"(?i)(wine|blanc|rouge|produto|sinieee|pbeter|hosi|sl\\b|a01)", lab):
                    name, trusted = lab, False  # ainda marcado como OCR'''
new3 = '''            if not trusted:
                # nas "folhas de rotulo" varios codicos dividem a mesma imagem,
                # entao nao ha como atribuir um recorte de OCR a um codigo com
                # seguranca. Guardamos a hipese na descricao, nunca no nome.
                near = [l for l in ocr_lines
                        if abs((l["x0"] + l["x1"]) / 2 - a["x"]) < 100
                        and a["y"] - 150 <= l["y0"] <= a["y"] + 45]
                lab = clean(" ".join(l["t"] for l in near))
                lab = re.sub(r"C[ÓO]D\\.?\\s*:?\\s*[0-9]{3}", " ", lab, flags=re.I)
                lab = re.sub(r"(?i)\\b(teor|volume|origem|castas|uvas|gradua|alco[o6ú]ol|"
                             r"produtor|regiao|safra|premio|award|medal|pts)\\w*.*$", " ", lab)
                lab = re.sub(r"\\d{1,2}[.,]\\d\\s*%?", " ", lab)
                lab = re.sub(r"\\d{1,2}\\s*[xX]\\s*\\d{3}\\s*ml", " ", lab, flags=re.I)
                lab = re.sub(r"[^A-Za-zÀ-ÿ()'&./\\- ]", " ", lab)
                lab = clean(re.sub(r"\\s+", " ", lab))
                if 6 <= len(lab) <= 58 and re.search(r"[A-Za-zÀ-ÿ]{4,}\\s+\\S", lab) \\
                   and not re.search(r"(?i)(wine|blanc|rouge|produto|sinieee|pbeter|hosi|a01)", lab):
                    ocr_guess = lab'''
assert old3 in s
s = s.replace(old3, new3)

s = s.replace('''            fb = titleize(producer or line_brand or "")''',
'''            fb = titleize(producer or line_brand or "")
            ocr_guess = ""''')
s = s.replace('''            if name:
                nm = titleize(re.sub(r"\\s*\\.\\s*", ". ", name)[:120])''',
'''            if name:
                nm = titleize(re.sub(r"\\s*\\.\\s*", ". ", name)[:120])''')

old4 = '''            src = "texto do PDF" if trusted else "OCR da etiqueta"
            desc = (f"{nm}. " if name else
                    f"Rótulo do catálogo de importados, código {a['code']}"
                    + (f" (linha {fb})" if fb else "") + ". ")
            desc += (f"Especificações lidas do catálogo ({src})."
                     if name else
                     "Nome não recuperado do PDF (etiqueta sem texto); complete no Admin.")'''
new4 = '''            src = "texto do PDF" if trusted else "marca da página + código"
            desc = (f"{nm}. " if name else
                    f"Rótulo do catálogo de importados, código {a['code']}"
                    + (f" (linha {fb})" if fb else "") + ". ")
            if name:
                desc += f"Especificações lidas do catálogo ({src})."
            else:
                desc += ("Nome não recuperado do PDF — a etiqueta é imagem e vários códigos"
                         " dividem a mesma arte.")
                if ocr_guess:
                    desc += f" Hipótese de leitura da etiqueta: “{ocr_guess}”."
                desc += " Ajuste o nome no Admin."'''
assert old4 in s
s = s.replace(old4, new4)

open(p, "w").write(s)
print("ok")
