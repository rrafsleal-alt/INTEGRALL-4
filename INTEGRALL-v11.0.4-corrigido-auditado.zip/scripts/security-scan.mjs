import {readFile, readdir} from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const scanRoots = ['server.js', 'src', 'scripts', 'public/js'];
const failures = [];
const warnings = [];

async function walk(rel) {
  const full = path.join(root, rel);
  if (/\.(?:js|mjs)$/i.test(rel)) return [rel];
  const out = [];
  for (const entry of await readdir(full, {withFileTypes: true})) {
    const child = path.join(rel, entry.name);
    if (entry.isDirectory()) out.push(...await walk(child));
    else if (/\.(?:js|mjs|html|css)$/i.test(entry.name)) out.push(child);
  }
  return out;
}

const files = [];
for (const item of scanRoots) files.push(...await walk(item));

const rules = [
  {name: 'execução dinâmica', re: /\beval\s*\(|new\s+Function\s*\(/},
  {name: 'SQL concatenado', re: /(?:query|execute)\s*\(\s*`[^`]*\$\{[^}]+\}/s},
  {name: 'credencial hardcoded', re: /(?:access[_-]?token|api[_-]?key|client[_-]?secret|password)\s*[:=]\s*["'][A-Za-z0-9_\-./+=]{20,}["']/i},
];

for (const file of [...new Set(files)].sort()) {
  const text = await readFile(path.join(root, file), 'utf8');
  for (const rule of rules) {
    if (rule.re.test(text)) failures.push(`${file}: ${rule.name}`);
  }
  if (/console\.log\s*\(/.test(text) && !file.startsWith('scripts/')) warnings.push(`${file}: console.log presente; confirme que não registra PII/segredos`);
  if (/rejectUnauthorized\s*:\s*false/.test(text)) warnings.push(`${file}: modo TLS sem validação de certificado existe apenas para DATABASE_SSL_MODE=require; produção exige configuração explícita e recomenda verify-full`);
}


const serverSource = await readFile(path.join(root, 'server.js'), 'utf8');
if (!serverSource.includes("adminAuth.requirePermission('catalog:write')") ||
    !serverSource.includes("adminAuth.requirePermission('orders:write')") ||
    !serverSource.includes("adminAuth.requirePermission('media:write')")) {
  failures.push('server.js: proteção administrativa por permissão não foi detectada nas capacidades críticas');
}
if (/const\s+requireAdmin\s*=\s*\([^)]*\)\s*=>\s*[^;]*next\(\)/s.test(serverSource)) {
  failures.push('server.js: middleware administrativo permissivo/bypass detectado');
}

const envExample = await readFile(path.join(root, '.env.example'), 'utf8');
for (const line of envExample.split(/\r?\n/)) {
  const match = line.match(/^([A-Z][A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|ACCESS_CODE|DATABASE_URL))=(.+)$/);
  if (match && match[2].trim()) failures.push(`.env.example: ${match[1]} deve permanecer sem segredo real`);
}

if (failures.length) {
  console.error('SECURITY SCAN FAIL');
  for (const item of failures) console.error(`- ${item}`);
  process.exit(1);
}
console.log(`SECURITY SCAN OK - ${new Set(files).size} arquivos inspecionados`);
for (const item of warnings.slice(0, 20)) console.warn(`WARN: ${item}`);
