#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const ROOT = process.cwd();
const forbiddenCredential = ['159213', 'Rafs'].join('');
const skipDirs = new Set(['node_modules','.git','coverage','.cache','dist','build','docs']);
const textExt = new Set(['.js','.mjs','.cjs','.ts','.tsx','.jsx','.json','.html','.htm','.css','.scss','.md','.txt','.yml','.yaml','.xml','.svg','.sh','.bat','.cmd','.ps1']);

function walk(dir) {
  const out=[];
  for (const ent of fs.readdirSync(dir,{withFileTypes:true})) {
    if (skipDirs.has(ent.name)) continue;
    const p=path.join(dir,ent.name);
    if (ent.isDirectory()) out.push(...walk(p));
    else if (ent.isFile() && (textExt.has(path.extname(ent.name).toLowerCase()) || ent.name==='Dockerfile')) out.push(p);
  }
  return out;
}
function read(p){try{return fs.readFileSync(p,'utf8')}catch{return ''}}
function rel(p){return path.relative(ROOT,p).split(path.sep).join('/')}
const files=walk(ROOT);
const failures=[];
const passes=[];
function check(cond,label,detail=''){
  if(cond){passes.push(label);console.log(`APROVADO — ${label}`)}
  else {failures.push(`${label}${detail?`: ${detail}`:''}`);console.error(`REPROVADO — ${label}${detail?`: ${detail}`:''}`)}
}

const pkg=JSON.parse(read(path.join(ROOT,'package.json')) || '{}');
check(pkg.version==='11.0.4','versão do pacote é 11.0.4');

const publicFiles=files.filter(p=>/(^|\/)(public|client|frontend|web|static)(\/|$)/i.test(rel(p)));
const exposedPublic=publicFiles.filter(p=>read(p).includes(forbiddenCredential));
check(exposedPublic.length===0,'credencial padrão ausente do bundle/HTML/CSS/JS público',exposedPublic.map(rel).join(', '));

const sourceNonTests=files.filter(p=>!/(^|\/)(tests?|scripts?)(\/|$)/i.test(rel(p)) && !/\.md$/i.test(p));
const plaintextSource=sourceNonTests.filter(p=>read(p).includes(forbiddenCredential));
check(plaintextSource.length===0,'credencial padrão ausente do código-fonte executável em texto puro',plaintextSource.map(rel).join(', '));

const allHtml=files.filter(p=>/\.html?$/i.test(p));
const detailHosts=allHtml.filter(p=>/id=["']productDetails["']/i.test(read(p)));
check(detailHosts.length===1,'existe exatamente um bloco semântico #productDetails',detailHosts.map(rel).join(', '));
const legacyModal=allHtml.filter(p=>/id=["']productModal["']/i.test(read(p)));
check(legacyModal.length===0,'modal lateral legado #productModal foi removido',legacyModal.map(rel).join(', '));
if(detailHosts.length===1){
  const html=read(detailHosts[0]);
  const detailsAt=html.search(/id=["']productDetails["']/i);
  const footerAt=html.search(/<footer\b/i);
  check(footerAt<0 || detailsAt<footerAt,'detalhes do produto aparecem antes do rodapé na ordem do DOM',rel(detailHosts[0]));
}

const cssFiles=files.filter(p=>/\.css$/i.test(p));
const css=cssFiles.map(p=>`/* ${rel(p)} */\n${read(p)}`).join('\n');
check(!/body\s*\{[^}]*min-width\s*:\s*320px/isu.test(css),'não existe min-width global de 320 px no body');
let unsafeDetailPosition=[];
for(const p of cssFiles){
  const text=read(p);
  const rules=[...text.matchAll(/([^{}]*#productDetails[^{}]*)\{([^{}]*)\}/gisu)];
  for(const m of rules){if(/position\s*:\s*(fixed|absolute|sticky)/i.test(m[2])) unsafeDetailPosition.push(rel(p));}
}
check(unsafeDetailPosition.length===0,'#productDetails permanece no fluxo normal do documento',unsafeDetailPosition.join(', '));

const storageLeaks=files.filter(p=>/(localStorage|sessionStorage)/.test(read(p)) && /(password|senha|credential)/i.test(read(p)) && /setItem\s*\([^)]*(password|senha|credential)/i.test(read(p)));
check(storageLeaks.length===0,'credencial não é persistida em localStorage/sessionStorage',storageLeaks.map(rel).join(', '));

const authSources=files.filter(p=>/(auth|config)/i.test(path.basename(p)) && /\.(m?js|cjs|ts)$/i.test(p));
const fallbackPatterns=/(fallbackPasswordHash|passwordFallback|fallbackHashes|legacyPasswordHash)/i;
const fallbackFiles=authSources.filter(p=>fallbackPatterns.test(read(p)));
check(fallbackFiles.length===0,'não existe fallback explícito para credencial administrativa antiga',fallbackFiles.map(rel).join(', '));

const dangerous=files.filter(p=>/\.(m?js|cjs|ts|html)$/i.test(p) && /\beval\s*\(/.test(read(p)));
check(dangerous.length===0,'não existe uso direto de eval()',dangerous.map(rel).join(', '));

console.log(`\nResumo: ${passes.length} aprovado(s), ${failures.length} reprovado(s).`);
if(failures.length) process.exit(1);

