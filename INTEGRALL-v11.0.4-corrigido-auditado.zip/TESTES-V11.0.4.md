# TESTES — INTEGRALL v11.0.4

_Gerado em 2026-08-31T16:35:32+00:00._

## Ambiente

- Sistema: Linux-6.18.35-x86_64-with-glibc2.41
- Python: 3.13.5
- Node: v22.16.0
- npm: 10.9.2
- Diretório testado: pacote extraído em área isolada.
- Fase registrada: Pré-empacotamento; validação limpa será executada sobre o candidato extraído.

## Comandos principais

```bash
npm ci
npm run verify:v11.0.4
npm test
npm run build
npm start
```

## Matriz de autenticação

| ID | Cenário | Esperado | Resultado real |
|---|---|---|---|
| AUTH-001 | Campo vazio | Acesso recusado com mensagem clara | **NÃO EXECUTADO** |
| AUTH-002 | Senha incorreta | Acesso recusado | **NÃO EXECUTADO** |
| AUTH-003 | Senha antiga | Acesso recusado | **NÃO EXECUTADO** |
| AUTH-004 | Capitalização minúscula divergente | Acesso recusado | **NÃO EXECUTADO** |
| AUTH-005 | Capitalização maiúscula divergente | Acesso recusado | **NÃO EXECUTADO** |
| AUTH-006 | Credencial exata | Acesso autorizado | **NÃO EXECUTADO** |
| AUTH-007 | Pressionar Enter | Login executado | **NÃO EXECUTADO** |
| AUTH-008 | Recarregar após login | Sessão estável | **NÃO EXECUTADO** |
| AUTH-009 | Rota protegida direta | Proteção correta | **NÃO EXECUTADO** |
| AUTH-010 | Logout | Sessão encerrada | **NÃO EXECUTADO** |
| AUTH-011 | Voltar após logout | Painel não reaparece autorizado | **NÃO EXECUTADO** |
| AUTH-012 | Storage antigo | Tratado sem quebra | **NÃO EXECUTADO** |
| AUTH-013 | Duas abas | Estado coerente | **NÃO EXECUTADO** |
| AUTH-014 | Reload repetido | Sem loop/tela branca | **NÃO EXECUTADO** |

## Matriz de produto

| ID | Cenário | Esperado | Resultado real |
|---|---|---|---|
| PROD-001 | Abrir produto | Detalhes abaixo | **REPROVADO** |
| PROD-002 | Abrir em 320 px | Detalhes abaixo e sem corte | **NÃO EXECUTADO** |
| PROD-003 | Abrir em 768 px | Detalhes abaixo | **NÃO EXECUTADO** |
| PROD-004 | Abrir em 1440 px | Nunca ao lado | **NÃO EXECUTADO** |
| PROD-005 | Abrir em 1920 px | Nunca ao lado | **NÃO EXECUTADO** |
| PROD-006 | Trocar produto | Dados atualizados | **NÃO EXECUTADO** |
| PROD-007 | Fechar produto | Estado limpo | **NÃO EXECUTADO** |
| PROD-008 | Reabrir produto | Sem resíduos | **NÃO EXECUTADO** |
| PROD-009 | Alterar cor | Estado coerente | **NÃO EXECUTADO** |
| PROD-010 | Alterar tamanho | Estado coerente | **NÃO EXECUTADO** |
| PROD-011 | Alterar quantidade | Limites respeitados | **NÃO EXECUTADO** |
| PROD-012 | Descrição longa | Sem estouro | **REPROVADO** |
| PROD-013 | Nome longo | Sem corte | **REPROVADO** |
| PROD-014 | Produto sem imagem | Fallback correto | **NÃO EXECUTADO** |
| PROD-015 | Produto sem variação | Interface estável | **NÃO EXECUTADO** |
| PROD-016 | Abrir vários produtos | Sem listener duplicado | **NÃO EXECUTADO** |
| PROD-017 | Reload com produto aberto | Previsível | **NÃO EXECUTADO** |
| PROD-018 | Teclado | Acessível | **NÃO EXECUTADO** |
| PROD-019 | Zoom 200% | Sem perda funcional | **NÃO EXECUTADO** |
| PROD-020 | Ordem do DOM | Coerente | **REPROVADO** |

## Matriz de responsividade

| ID | Cenário | Esperado | Resultado real |
|---|---|---|---|
| RESP-001 | 280 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-002 | 320 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-003 | 375 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-004 | 430 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-005 | 768 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-006 | 1024 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-007 | 1366 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-008 | 1440 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-009 | 1920 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-010 | 2560 px | Layout estável, sem overflow global | **NÃO EXECUTADO** |
| RESP-011 | Orientação horizontal | Sem cortes | **NÃO EXECUTADO** |
| RESP-012 | Zoom 200% | Funcionalidade preservada | **NÃO EXECUTADO** |

Larguras registradas: 280px: NÃO EXECUTADO, 320px: NÃO EXECUTADO, 360px: NÃO EXECUTADO, 375px: NÃO EXECUTADO, 390px: NÃO EXECUTADO, 412px: NÃO EXECUTADO, 430px: NÃO EXECUTADO, 480px: NÃO EXECUTADO, 600px: NÃO EXECUTADO, 768px: NÃO EXECUTADO, 820px: NÃO EXECUTADO, 1024px: NÃO EXECUTADO, 1280px: NÃO EXECUTADO, 1366px: NÃO EXECUTADO, 1440px: NÃO EXECUTADO, 1600px: NÃO EXECUTADO, 1920px: NÃO EXECUTADO, 2560px: NÃO EXECUTADO.

## Build e estabilidade

| ID | Cenário | Resultado real |
|---|---|---|
| BUILD-001 | Instalação limpa | **NÃO EXECUTADO** |
| BUILD-002 | Lint | **NÃO EXECUTADO** |
| BUILD-003 | Type-check | **NÃO EXECUTADO** |
| BUILD-004 | Testes unitários | **REPROVADO** |
| BUILD-005 | Testes de integração | **NÃO EXECUTADO** |
| BUILD-006 | Testes E2E | **NÃO EXECUTADO** |
| BUILD-007 | Build de produção | **NÃO EXECUTADO** |
| BUILD-008 | Servir produção | **NÃO EXECUTADO** |
| BUILD-009 | Console | **NÃO EXECUTADO** |
| BUILD-010 | Requisições | **NÃO EXECUTADO** |
| BUILD-011 | Assets | **NÃO EXECUTADO** |
| BUILD-012 | Rotas | **NÃO EXECUTADO** |

## Execuções registradas

| Execução | Status | Duração | Evidência/observação |
|---|---|---:|---|
| working: verify:v11.0.4 | **REPROVADO** | 0.1s | REPROVADO — existe exatamente um bloco semântico #productDetails<br>REPROVADO — modal lateral legado #productModal foi removido: public/index.html<br>REPROVADO — não existe min-width global de 320 px no body<br>APROVADO — #productDetails permanece no fluxo normal do documento<br>APROVADO — credencial não é persistida em localStorage/sessionStorage<br>REPROVADO — não existe fallback explícito para credencial administrativa antiga: src/auth.js, src/config.js, tests/auth.test.js<br>REPROVADO — não  |
| working: test:v11.0.4 | **REPROVADO** | 0.1s | # tests 4<br># suites 0<br># pass 2<br># fail 2<br># cancelled 0<br># skipped 0<br># todo 0<br># duration_ms 85.823706 |
| working: suíte dependente de node_modules | **NÃO EXECUTADO** | 0.0s | node_modules não estava presente na cópia de trabalho; será tentada instalação limpa no pacote extraído. |

## Evidências

As evidências geradas realmente pelo ambiente estão em `docs/evidencias-v11.0.4/`. Logs são redigidos e não contêm a credencial em texto puro. Capturas ausentes não devem ser interpretadas como aprovadas.

## Navegadores

- Chromium/Chrome headless: **NÃO EXECUTADO**.
- Firefox: **NÃO EXECUTADO** — mecanismo/binário automatizável não confirmado no ambiente.
- WebKit/Safari: **NÃO EXECUTADO** — Safari não está disponível no ambiente Linux; validar posteriormente em macOS/iOS real.
- Edge: **NÃO EXECUTADO** — mecanismo Chromium foi exercitado, mas o produto Microsoft Edge não foi instalado separadamente.

## Testes não executados e risco residual

Todo item com status **NÃO EXECUTADO** permaneceu assim por ausência do navegador/mecanismo, falta de endpoint detectável, dependência externa ou limitação explícita registrada na linha correspondente. O risco residual concentra-se em diferenças específicas de Safari/WebKit, Firefox, teclado virtual mobile e persistência com infraestrutura PostgreSQL/serviços externos reais.

## Checklist final

- Código e assets incluídos: ver `MANIFESTO-V11.0.4.txt`.
- `node_modules`, `.git`, caches e `.env` real excluídos.
- Verificação estática própria disponível em `npm run verify:v11.0.4`.
- ZIP testado após extração: consultar a fase e as execuções acima.
- Nenhum status foi convertido de NÃO EXECUTADO para APROVADO.
