# Correção v11.0.2 — acesso administrativo

- Senha padrão de acesso à personalização definida como `159213Rafs`.
- Login passa a aceitar o campo de e-mail em branco.
- Credencial padrão validada por hash scrypt no backend, com sessão assinada, CSRF, RBAC e rate limiting preservados.
- Senha personalizada por `ADMIN_PASSWORD_HASH` continua suportada; a recuperação padrão pode ser desativada com `ADMIN_DEFAULT_LOGIN_ENABLED=false`.
- Inicializador corrigido para detectar também `mercadopago` e `pg`, não apenas `express`.
- Novo `PREPARAR-DEPENDENCIAS.bat` recupera instalações ausentes ou parciais com `npm ci`.
- `ABRIR-ADMIN.bat` passa a iniciar o servidor quando necessário e aguarda o health check antes de abrir o painel.
- Novo teste usa o hash padrão real de `src/config.js`, evitando falso positivo com hash criado apenas dentro da suíte.

# CHANGELOG_AUDIT

## v11.0.0 — 30/08/2026

### Segurança
- Proteção real de `/api/admin/*`.
- Login/logout administrativo, sessão assinada, cookie HttpOnly/SameSite/Secure em HTTPS.
- CSRF em mutações administrativas.
- RBAC para admin/editor/operator.
- Rate limit específico para login e rotas administrativas.
- Request ID e padronização de erros.
- Modo TLS PostgreSQL configurável e validação forte de produção.
- Auditoria de ações administrativas em `integrall_audit_log`.

### Upload e mídia
- Upload multipart de JPG/PNG/WebP.
- Validação de assinatura, integridade, tamanho, dimensões e pixels.
- Remoção de metadados desnecessários em formatos suportados.
- UUID, checksum, dimensão, tamanho, alt text, finalidade e autor.
- Provider de storage com implementações memória/local/PostgreSQL.
- Listagem de mídia e exclusão bloqueada quando o arquivo está em uso.
- Upload de logo, favicon, hero e fundos pelo painel.
- Galeria de produto com capa/reordenação/remoção.

### Dados e regras
- Migrations `001_initial` e `002_media_metadata_audit` com rollback disponível quando seguro.
- Runner com checksum e advisory lock.
- Máquina de estados de pedido.
- Atualização atômica do catálogo para reduzir condição de corrida.
- IDs novos baseados em UUID.

### Frontend/UX
- Tela de login administrativa.
- Feedback de sessão expirada e logout seguro.
- Alvos interativos mínimos e ajustes responsivos no admin.
- 404/500 próprias, manifest e robots.
- Metadados SEO/social na home.

### Qualidade/Operação
- 100 testes Node aprovados na validação final.
- Scripts `check`, `test:smoke`, `security:scan`, `db:migrate`, `build` e `verify`.
- Documentação de segurança, deploy, imagem e auditoria.
