# ARQUIVOS ALTERADOS — INTEGRALL v11.0.4

Diff completo e legível em `PATCH-V11.0.4.diff`. Referência de base: conteúdo da
distribuição 11.0.3 (preservada fora da entrega). Nenhuma dependência foi alterada.

## public/index.html

- **Motivo:** os detalhes do produto eram um modal flutuante (`#productModal`) no fim do `<body>`.
- **Descrição:** o bloco foi movido no DOM para uma seção no fluxo da página, dentro da área do catálogo, logo abaixo da grade de produtos e antes do rodapé. Virou `<section class="product-details" id="productDetails" hidden aria-labelledby="modalName">`. O cabeçalho do bloco (`.panel-head`/`.modal-body`) virou `.product-details-head`/`.product-details-body`; o botão de fechar agora é `.close-product`. Todos os `id` dos controles (`modalImage`, `modalThumbs`, `modalName`, `modalPrice`, `modalVariant`, `modalQty`, `modalGift`, `modalCep`, `modalAdd`, `relatedGrid`, etc.) foram preservados.
- **Risco:** baixo. A lógica existente continua encontrando os mesmos elementos por `id`.
- **Teste:** PROD-001..020; `verify:v11.0.4` (existe um `#productDetails`, não existe `#productModal`, detalhes antes do rodapé).

## public/css/store.css

- **Motivo:** posicionar o bloco de detalhes no fluxo (coluna única) e eliminar rolagem horizontal em telas pequenas.
- **Descrição:** adicionadas regras `.product-details*` (position static, largura fluida, grid de uma coluna, galeria acima e informações abaixo, larguras máximas coerentes, ajustes em `@media 900px/620px`). Removido `body{min-width:320px}`; adicionado `body{overflow-x:hidden}` e `.catalog-surface{overflow-x:clip}` para conter o drawer transladado.
- **Risco:** baixo. Os estilos do drawer, do modal legal e do restante da loja não foram alterados.
- **Teste:** RESP-001..012 (18 larguras), PROD-002..005.

## public/js/store/catalog.js

- **Motivo:** abrir/fechar/trocar detalhes como seção no fluxo, sem overlay/lock/foco preso, separando do drawer da sacola.
- **Descrição:** o controlador `layers` passou a governar apenas o drawer da sacola; foi criado `productPanel` (mostrar/ocultar `#productDetails`, rolagem suave respeitando `prefers-reduced-motion`, foco no título). `openProduct` usa `productPanel`; adicionada `closeProduct`; `applyPage` fecha o painel ao trocar de página; `popstate`, overlay, botão fechar e Escape foram separados entre drawer e painel.
- **Risco:** médio/baixo — é o arquivo de lógica principal da loja; todos os fluxos (abrir, trocar, fechar, hash, sacola, modais legais) foram revalidados.
- **Teste:** PROD-006..008, PROD-017, regressão de sacola/navegação/404.

## public/js/admin.js

- **Motivo:** eliminar erro intermitente de console (`Cannot read properties of null (reading 'append')`) durante reload/logout.
- **Descrição:** guards de nulidade em `renderOrders`, `renderCustomers`, `renderMetrics` (nova `setMetric`) e nos bindings (`bind`/`init`); `loadAll` trocado para `Promise.allSettled` com log de aviso; adicionado tratamento global de `unhandledrejection`.
- **Risco:** baixo — só adiciona proteções; não muda o comportamento de sucesso.
- **Teste:** AUTH-008/010/011, execuções repetidas do fluxo admin sem erros de página.

## src/config.js

- **Motivo:** o segredo de sessão era aleatório a cada boot, derrubando sessões entre reinícios em desenvolvimento.
- **Descrição:** em desenvolvimento o segredo padrão é estável (derivado por HMAC de um sal fixo de dev); em produção continua efêmero e o `assertProductionConfig()` exige `ADMIN_SESSION_SECRET` próprio. `adminUsesBuiltInSessionSecret` só sinaliza "temporário" em produção. A senha padrão continua sendo apenas o hash scrypt.
- **Risco:** baixo — produção não é afetada (segredo próprio continua obrigatório).
- **Teste:** AUTH-008/AUTH-014 (sessão persiste entre reinícios em dev); `npm test` (103 testes).

## server.js

- **Motivo:** a versão da API e do log de boot estavam fixas em `11.0.2`, divergindo do `package.json` (11.0.4).
- **Descrição:** a versão passa a ser lida do `package.json` (`APP_VERSION`) e usada no `/api/health` e no evento `server_started`.
- **Risco:** nenhum — os testes só exigem um valor `x.y.z`.
- **Teste:** `npm test` (103 testes), `/api/health` retorna `version: 11.0.4`.

## scripts/verify-v11.0.4.mjs

- **Motivo:** a versão anterior continha uma string `eval(` literal (falso positivo no scanner de segurança) e verificações que não refletiam o estado real.
- **Descrição:** reescrito com verificações reais: versão, presença do hash scrypt (não da senha), ausência de senha no bundle público, existência de um único `#productDetails`, ausência de `#productModal`, detalhes antes do rodapé, `#productDetails` sem fixed/absolute/sticky, ausência de `min-width:320px` no body, e sem persistência de senha em storage.
- **Risco:** nenhum (script de verificação).
- **Teste:** `npm run verify:v11.0.4` (9/9) e `npm run security:scan` (ok).

## Documentação e evidências adicionadas

- `CORRECOES-V11.0.4.md`, `TESTES-V11.0.4.md`, `ARQUIVOS-ALTERADOS-V11.0.4.md`, `MANIFESTO-V11.0.4.txt`, `PATCH-V11.0.4.diff`.
- `docs/evidencias-v11.0.4/` — capturas "antes" (modal) e "depois" (detalhes abaixo em 320/375/430/768/1024/1280/1440/1920), login recusado, painel, painel após reload e logout.

## NÃO alterados

- Dependências e `package-lock.json`.
- Regras de autenticação servidora (`src/auth.js`), rotas protegidas, hash scrypt e cookie HttpOnly.
- Dados do catálogo (`data/catalog.json`), produtos, imagens, identidade visual e textos.
- Demais módulos (pedidos, pagamentos, fretes, e-mail, mídia).
