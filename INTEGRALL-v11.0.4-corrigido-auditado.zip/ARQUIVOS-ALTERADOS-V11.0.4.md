# ARQUIVOS ALTERADOS — INTEGRALL v11.0.4

_Comparação entre a extração intacta do arquivo recebido e a versão preparada para entrega._

| Caminho | Tipo | Motivo/descrição | Risco | Teste relacionado |
|---|---|---|---|---|
| `ARQUIVOS-ALTERADOS-V11.0.4.md` | ADICIONADO | Documentação e evidência de auditoria | Baixo | Documentação obrigatória |
| `CORRECOES-V11.0.4.md` | ADICIONADO | Documentação e evidência de auditoria | Baixo | Documentação obrigatória |
| `MANIFESTO-V11.0.4.txt` | ADICIONADO | Documentação e evidência de auditoria | Baixo | Documentação obrigatória |
| `PATCH-V11.0.4.diff` | ADICIONADO | Documentação e evidência de auditoria | Baixo | Documentação obrigatória |
| `TESTES-V11.0.4.md` | ADICIONADO | Cobertura automatizada de regressão da versão 11.0.4 | Baixo | BUILD-004 a BUILD-006 |
| `docs/INVENTARIO-ORIGINAL-V11.0.3.txt` | ADICIONADO | Documentação e evidência de auditoria | Baixo | Documentação obrigatória |
| `docs/evidencias-v11.0.4/logs/working-static-tests.log` | ADICIONADO | Cobertura automatizada de regressão da versão 11.0.4 | Baixo | BUILD-004 a BUILD-006 |
| `docs/evidencias-v11.0.4/logs/working-verify-v11.0.4.log` | ADICIONADO | Cobertura automatizada de regressão da versão 11.0.4 | Baixo | BUILD-004 a BUILD-006 |
| `package-lock.json` | ALTERADO | Versionamento e comandos de verificação | Baixo | BUILD-001 a BUILD-007 |
| `package.json` | ALTERADO | Versionamento e comandos de verificação | Baixo | BUILD-001 a BUILD-007 |
| `scripts/verify-v11.0.4.mjs` | ADICIONADO | Cobertura automatizada de regressão da versão 11.0.4 | Baixo | BUILD-004 a BUILD-006 |
| `tests/v11.0.4-static.test.mjs` | ADICIONADO | Cobertura automatizada de regressão da versão 11.0.4 | Baixo | BUILD-004 a BUILD-006 |

Arquivos de documentação gerados nesta etapa podem não aparecer no diff inicial quando não existiam na árvore original; eles são listados no manifesto final.
