import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import pg from 'pg';
import {runMigrations} from './migrations.js';
import {LocalMediaStorage, MemoryMediaStorage, PostgresMediaStorage} from './media-storage.js';
const {Pool} = pg;

const INVENTORY_COMMIT_STATUSES = new Set(['paid', 'preparing', 'ready', 'completed']);

function postgresSsl(mode, ca = '') {
  const normalized = String(mode || '').toLowerCase();
  if (normalized === 'disable') return undefined;
  if (normalized === 'require') return {rejectUnauthorized: false};
  return {rejectUnauthorized: true, ...(ca ? {ca} : {})};
}

function clone(value) {
  return typeof structuredClone === 'function' ? structuredClone(value) : JSON.parse(JSON.stringify(value));
}

async function rollbackTransaction(client, context) {
  try {
    await client.query('ROLLBACK');
  } catch (error) {
    console.error(JSON.stringify({level: 'error', event: 'database_rollback_failed', context, message: String(error?.message || error).slice(0, 500)}));
  }
}

function digits(value) {
  return String(value || '').replace(/\D/g, '');
}

/** Escapa curingas do LIKE (% e _) para que a busca seja literal. */
function likePattern(term) {
  return `%${String(term).replace(/([\\%_])/g, '\\$1')}%`;
}

function customerKey(customer = {}) {
  const email = String(customer.email || '').trim().toLowerCase();
  const phone = digits(customer.phone);
  if (!email && !phone) return '';
  return createHash('sha256').update(`${email}|${phone}`).digest('hex');
}

function customerSnapshot(order) {
  const key = customerKey(order.customer);
  if (!key) return null;
  return {
    key,
    data: {
      name: String(order.customer?.name || ''),
      email: String(order.customer?.email || ''),
      phone: String(order.customer?.phone || ''),
      firstOrderAt: order.createdAt,
      lastOrderAt: order.createdAt,
      lastOrderId: order.id
    }
  };
}

function mergeOrder(current, patch, {source = 'system', note = ''} = {}) {
  const now = new Date().toISOString();
  const next = {...current, ...clone(patch), updatedAt: now};
  if (patch.payment) next.payment = {...(current.payment || {}), ...clone(patch.payment)};
  if (patch.shipping) next.shipping = {...(current.shipping || {}), ...clone(patch.shipping)};
  if (patch.customer) next.customer = {...(current.customer || {}), ...clone(patch.customer)};

  const statusChanged = patch.status && patch.status !== current.status;
  if (statusChanged || note) {
    next.history = Array.isArray(current.history) ? clone(current.history) : [];
    next.history.push({
      at: now,
      status: next.status || current.status,
      source,
      note: String(note || '').slice(0, 500)
    });
    // Cap do histórico: webhooks repetidos/edições não podem inflar o JSONB
    // indefinidamente. 100 eventos cobrem qualquer ciclo de vida real.
    if (next.history.length > 100) next.history = next.history.slice(-100);
  }
  return next;
}

function commitInventory(catalog, order) {
  const nextCatalog = clone(catalog);
  const warnings = [];
  for (const line of order.items || []) {
    const product = nextCatalog.products?.find(item => item.id === line.productId);
    if (!product) {
      warnings.push(`Produto ausente no catálogo: ${line.productId}`);
      continue;
    }
    const qty = Number(line.qty) || 0;
    if (qty <= 0) continue;

    const variant = line.variantId ? (product.variants || []).find(item => item.id === line.variantId) : null;
    if (variant && variant.stock != null) {
      const before = Number(variant.stock);
      if (!Number.isFinite(before)) {
        warnings.push(`Estoque inválido em ${product.name} / ${variant.name}`);
        continue;
      }
      if (before < qty) warnings.push(`Estoque insuficiente ao confirmar pagamento: ${product.name} / ${variant.name}`);
      variant.stock = Math.max(0, before - qty);
      continue;
    }

    if (product.stock != null) {
      const before = Number(product.stock);
      if (!Number.isFinite(before)) {
        warnings.push(`Estoque inválido em ${product.name}`);
        continue;
      }
      if (before < qty) warnings.push(`Estoque insuficiente ao confirmar pagamento: ${product.name}`);
      product.stock = Math.max(0, before - qty);
    }
  }
  return {catalog: nextCatalog, warnings};
}

export class Repository {
  constructor({databaseUrl, initialCatalog, production = false, localDataDir = '', databaseSslMode = 'disable', databaseCa = '', migrationsDir = ''}) {
    this.databaseUrl = databaseUrl;
    this.initialCatalog = initialCatalog;
    this.production = production;
    this.localDataDir = String(localDataDir || '').trim();
    this.databaseSslMode = String(databaseSslMode || (production ? 'verify-full' : 'disable'));
    this.databaseCa = String(databaseCa || '');
    this.migrationsDir = String(migrationsDir || path.join(process.cwd(), 'migrations'));
    this.pool = null;
    this.mediaStorage = null;
    this.memoryCatalog = clone(initialCatalog);
    this.memoryOrders = new Map();
    this.clientIndex = new Map();
    this.memoryCustomers = new Map();
    this.memoryAudit = [];
  }

  get persistent() { return Boolean(this.pool); }

  async init() {
    if (!this.databaseUrl) {
      if (this.production) throw new Error('DATABASE_URL é obrigatório em produção.');
      if (this.localDataDir) {
        await mkdir(path.join(this.localDataDir, 'media'), {recursive: true});
        try {
          const saved = JSON.parse(await readFile(path.join(this.localDataDir, 'catalog.json'), 'utf8'));
          if (saved && typeof saved === 'object') this.memoryCatalog = saved;
        } catch (error) {
          if (error?.code !== 'ENOENT') console.warn('[local-state] catálogo local ignorado:', error.message);
        }
        this.mediaStorage = new LocalMediaStorage(path.join(this.localDataDir, 'media'));
      } else {
        this.mediaStorage = new MemoryMediaStorage();
      }
      await this.mediaStorage.init();
      return;
    }

    this.pool = new Pool({
      connectionString: this.databaseUrl,
      ssl: postgresSsl(this.databaseSslMode, this.databaseCa),
      max: 10,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 10_000,
      application_name: 'integrall-online'
    });
    await this.pool.query('SELECT 1');
    await runMigrations(this.pool, this.migrationsDir);
    this.mediaStorage = new PostgresMediaStorage(this.pool);
    await this.mediaStorage.init();
    await this.pool.query(
      `INSERT INTO integrall_catalog (id, data) VALUES (1, $1::jsonb) ON CONFLICT (id) DO NOTHING`,
      [JSON.stringify(this.initialCatalog)]
    );
  }

  async persistLocalCatalog() {
    if (!this.localDataDir || this.pool) return;
    await mkdir(this.localDataDir, {recursive: true});
    await writeFile(path.join(this.localDataDir, 'catalog.json'), `${JSON.stringify(this.memoryCatalog, null, 2)}\n`, 'utf8');
  }

  async getCatalog() {
    if (!this.pool) return clone(this.memoryCatalog);
    const {rows} = await this.pool.query('SELECT data FROM integrall_catalog WHERE id = 1');
    return rows[0]?.data ?? clone(this.initialCatalog);
  }

  async saveCatalog(catalog) {
    if (!this.pool) {
      this.memoryCatalog = clone(catalog);
      await this.persistLocalCatalog();
      return this.getCatalog();
    }
    await this.pool.query(
      `INSERT INTO integrall_catalog (id, data, updated_at) VALUES (1, $1::jsonb, NOW())
       ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
      [JSON.stringify(catalog)]
    );
    return catalog;
  }

  /** Atualiza o catálogo atomicamente sobre o estado mais recente. */
  async mutateCatalog(mutator) {
    if (typeof mutator !== 'function') throw new TypeError('mutator precisa ser uma função.');
    if (!this.pool) {
      const next = await mutator(clone(this.memoryCatalog));
      if (!next || typeof next !== 'object') throw new Error('A mutação do catálogo não retornou um catálogo válido.');
      this.memoryCatalog = clone(next);
      await this.persistLocalCatalog();
      return this.getCatalog();
    }
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const {rows} = await client.query('SELECT data FROM integrall_catalog WHERE id = 1 FOR UPDATE');
      const current = rows[0]?.data ?? clone(this.initialCatalog);
      const next = await mutator(current);
      if (!next || typeof next !== 'object') throw new Error('A mutação do catálogo não retornou um catálogo válido.');
      await client.query(
        `INSERT INTO integrall_catalog (id, data, updated_at) VALUES (1, $1::jsonb, NOW())
         ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()`,
        [JSON.stringify(next)]
      );
      await client.query('COMMIT');
      return next;
    } catch (error) {
      await rollbackTransaction(client, 'catalog_mutation');
      throw error;
    } finally {
      client.release();
    }
  }

  async saveMedia(media) {
    if (!this.mediaStorage) throw new Error('Armazenamento de mídia não inicializado.');
    return this.mediaStorage.save(media);
  }

  async getMedia(id) {
    if (!this.mediaStorage) return null;
    return this.mediaStorage.get(id);
  }

  async listMedia(options = {}) {
    if (!this.mediaStorage) return [];
    return this.mediaStorage.list(options);
  }

  async deleteMedia(id) {
    if (!this.mediaStorage) return false;
    return this.mediaStorage.delete(id);
  }

  async recordAudit({requestId = '', actor = 'system', role = '', action, entityType, entityId = '', metadata = {}}) {
    const entry = {
      requestId: String(requestId || '').slice(0, 120),
      actor: String(actor || 'system').slice(0, 254),
      role: String(role || '').slice(0, 40),
      action: String(action || '').slice(0, 120),
      entityType: String(entityType || '').slice(0, 120),
      entityId: String(entityId || '').slice(0, 180),
      metadata: clone(metadata && typeof metadata === 'object' ? metadata : {}),
      createdAt: new Date().toISOString()
    };
    if (!entry.action || !entry.entityType) return null;
    if (!this.pool) {
      this.memoryAudit.push(entry);
      if (this.memoryAudit.length > 2000) this.memoryAudit.splice(0, this.memoryAudit.length - 2000);
      return clone(entry);
    }
    const {rows} = await this.pool.query(
      `INSERT INTO integrall_audit_log (request_id, actor, role, action, entity_type, entity_id, metadata)
       VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)
       RETURNING id, created_at`,
      [entry.requestId, entry.actor, entry.role, entry.action, entry.entityType, entry.entityId, JSON.stringify(entry.metadata)]
    );
    return {...entry, id: rows[0]?.id, createdAt: rows[0]?.created_at?.toISOString?.() || rows[0]?.created_at};
  }

  async listAudit({limit = 100} = {}) {
    const safeLimit = Math.max(1, Math.min(500, Number(limit) || 100));
    if (!this.pool) return clone(this.memoryAudit.slice(-safeLimit).reverse());
    const {rows} = await this.pool.query(
      `SELECT id, request_id, actor, role, action, entity_type, entity_id, metadata, created_at
         FROM integrall_audit_log ORDER BY created_at DESC LIMIT $1`,
      [safeLimit]
    );
    return rows.map(row => ({
      id: row.id,
      requestId: row.request_id,
      actor: row.actor,
      role: row.role,
      action: row.action,
      entityType: row.entity_type,
      entityId: row.entity_id,
      metadata: row.metadata,
      createdAt: row.created_at?.toISOString?.() || row.created_at
    }));
  }

  async getOrder(id) {
    if (!this.pool) return this.memoryOrders.has(id) ? clone(this.memoryOrders.get(id)) : null;
    const {rows} = await this.pool.query('SELECT data FROM integrall_orders WHERE id = $1', [id]);
    return rows[0]?.data ?? null;
  }

  async getOrderByClientId(clientOrderId) {
    if (!this.pool) {
      const id = this.clientIndex.get(clientOrderId);
      return id ? this.getOrder(id) : null;
    }
    const {rows} = await this.pool.query('SELECT data FROM integrall_orders WHERE client_order_id = $1', [clientOrderId]);
    return rows[0]?.data ?? null;
  }

  upsertMemoryCustomer(order) {
    const snapshot = customerSnapshot(order);
    if (!snapshot) return;
    const existing = this.memoryCustomers.get(snapshot.key);
    this.memoryCustomers.set(snapshot.key, {
      ...(existing || {}),
      ...snapshot.data,
      firstOrderAt: existing?.firstOrderAt || snapshot.data.firstOrderAt,
      lastOrderAt: order.createdAt,
      lastOrderId: order.id
    });
  }

  async createOrder(order) {
    const existing = await this.getOrderByClientId(order.clientOrderId);
    if (existing) return {order: existing, created: false};

    if (!this.pool) {
      this.memoryOrders.set(order.id, clone(order));
      this.clientIndex.set(order.clientOrderId, order.id);
      this.upsertMemoryCustomer(order);
      return {order: clone(order), created: true};
    }

    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `INSERT INTO integrall_orders (id, client_order_id, data, created_at, updated_at)
         VALUES ($1, $2, $3::jsonb, $4, $4)`,
        [order.id, order.clientOrderId, JSON.stringify(order), order.createdAt]
      );
      const snapshot = customerSnapshot(order);
      if (snapshot) {
        await client.query(
          `INSERT INTO integrall_customers (contact_key, data, created_at, updated_at)
           VALUES ($1, $2::jsonb, $3, $3)
           ON CONFLICT (contact_key) DO UPDATE SET
             data = jsonb_set(
               jsonb_set(
                 jsonb_set(EXCLUDED.data, '{firstOrderAt}', COALESCE(integrall_customers.data->'firstOrderAt', EXCLUDED.data->'firstOrderAt')),
                 '{lastOrderAt}', EXCLUDED.data->'lastOrderAt'
               ),
               '{lastOrderId}', EXCLUDED.data->'lastOrderId'
             ),
             updated_at = NOW()`,
          [snapshot.key, JSON.stringify(snapshot.data), order.createdAt]
        );
      }
      await client.query('COMMIT');
      return {order, created: true};
    } catch (error) {
      await rollbackTransaction(client, 'order_creation');
      if (error?.code === '23505') {
        const duplicate = await this.getOrderByClientId(order.clientOrderId);
        if (duplicate) return {order: duplicate, created: false};
      }
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Atualiza um pedido com lock (FOR UPDATE).
   * `patch` pode ser um objeto OU uma função (currentFresh) => patch | null.
   * A forma funcional é avaliada DENTRO do lock, sobre o estado mais recente —
   * obrigatória para decisões dependentes de estado (ex.: webhook de
   * pagamento), eliminando TOCTOU entre ler o pedido e gravar a decisão.
   * Retornar null da função aborta sem gravar (retorna o estado atual).
   */
  async updateOrder(id, patch, options = {}) {
    const resolvePatch = current => (typeof patch === 'function' ? patch(current) : patch);
    if (!this.pool) {
      const current = await this.getOrder(id);
      if (!current) return null;
      const resolved = resolvePatch(current);
      if (resolved == null) return clone(current);
      let next = mergeOrder(current, resolved, typeof options === 'function' ? options(current) : options);
      if (!current.inventoryCommittedAt && INVENTORY_COMMIT_STATUSES.has(next.status)) {
        const result = commitInventory(this.memoryCatalog, next);
        this.memoryCatalog = result.catalog;
        await this.persistLocalCatalog();
        next.inventoryCommittedAt = new Date().toISOString();
        if (result.warnings.length) next.inventoryWarnings = result.warnings;
      }
      this.memoryOrders.set(id, clone(next));
      return clone(next);
    }

    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const {rows} = await client.query('SELECT data FROM integrall_orders WHERE id = $1 FOR UPDATE', [id]);
      const current = rows[0]?.data;
      if (!current) {
        await client.query('ROLLBACK');
        return null;
      }
      // Forma funcional: decide o patch DENTRO do lock, sobre o estado fresco.
      const resolved = resolvePatch(current);
      if (resolved == null) {
        await client.query('ROLLBACK');
        return current;
      }
      let next = mergeOrder(current, resolved, typeof options === 'function' ? options(current) : options);

      if (!current.inventoryCommittedAt && INVENTORY_COMMIT_STATUSES.has(next.status)) {
        const catalogResult = await client.query('SELECT data FROM integrall_catalog WHERE id = 1 FOR UPDATE');
        const catalog = catalogResult.rows[0]?.data ?? clone(this.initialCatalog);
        const result = commitInventory(catalog, next);
        await client.query('UPDATE integrall_catalog SET data = $1::jsonb, updated_at = NOW() WHERE id = 1', [JSON.stringify(result.catalog)]);
        next.inventoryCommittedAt = new Date().toISOString();
        if (result.warnings.length) next.inventoryWarnings = result.warnings;
      }

      await client.query('UPDATE integrall_orders SET data = $2::jsonb, updated_at = NOW() WHERE id = $1', [id, JSON.stringify(next)]);
      await client.query('COMMIT');
      return next;
    } catch (error) {
      await rollbackTransaction(client, 'order_update');
      throw error;
    } finally {
      client.release();
    }
  }

  async listOrders({status = '', search = '', limit = 300} = {}) {
    const safeLimit = Math.max(1, Math.min(500, Number(limit) || 300));
    const normalizedStatus = String(status || '').trim();
    const q = String(search || '').toLowerCase().trim();
    if (!this.pool) {
      return [...this.memoryOrders.values()]
        .map(order => clone(order))
        .filter(order => !normalizedStatus || order.status === normalizedStatus)
        .filter(order => !q || `${order.id} ${order.clientOrderId} ${order.customer?.name || ''} ${order.customer?.email || ''} ${order.customer?.phone || ''}`.toLowerCase().includes(q))
        .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
        .slice(0, safeLimit);
    }

    const pattern = q ? likePattern(q) : '';
    const {rows} = await this.pool.query(
      `SELECT data
         FROM integrall_orders
        WHERE ($1 = '' OR data->>'status' = $1)
          AND ($2 = '' OR LOWER(CONCAT_WS(' ',
                id,
                client_order_id,
                COALESCE(data #>> '{customer,name}', ''),
                COALESCE(data #>> '{customer,email}', ''),
                COALESCE(data #>> '{customer,phone}', '')
              )) LIKE $2)
        ORDER BY created_at DESC
        LIMIT $3`,
      [normalizedStatus, pattern, safeLimit]
    );
    return rows.map(row => row.data);
  }

  async listCustomers({search = '', limit = 300} = {}) {
    const safeLimit = Math.max(1, Math.min(500, Number(limit) || 300));
    const q = String(search || '').toLowerCase().trim();
    if (!this.pool) {
      return [...this.memoryCustomers.values()]
        .map(customer => clone(customer))
        .filter(customer => !q || `${customer.name || ''} ${customer.email || ''} ${customer.phone || ''}`.toLowerCase().includes(q))
        .sort((a, b) => String(b.lastOrderAt || '').localeCompare(String(a.lastOrderAt || '')))
        .slice(0, safeLimit);
    }
    const pattern = q ? likePattern(q) : '';
    const {rows} = await this.pool.query(
      `SELECT data FROM integrall_customers
       WHERE ($1 = '' OR LOWER(CONCAT_WS(' ', COALESCE(data->>'name',''), COALESCE(data->>'email',''), COALESCE(data->>'phone',''))) LIKE $1)
       ORDER BY updated_at DESC
       LIMIT $2`,
      [pattern, safeLimit]
    );
    return rows.map(row => row.data);
  }

  /**
   * Cancela pedidos sem pagamento criados há mais de `days` dias.
   * Considera apenas estados pré-financeiros; nunca toca pedidos pagos.
   */
  async expireStaleOrders(days) {
    const cutoffMs = Number(days) * 86_400_000;
    if (!Number.isFinite(cutoffMs) || cutoffMs <= 0) return [];
    const cutoff = new Date(Date.now() - cutoffMs).toISOString();
    const staleStatuses = ['received', 'awaiting_payment', 'payment_failed', 'payment_expired'];
    const expired = [];

    // Patch FUNCIONAL: reconfirma o status DENTRO do lock. Sem isso, um
    // webhook poderia marcar o pedido como pago entre o SELECT e o UPDATE,
    // e o cancelamento automático sobrescreveria um pedido pago (TOCTOU).
    // O flag `applied` (por pedido) distingue "cancelei agora" de "já estava
    // em outro estado" — evita e-mail de expiração duplicado/indevido.
    const auditNote = {source: 'system', note: `Pedido cancelado automaticamente após ${days} dia(s) sem pagamento.`};
    const expireOne = async id => {
      let applied = false;
      const next = await this.updateOrder(id, current => {
        if (staleStatuses.includes(current.status) && String(current.createdAt) < cutoff) {
          applied = true;
          return {status: 'cancelled'};
        }
        return null;
      }, auditNote);
      if (next && applied) expired.push(next);
    };

    if (!this.pool) {
      for (const [id, order] of this.memoryOrders) {
        if (staleStatuses.includes(order.status) && String(order.createdAt) < cutoff) await expireOne(id);
      }
      return expired;
    }

    const {rows} = await this.pool.query(
      `SELECT id FROM integrall_orders
        WHERE data->>'status' = ANY($1)
          AND created_at < $2
        LIMIT 200`,
      [staleStatuses, cutoff]
    );
    for (const row of rows) await expireOne(row.id);
    return expired;
  }

  async health() {
    if (!this.pool) return {ok: true, mode: 'memory-development-only'};
    await this.pool.query('SELECT 1');
    return {ok: true, mode: 'postgresql'};
  }

  async close() {
    await this.pool?.end();
  }
}
