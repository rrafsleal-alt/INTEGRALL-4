import process from 'node:process';
import {randomBytes} from 'node:crypto';

// Credencial padrão solicitada para garantir o primeiro acesso ao editor.
// A senha nunca fica em texto puro no código: somente o hash scrypt é armazenado.
const DEFAULT_ADMIN_EMAIL = 'admin@integrall.local';
const DEFAULT_ADMIN_PASSWORD_HASH = 'scrypt$32768$8$1$kl5XPhtAyxTz2pU0MBydlg$3LcI-tTNygXiOaULs-bPEXuEyYF4X5DTuuWfVv8oX6H1mXF1e_E7tK7_aO7CIvskjY_tKnA3LDw_3GRzbBa-ng';
// Em desenvolvimento, sem ADMIN_SESSION_SECRET definido, usamos um segredo
// ESTÁVEL derivado por HMAC de um sal fixo de desenvolvimento. Isso mantém a
// sessão administrativa válida entre reinícios do servidor (evita "logout
// fantasma"/loop ao atualizar durante o desenvolvimento local).
// Em produção (NODE_ENV=production) o assertProductionConfig() exige um
// ADMIN_SESSION_SECRET real e persistente — o valor abaixo nunca é usado lá.
import {createHmac} from 'node:crypto';
const DEV_SESSION_SALT = 'integrall-dev-session-v11';
const DEV_ADMIN_SESSION_SECRET = createHmac('sha256', DEV_SESSION_SALT).update('admin-session-secret').digest('base64url').repeat(2).slice(0, 64);
const isProduction = text('NODE_ENV', 'development') === 'production';
const DEFAULT_ADMIN_SESSION_SECRET = isProduction ? randomBytes(48).toString('base64url') : DEV_ADMIN_SESSION_SECRET;

function bool(name, fallback = false) {
  const value = process.env[name];
  if (value == null || value === '') return fallback;
  return /^(1|true|yes|on)$/i.test(value);
}

function int(name, fallback = null) {
  const value = process.env[name];
  if (value == null || value === '') return fallback;
  const number = Number(value);
  return Number.isInteger(number) ? number : fallback;
}

function text(name, fallback = '') {
  return String(process.env[name] ?? fallback).trim();
}

function base64Text(name) {
  const value = text(name);
  if (!value) return '';
  try { return Buffer.from(value, 'base64').toString('utf8'); }
  catch { return ''; }
}

const configuredAdminEmail = text('ADMIN_EMAIL').toLowerCase();
const configuredAdminPasswordHash = text('ADMIN_PASSWORD_HASH');
const configuredAdminSessionSecret = text('ADMIN_SESSION_SECRET');
const defaultAdminLoginEnabled = bool('ADMIN_DEFAULT_LOGIN_ENABLED', true);

export const config = Object.freeze({
  env: text('NODE_ENV', 'development'),
  port: int('PORT', 3000) ?? 3000,
  databaseUrl: text('DATABASE_URL'),
  databaseSslMode: text('DATABASE_SSL_MODE', text('NODE_ENV', 'development') === 'production' ? 'verify-full' : 'disable').toLowerCase(),
  databaseCa: base64Text('DATABASE_CA_BASE64'),
  publicUrl: text('PUBLIC_URL').replace(/\/$/, ''),
  renderExternalHostname: text('RENDER_EXTERNAL_HOSTNAME'),
  whatsappNumber: text('WHATSAPP_NUMBER').replace(/\D/g, ''),
  mercadoPagoAccessToken: text('MERCADO_PAGO_ACCESS_TOKEN'),
  mercadoPagoWebhookSecret: text('MERCADO_PAGO_WEBHOOK_SECRET'),
  mercadoPagoUseSandbox: bool('MERCADO_PAGO_USE_SANDBOX', false),
  mercadoPagoExpirationDays: Math.max(3, Math.min(30, int('MERCADO_PAGO_PAYMENT_EXPIRATION_DAYS', 3) ?? 3)),
  allowPaymentWithQuotedShipping: bool('ALLOW_PAYMENT_WITH_QUOTED_SHIPPING', false),
  shippingMode: text('SHIPPING_MODE'),
  shippingFixedCents: int('SHIPPING_FIXED_CENTS', null),
  freeShippingCents: int('FREE_SHIPPING_CENTS', null),
  trustProxy: bool('TRUST_PROXY', false),

  // Administração segura. A senha padrão permanece disponível como recuperação
  // enquanto ADMIN_DEFAULT_LOGIN_ENABLED não for definido como false.
  adminEmail: configuredAdminEmail || DEFAULT_ADMIN_EMAIL,
  adminPasswordHash: configuredAdminPasswordHash || (defaultAdminLoginEnabled ? DEFAULT_ADMIN_PASSWORD_HASH : ''),
  adminFallbackPasswordHash: configuredAdminPasswordHash && defaultAdminLoginEnabled ? DEFAULT_ADMIN_PASSWORD_HASH : '',
  adminDefaultLoginEnabled: defaultAdminLoginEnabled,
  // Em desenvolvimento o segredo embutido é estável (não derruba sessões entre
  // reinícios); em produção ele é efêmero e o assertProductionConfig exige um
  // ADMIN_SESSION_SECRET próprio, por isso sinalizamos como "embutido" só lá.
  adminUsesBuiltInSessionSecret: !configuredAdminSessionSecret && isProduction,
  adminRole: text('ADMIN_ROLE', 'admin').toLowerCase(),
  adminSessionSecret: configuredAdminSessionSecret || DEFAULT_ADMIN_SESSION_SECRET,
  adminSessionHours: Math.max(1, Math.min(24, int('ADMIN_SESSION_HOURS', 8) ?? 8)),

  // Correios (API de contrato / CWS)
  correiosUser: text('CORREIOS_USER'),
  correiosAccessCode: text('CORREIOS_ACCESS_CODE'),
  correiosPostageCard: text('CORREIOS_POSTAGE_CARD'),
  correiosContract: text('CORREIOS_CONTRACT'),
  correiosOriginCep: text('CORREIOS_ORIGIN_CEP').replace(/\D/g, ''),
  correiosServices: text('CORREIOS_SERVICES'),
  correiosHomolog: bool('CORREIOS_HOMOLOG', false),
  correiosBaseUrl: text('CORREIOS_BASE_URL'),
  correiosApiVersion: text('CORREIOS_API_VERSION'),

  // Jadlog (API Embarcador)
  jadlogToken: text('JADLOG_TOKEN'),
  jadlogCnpj: text('JADLOG_CNPJ').replace(/\D/g, ''),
  jadlogConta: text('JADLOG_CONTA'),
  jadlogContrato: text('JADLOG_CONTRATO'),
  jadlogModalidade: int('JADLOG_MODALIDADE', 3) ?? 3,
  jadlogTpEntrega: text('JADLOG_TP_ENTREGA', 'D').toUpperCase() === 'R' ? 'R' : 'D',
  jadlogTpSeguro: text('JADLOG_TP_SEGURO', 'N').toUpperCase() === 'A' ? 'A' : 'N',
  jadlogBaseUrl: text('JADLOG_BASE_URL'),

  // Regra de divisão entre transportadoras: até N unidades → Correios;
  // acima de N unidades → Jadlog. 0 desativa (todas cotam sempre).
  carrierSplitUnits: Math.max(0, Math.min(999, int('CARRIER_SPLIT_UNITS', 12) ?? 12)),

  // E-mail transacional (SMTP)
  smtpHost: text('SMTP_HOST'),
  smtpPort: int('SMTP_PORT', 587) ?? 587,
  smtpUser: text('SMTP_USER'),
  smtpPassword: text('SMTP_PASSWORD'),
  smtpFrom: text('SMTP_FROM'),
  smtpFromName: text('SMTP_FROM_NAME', 'INTEGRALL'),
  smtpReplyTo: text('SMTP_REPLY_TO'),
  smtpSecure: bool('SMTP_SECURE', false),

  // Expiração automática de pedidos não pagos (0 desativa)
  orderExpireDays: Math.max(0, Math.min(90, int('ORDER_EXPIRE_DAYS', 7) ?? 7))
});

export function assertProductionConfig() {
  if (config.env !== 'production') return;
  const missing = [];
  if (!config.databaseUrl) missing.push('DATABASE_URL');
  if (!['disable', 'require', 'verify-full'].includes(config.databaseSslMode)) missing.push('DATABASE_SSL_MODE (disable, require ou verify-full)');
  if (config.databaseSslMode === 'disable') missing.push('DATABASE_SSL_MODE seguro em produção (verify-full recomendado)');
  if (!config.publicUrl || !/^https:\/\//i.test(config.publicUrl)) missing.push('PUBLIC_URL (HTTPS)');
  if (!config.adminEmail) missing.push('ADMIN_EMAIL');
  if (!config.adminPasswordHash) missing.push('ADMIN_PASSWORD_HASH');
  if (config.adminSessionSecret.length < 32) missing.push('ADMIN_SESSION_SECRET (mínimo 32 caracteres aleatórios)');
  if (!['admin', 'editor', 'operator'].includes(config.adminRole)) missing.push('ADMIN_ROLE (admin, editor ou operator)');
  if (config.mercadoPagoAccessToken && !config.mercadoPagoWebhookSecret) missing.push('MERCADO_PAGO_WEBHOOK_SECRET (obrigatório quando o Mercado Pago está ativo)');
  if (missing.length) throw new Error(`Configuração de produção incompleta: ${missing.join(', ')}`);
}

/**
 * Avisos de coerência entre configurações (não bloqueiam o boot, mas
 * denunciam combinações que degradam a operação silenciosamente).
 */
export function configWarnings() {
  const warnings = [];
  if (!['disable', 'require', 'verify-full'].includes(config.databaseSslMode)) {
    warnings.push('DATABASE_SSL_MODE inválido; use disable, require ou verify-full.');
  } else if (config.env === 'production' && config.databaseSslMode === 'require') {
    warnings.push('DATABASE_SSL_MODE=require cifra a conexão, mas não valida o certificado; prefira verify-full.');
  }
  if (!config.adminEmail || !config.adminPasswordHash || config.adminSessionSecret.length < 32) {
    warnings.push('Administração desativada: configure ADMIN_EMAIL, ADMIN_PASSWORD_HASH e ADMIN_SESSION_SECRET.');
  } else {
    if (config.adminDefaultLoginEnabled) warnings.push('Senha administrativa padrão ativa; desative-a com ADMIN_DEFAULT_LOGIN_ENABLED=false após cadastrar uma senha própria.');
    if (config.adminUsesBuiltInSessionSecret) warnings.push('ADMIN_SESSION_SECRET temporário em uso; defina um segredo exclusivo e persistente no ambiente de produção.');
  }
  if (config.env !== 'production' && config.publicUrl && !/^https:\/\//i.test(config.publicUrl)) {
    warnings.push('PUBLIC_URL não usa HTTPS; permitido somente fora de produção.');
  }
  if (config.shippingMode === 'correios') {
    const correiosReady = config.correiosUser && config.correiosAccessCode && config.correiosPostageCard && config.correiosOriginCep.length === 8;
    const jadlogReady = config.jadlogToken && config.jadlogCnpj.length === 14 && config.correiosOriginCep.length === 8;
    if (!correiosReady && !jadlogReady) {
      warnings.push('SHIPPING_MODE=correios sem credenciais completas de Correios nem Jadlog: TODOS os pedidos de entrega cairão em cotação manual.');
    }
  }
  if (config.orderExpireDays > 0 && config.mercadoPagoAccessToken && config.orderExpireDays < config.mercadoPagoExpirationDays) {
    warnings.push(`ORDER_EXPIRE_DAYS (${config.orderExpireDays}) é menor que a expiração da preferência do Mercado Pago (${config.mercadoPagoExpirationDays} dias): pedidos podem ser cancelados com link de pagamento ainda ativo (a proteção approved_after_cancel cobre, mas gera revisão manual).`);
  }
  if (config.smtpHost && (!config.smtpUser || !config.smtpPassword || !config.smtpFrom)) {
    warnings.push('SMTP_HOST definido mas SMTP_USER/SMTP_PASSWORD/SMTP_FROM incompletos: nenhum e-mail será enviado.');
  }
  return warnings;
}
