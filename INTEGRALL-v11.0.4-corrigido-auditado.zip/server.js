import express from 'express';
import process from 'node:process';
import {randomUUID} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {config, assertProductionConfig, configWarnings} from './src/config.js';
import {normalizeCatalog, publicCatalog, buildOrder, ORDER_STATUSES, cleanText, findCoupon, validateCoupon, couponDiscount} from './src/catalog.js';
import {Repository} from './src/repository.js';
import {securityHeaders, rateLimit, safeEqual} from './src/security.js';
import {MercadoPagoService, InvalidWebhookSignatureError} from './src/payments.js';
import {evaluatePayment} from './src/payment-state.js';
import {CorreiosService} from './src/correios.js';
import {JadlogService} from './src/jadlog.js';
import {Mailer, orderEmail} from './src/mailer.js';
import {AdminAuth} from './src/auth.js';
import {decodeLegacyDataUrl, ImageUploadError, mediaIdFromUrl, parseMultipartBody, validateAndSanitizeImage} from './src/image-upload.js';
import {assertOrderTransition} from './src/order-state.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');
const initialCatalog = normalizeCatalog(JSON.parse(await readFile(path.join(__dirname, 'data', 'catalog.json'), 'utf8')));
assertProductionConfig();

const repo = new Repository({
  databaseUrl: config.databaseUrl,
  initialCatalog,
  production: config.env === 'production',
  localDataDir: path.join(__dirname, 'data', 'local-state'),
  databaseSslMode: config.databaseSslMode,
  databaseCa: config.databaseCa,
  migrationsDir: path.join(__dirname, 'migrations')
});
await repo.init();
const adminAuth = new AdminAuth({
  email: config.adminEmail,
  passwordHash: config.adminPasswordHash,
  fallbackPasswordHash: config.adminFallbackPasswordHash,
  role: config.adminRole,
  sessionSecret: config.adminSessionSecret,
  sessionHours: config.adminSessionHours,
  secureCookies: config.env === 'production' || /^https:\/\//i.test(config.publicUrl),
  publicUrl: config.publicUrl
});
const mercadoPago = new MercadoPagoService({
  accessToken: config.mercadoPagoAccessToken,
  webhookSecret: config.mercadoPagoWebhookSecret,
  sandbox: config.mercadoPagoUseSandbox,
  expirationDays: config.mercadoPagoExpirationDays
});
const correios = new CorreiosService({
  user: config.correiosUser,
  accessCode: config.correiosAccessCode,
  postageCard: config.correiosPostageCard,
  contract: config.correiosContract,
  originCep: config.correiosOriginCep,
  services: config.correiosServices,
  homolog: config.correiosHomolog,
  baseUrl: config.correiosBaseUrl,
  apiVersion: config.correiosApiVersion
});
const jadlog = new JadlogService({
  token: config.jadlogToken,
  cnpj: config.jadlogCnpj,
  conta: config.jadlogConta,
  contrato: config.jadlogContrato,
  originCep: config.correiosOriginCep, // CEP de origem da loja (compartilhado)
  modalidade: config.jadlogModalidade,
  tpEntrega: config.jadlogTpEntrega,
  tpSeguro: config.jadlogTpSeguro,
  baseUrl: config.jadlogBaseUrl
});
const mailer = new Mailer({
  host: config.smtpHost,
  port: config.smtpPort,
  user: config.smtpUser,
  password: config.smtpPassword,
  from: config.smtpFrom,
  fromName: config.smtpFromName,
  replyTo: config.smtpReplyTo,
  secure: config.smtpSecure
});

const EMAIL_STATUS_EVENTS = new Set(['paid', 'payment_failed', 'payment_expired', 'preparing', 'ready', 'completed', 'refunded', 'cancelled']);

// Deduplicação de e-mails de status: webhooks reenviados (retry do Mercado
// Pago) não devem disparar o mesmo aviso duas vezes. Chave: pedido+status.
const notifiedStatuses = new Map();
const NOTIFIED_MAX = 2000;

function sendOrderEmail(order, kind) {
  if (!mailer.configured || !order?.customer?.email) return;
  if (kind === 'status') {
    const key = `${order.id}|${order.status}${order.trackingCode ? `|${order.trackingCode}` : ''}`;
    if (notifiedStatuses.has(key)) return;
    if (notifiedStatuses.size >= NOTIFIED_MAX) notifiedStatuses.delete(notifiedStatuses.keys().next().value);
    notifiedStatuses.set(key, Date.now());
  }
  const businessName = 'INTEGRALL';
  const message = orderEmail(order, {kind, publicUrl: config.publicUrl, businessName});
  mailer.send({to: order.customer.email, ...message}).then(result => {
    if (!result.ok) console.error(`E-mail não enviado (pedido ${order.id}): ${result.error}`);
  }).catch(error => console.error(`E-mail não enviado (pedido ${order.id}):`, error));
}

const app = express();

function safeLogMessage(value) {
  return String(value || '')
    .replace(/(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]+/gi, '$1 [REDACTED]')
    .replace(/(token|secret|password|authorization)(\s*[:=]\s*)[^\s,;]+/gi, '$1$2[REDACTED]')
    .slice(0, 800);
}

function logEvent(level, event, details = {}) {
  const payload = JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    event,
    ...details
  });
  if (level === 'error') console.error(payload);
  else if (level === 'warn') console.warn(payload);
  else process.stdout.write(`${payload}\n`);
}
if (config.trustProxy) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((req, res, next) => {
  const supplied = String(req.headers['x-request-id'] || '');
  req.id = /^[A-Za-z0-9._:-]{8,120}$/.test(supplied) ? supplied : randomUUID();
  res.setHeader('X-Request-Id', req.id);
  const json = res.json.bind(res);
  res.json = payload => {
    if (res.statusCode >= 400 && payload && typeof payload === 'object' && !Array.isArray(payload)) {
      payload.requestId ||= req.id;
      payload.code ||= `HTTP_${res.statusCode}`;
    }
    return json(payload);
  };
  next();
});
app.use(securityHeaders);
app.use('/api/admin', (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
  next();
});
const publicJson = express.json({limit: '64kb', strict: true});
const adminCatalogJson = express.json({limit: '2mb', strict: true});
const adminLegacyMediaJson = express.json({limit: '10mb', strict: true});
const adminMediaRaw = express.raw({type: 'multipart/form-data', limit: '10.25mb'});

const orderLimiter = rateLimit({windowMs: 60_000, max: 20});
const statusLimiter = rateLimit({windowMs: 60_000, max: 60});
const paymentLimiter = rateLimit({windowMs: 60_000, max: 30});
const webhookLimiter = rateLimit({windowMs: 60_000, max: 180});
const adminLimiter = rateLimit({windowMs: 60_000, max: 90});
const adminLoginLimiter = rateLimit({windowMs: 15 * 60_000, max: 10});
const readLimiter = rateLimit({windowMs: 60_000, max: 120});

const adminOrdersRead = adminAuth.requirePermission('orders:read');
const adminOrdersWrite = adminAuth.requirePermission('orders:write');
const adminCustomersRead = adminAuth.requirePermission('customers:read');
const adminCatalogRead = adminAuth.requirePermission('catalog:read');
const adminCatalogWrite = adminAuth.requirePermission('catalog:write');
const adminMediaWrite = adminAuth.requirePermission('media:write');
const adminAuditRead = adminAuth.requirePermission('audit:read');
const adminSession = adminAuth.requireSession();

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

async function auditAdmin(req, action, entityType, entityId = '', metadata = {}) {
  try {
    await repo.recordAudit({
      requestId: req.id,
      actor: req.admin?.email || 'system',
      role: req.admin?.role || '',
      action,
      entityType,
      entityId,
      metadata
    });
  } catch (error) {
    console.error(JSON.stringify({level: 'error', event: 'audit_log_failed', requestId: req.id, message: error?.message || String(error)}));
  }
}

function catalogMediaReferences(catalog, mediaId) {
  const references = [];
  const expectedUrl = `/media/products/${mediaId}`;
  for (const product of catalog?.products || []) {
    if ((product.images || []).includes(expectedUrl)) references.push({type: 'product', id: product.id, name: product.name});
  }
  const assets = catalog?.settings?.visual?.assets || {};
  for (const [key, value] of Object.entries(assets)) {
    if (value === expectedUrl) references.push({type: 'visual_asset', id: key, name: key});
  }
  return references;
}

function mediaResponse(item) {
  if (!item) return null;
  return {
    id: item.id,
    url: `/media/products/${item.id}`,
    mimeType: item.mimeType,
    size: item.size,
    width: item.width,
    height: item.height,
    altText: item.altText || '',
    checksum: item.checksum || '',
    originalName: item.originalName || '',
    uploadedBy: item.uploadedBy || '',
    purpose: item.purpose || 'product',
    processingStatus: item.processingStatus || 'ready',
    createdAt: item.createdAt || '',
    updatedAt: item.updatedAt || ''
  };
}

function publicBaseUrl(req) {
  if (config.publicUrl) return config.publicUrl;
  if (config.renderExternalHostname) return `https://${config.renderExternalHostname}`;
  if (config.env === 'production') return '';
  return `${req.protocol}://${req.get('host')}`.replace(/\/$/, '');
}

function paymentCanStart(order) {
  // payment_review (mediação/divergência) também bloqueia: um novo checkout
  // durante mediação poderia gerar cobrança dupla ao cliente.
  return !['paid', 'preparing', 'ready', 'completed', 'refunded', 'chargeback', 'cancelled', 'payment_review'].includes(order?.status);
}

function publicOrder(order) {
  return {
    id: order.id,
    status: order.status,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    subtotalCents: order.subtotalCents,
    shippingCents: order.shippingCents,
    discountCents: Number(order.discountCents) || 0,
    coupon: order.coupon?.code || '',
    trackingCode: order.trackingCode || '',
    trackingCarrier: order.trackingCarrier || '',
    trackingUrl: order.trackingUrl || '',
    totalCents: order.totalCents,
    requiresShippingQuote: Boolean(order.requiresShippingQuote),
    shipping: {
      choice: order.shipping?.choice || '',
      cep: order.shipping?.cep || '',
      label: order.shipping?.label || '',
      days: order.shipping?.days || ''
    },
    items: (order.items || []).map(item => ({
      name: item.name,
      variant: item.variant,
      qty: item.qty,
      lineTotalCents: item.lineTotalCents
    })),
    payment: {
      provider: order.payment?.provider || '',
      status: order.payment?.status || '',
      statusDetail: order.payment?.statusDetail || '',
      approvedAt: order.payment?.approvedAt || ''
    },
    history: (order.history || []).slice(-30).map(event => ({
      at: event.at,
      status: event.status,
      source: event.source,
      note: event.note || ''
    })),
    onlinePaymentAvailable: mercadoPago.configured && paymentCanStart(order) && !order.requiresShippingQuote
  };
}

function centsFromBody(value) {
  const number = Number(value);
  if (!Number.isSafeInteger(number) || number < 0 || number > 100_000_000) return null;
  return number;
}

app.get('/api/admin/session', adminLimiter, (req, res) => {
  res.setHeader('Vary', 'Cookie');
  const session = adminAuth.readSession(req);
  if (!session) return res.json({configured: adminAuth.configured, authenticated: false});
  res.json({
    configured: true,
    authenticated: true,
    user: {email: session.sub, role: session.role},
    csrfToken: session.csrf,
    expiresAt: new Date(session.exp * 1000).toISOString()
  });
});

app.post('/api/admin/session/login', adminLoginLimiter, publicJson, asyncRoute(async (req, res) => {
  if (!adminAuth.configured) {
    return res.status(503).json({code: 'ADMIN_NOT_CONFIGURED', error: 'A administração segura ainda não foi configurada.'});
  }
  const email = cleanText(req.body?.email, 254).toLowerCase();
  const password = String(req.body?.password || '');
  const user = await adminAuth.authenticate(email, password);
  if (!user) {
    await auditAdmin(req, 'login_failed', 'admin_session', '', {emailProvided: Boolean(email)});
    return res.status(401).json({code: 'ADMIN_LOGIN_INVALID', error: 'E-mail ou senha inválidos.'});
  }
  const session = adminAuth.createSession(user);
  res.setHeader('Set-Cookie', session.cookie);
  res.setHeader('Vary', 'Cookie');
  await auditAdmin({...req, admin: user}, 'login_succeeded', 'admin_session', user.email);
  res.json({
    authenticated: true,
    user,
    csrfToken: session.payload.csrf,
    expiresAt: session.expiresAt
  });
}));

app.post('/api/admin/session/logout', adminLimiter, adminSession, asyncRoute(async (req, res) => {
  res.setHeader('Set-Cookie', adminAuth.clearCookie());
  await auditAdmin(req, 'logout', 'admin_session', req.admin.email);
  res.json({ok: true});
}));

app.get('/api/health', readLimiter, asyncRoute(async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const databaseHealth = await repo.health();
  res.json({
    ok: true,
    name: 'INTEGRALL API',
    version: '11.0.2',
    database: databaseHealth.ok ? 'available' : 'unavailable',
    mercadoPago: mercadoPago.configured,
    adminConfigured: adminAuth.configured,
    features: {
      persistentOrders: databaseHealth.mode === 'postgresql',
      orderTracking: true,
      inventoryOnPaid: true,
      shippingQuoteAdmin: true,
      customers: true,
      correiosShipping: carrierShippingEnabled(),
      carriers: [
        ...(config.shippingMode === 'correios' && correios.configured ? ['correios'] : []),
        ...(config.shippingMode === 'correios' && jadlog.configured ? ['jadlog'] : [])
      ],
      transactionalEmail: mailer.configured,
      orderAutoExpire: config.orderExpireDays > 0
    },
    time: new Date().toISOString()
  });
}));

app.get('/api/catalog', readLimiter, asyncRoute(async (_req, res) => {
  const catalog = await repo.getCatalog();
  res.setHeader('Cache-Control', 'public, max-age=60, stale-while-revalidate=300');
  res.json(publicCatalog(catalog, config));
}));

// Subtotal server-side dos itens (preços do catálogo) para o Valor Declarado
// do seguro dos Correios — nunca confia em valores vindos do navegador.
function estimateSubtotalCents(items, productsById) {
  let total = 0;
  for (const line of Array.isArray(items) ? items : []) {
    const product = productsById.get(cleanText(line?.productId, 120));
    if (!product) continue;
    const variant = line?.variantId ? (product.variants || []).find(v => v.id === cleanText(line.variantId, 120)) : null;
    const unit = Number(variant?.price ?? product.price) || 0;
    const qty = Math.max(1, Math.min(999, Number(line?.qty) || 1));
    total += unit * qty;
  }
  return Number.isSafeInteger(total) && total > 0 ? total : 0;
}

const carrierShippingEnabled = () => config.shippingMode === 'correios' && (correios.configured || jadlog.configured);

/** Total de unidades físicas do pedido (garrafas, caixas de biscoito etc.). */
function countOrderUnits(items) {
  let units = 0;
  for (const line of Array.isArray(items) ? items : []) {
    units += Math.max(1, Math.min(999, Number(line?.qty) || 1));
  }
  return units;
}

/**
 * Consulta as transportadoras elegíveis em paralelo e retorna as opções
 * combinadas, ordenadas por preço.
 *
 * REGRA DE DIVISÃO (CARRIER_SPLIT_UNITS, padrão 12): pedidos de até N
 * unidades são enviados pelos Correios; acima de N unidades, pela Jadlog
 * (multi-volume nos Correios sai caro; a Jadlog ganha em carga maior).
 * Se a transportadora preferida não estiver configurada ou falhar, a outra
 * entra como reserva — o cliente nunca fica sem frete por causa da regra.
 */
async function quoteAllCarriers(cep, pack, declaredCents, totalUnits = 0) {
  const available = [];
  if (correios.configured) available.push({name: 'Correios', prefixLabel: label => `Correios ${label}`, service: correios});
  if (jadlog.configured) available.push({name: 'Jadlog', prefixLabel: label => label, service: jadlog});
  if (!available.length) throw new Error('Nenhuma transportadora configurada.');

  let carriers = available;
  const split = config.carrierSplitUnits;
  if (split > 0 && available.length > 1) {
    const preferredName = totalUnits > split ? 'Jadlog' : 'Correios';
    carriers = available.filter(carrier => carrier.name === preferredName);
    if (!carriers.length) carriers = available;
  }

  const attempt = async group => {
    const settled = await Promise.allSettled(group.map(carrier => carrier.service.quote(cep, pack, declaredCents)));
    const options = [];
    const errors = [];
    for (const [index, result] of settled.entries()) {
      if (result.status === 'fulfilled') {
        for (const option of result.value.options) {
          options.push({...option, label: group[index].prefixLabel(option.label)});
        }
      } else {
        errors.push(`${group[index].name}: ${result.reason?.message || result.reason}`);
      }
    }
    return {options, errors};
  };

  let {options, errors} = await attempt(carriers);

  // Fallback: se a transportadora preferida pela regra falhou, tenta as demais.
  if (!options.length && carriers.length < available.length) {
    const backup = available.filter(carrier => !carriers.includes(carrier));
    const retry = await attempt(backup);
    options = retry.options;
    errors = errors.concat(retry.errors);
  }

  if (!options.length) throw new Error(errors.join(' | ') || 'Nenhuma transportadora retornou preço.');
  if (errors.length) console.error('Transportadora(s) indisponível(is) na cotação:', errors.join(' | '));
  options.sort((a, b) => a.priceCents - b.priceCents);
  return {options, cheapest: options[0]};
}

async function resolveCorreiosShipping(body, catalog) {
  if (!carrierShippingEnabled()) return null;
  if (body?.shipping?.choice !== 'delivery') return null;
  try {
    const productsById = new Map(catalog.products.map(product => [product.id, product]));
    const declaredCents = estimateSubtotalCents(body.items, productsById);
    // Acima do limiar de frete grátis, buildOrder zera o frete de qualquer
    // forma — não gasta chamadas de API das transportadoras à toa.
    const freeThreshold = Number(config.freeShippingCents ?? catalog.settings?.free) || 0;
    if (freeThreshold > 0 && declaredCents >= freeThreshold) return null;
    const pack = correios.packOrder(Array.isArray(body.items) ? body.items : [], productsById);
    const requestedService = cleanText(body?.shipping?.service, 20);
    const result = await quoteAllCarriers(body.shipping.cep, pack, declaredCents, countOrderUnits(body.items));
    const chosen = (requestedService && result.options.find(option => option.code === requestedService)) || result.cheapest;
    return {
      priceCents: chosen.priceCents,
      label: chosen.label,
      days: chosen.days != null ? `${chosen.days} dia(s) útil(eis)` : '',
      service: chosen.code
    };
  } catch (error) {
    console.error('Cotação de frete indisponível; pedido seguirá para cotação manual.', error?.message || error);
    return null;
  }
}

app.post('/api/shipping/quote', statusLimiter, publicJson, asyncRoute(async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (!carrierShippingEnabled()) {
    return res.status(404).json({error: 'Cotação automática de frete não está habilitada.'});
  }
  const cep = cleanText(req.body?.cep, 10).replace(/\D/g, '');
  if (cep.length !== 8) return res.status(400).json({error: 'Informe um CEP válido com 8 dígitos.'});
  const items = Array.isArray(req.body?.items) ? req.body.items.slice(0, 100) : [];
  if (!items.length) return res.status(400).json({error: 'Informe os itens do pedido.'});
  const catalog = await repo.getCatalog();
  const productsById = new Map(catalog.products.map(product => [product.id, product]));
  const pack = correios.packOrder(items, productsById);
  const subtotalCents = estimateSubtotalCents(items, productsById);

  // Frete grátis por limiar: buildOrder zera o frete acima de FREE_SHIPPING_CENTS.
  // A cotação precisa refletir a MESMA regra — sem isso o cliente veria um
  // preço aqui e outro (grátis) no fechamento.
  const freeThreshold = Number(config.freeShippingCents ?? catalog.settings?.free) || 0;
  if (freeThreshold > 0 && subtotalCents >= freeThreshold) {
    return res.json({options: [{service: 'FREE', label: 'Frete grátis', priceCents: 0, days: null, volumes: 1}]});
  }

  try {
    const result = await quoteAllCarriers(cep, pack, subtotalCents, countOrderUnits(items));
    res.json({
      options: result.options.map(option => ({
        service: option.code,
        label: option.label,
        priceCents: option.priceCents,
        days: option.days,
        volumes: option.volumes || 1
      }))
    });
  } catch (error) {
    res.status(502).json({error: error?.message || 'Não foi possível cotar o frete agora.'});
  }
}));

app.post('/api/orders', orderLimiter, publicJson, asyncRoute(async (req, res) => {
  const catalog = await repo.getCatalog();
  let order;
  try {
    // Segurança: 'resolved' é sempre descartado do corpo recebido e só é
    // preenchido pela cotação server-side dos Correios.
    const cleanShipping = {...(req.body?.shipping || {})};
    delete cleanShipping.resolved;
    const cleanBody = {...req.body, shipping: cleanShipping};
    const resolved = await resolveCorreiosShipping(cleanBody, catalog);
    const payload = resolved ? {...cleanBody, shipping: {...cleanShipping, resolved}} : cleanBody;
    order = buildOrder(payload, catalog, config);
  } catch (error) {
    return res.status(400).json({error: error?.message || 'Pedido inválido.'});
  }
  const result = await repo.createOrder(order);
  if (result.created) sendOrderEmail(result.order, 'created');
  res.status(result.created ? 201 : 200).json({
    order: {
      id: result.order.id,
      status: result.order.status,
      subtotalCents: result.order.subtotalCents,
      shippingCents: result.order.shippingCents,
      discountCents: Number(result.order.discountCents) || 0,
      coupon: result.order.coupon?.code || '',
      totalCents: result.order.totalCents,
      requiresShippingQuote: result.order.requiresShippingQuote,
      checkoutToken: result.order.checkoutToken,
      // paymentCanStart cobre o replay idempotente: se o clientOrderId repetido
      // devolve um pedido já pago/cancelado, não podemos anunciar pagamento.
      onlinePaymentAvailable: mercadoPago.configured && paymentCanStart(result.order) && !result.order.requiresShippingQuote
    },
    idempotent: !result.created
  });
}));

app.post('/api/coupons/validate', statusLimiter, publicJson, asyncRoute(async (req, res) => {
  const code = cleanText(req.body?.code, 40).toUpperCase();
  if (!code) return res.status(400).json({error: 'Informe o código do cupom.'});
  const subtotalCents = Number(req.body?.subtotalCents);
  const safeSubtotal = Number.isSafeInteger(subtotalCents) && subtotalCents > 0 ? subtotalCents : 0;
  const shippingChoice = cleanText(req.body?.shippingChoice, 20);
  const catalog = await repo.getCatalog();
  const coupon = findCoupon(catalog, code);
  const check = validateCoupon(coupon, {subtotalCents: safeSubtotal, shippingChoice, shippingQuoted: Boolean(req.body?.shippingQuoted)});
  res.setHeader('Cache-Control', 'no-store');
  if (!check.ok) return res.status(404).json({error: check.error || 'Cupom inválido.'});
  res.json({
    coupon: {code: coupon.code, type: coupon.type, value: coupon.value, note: coupon.note || ''},
    discountCents: safeSubtotal ? couponDiscount(coupon, safeSubtotal, 0) : 0
  });
}));

// Cache de rastreio: os eventos mudam poucas vezes ao dia; 15 min evita
// abusar das APIs das transportadoras em recarregamentos do cliente.
const trackingCache = new Map();
const TRACKING_CACHE_TTL_MS = 15 * 60 * 1000;

app.post('/api/orders/tracking', statusLimiter, publicJson, asyncRoute(async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const orderId = cleanText(req.body?.orderId, 100);
  const checkoutToken = cleanText(req.body?.checkoutToken, 128);
  if (!orderId || !checkoutToken) return res.status(400).json({error: 'Número do pedido e autorização são obrigatórios.'});
  const order = await repo.getOrder(orderId);
  if (!order || !safeEqual(checkoutToken, order.checkoutToken)) return res.status(404).json({error: 'Pedido não encontrado.'});
  if (!order.trackingCode) return res.status(404).json({error: 'Este pedido ainda não possui código de rastreio.'});

  const cacheKey = order.trackingCode;
  const cached = trackingCache.get(cacheKey);
  if (cached && Date.now() - cached.at < TRACKING_CACHE_TTL_MS) return res.json(cached.value);

  // Detecta a transportadora: etiqueta Correios = AA123456789BR; Jadlog = numérica.
  const isCorreiosCode = /^[A-Z]{2}\d{9}[A-Z]{2}$/i.test(order.trackingCode);
  const trackers = [];
  if (isCorreiosCode && correios.configured) trackers.push(correios);
  if (!isCorreiosCode && jadlog.configured) trackers.push(jadlog);
  // fallback: tenta qualquer transportadora configurada
  if (!trackers.length) {
    if (correios.configured) trackers.push(correios);
    if (jadlog.configured) trackers.push(jadlog);
  }
  if (!trackers.length) return res.status(503).json({error: 'Rastreamento automático não está configurado.', trackingUrl: order.trackingUrl || ''});

  let lastError = null;
  for (const tracker of trackers) {
    try {
      const result = await tracker.trackShipment(order.trackingCode);
      const value = {
        carrier: result.carrier,
        code: result.code,
        expectedDelivery: result.expectedDelivery || '',
        trackingUrl: order.trackingUrl || '',
        events: result.events.slice(0, 20)
      };
      if (trackingCache.size >= 500) trackingCache.delete(trackingCache.keys().next().value);
      trackingCache.set(cacheKey, {at: Date.now(), value});
      return res.json(value);
    } catch (error) {
      lastError = error;
    }
  }
  res.status(502).json({error: lastError?.message || 'Rastreamento indisponível no momento.', trackingUrl: order.trackingUrl || ''});
}));

app.post('/api/orders/status', statusLimiter, publicJson, asyncRoute(async (req, res) => {
  const orderId = cleanText(req.body?.orderId, 100);
  const checkoutToken = cleanText(req.body?.checkoutToken, 128);
  if (!orderId || !checkoutToken) return res.status(400).json({error: 'Número do pedido e autorização são obrigatórios.'});
  const order = await repo.getOrder(orderId);
  if (!order || !safeEqual(checkoutToken, order.checkoutToken)) return res.status(404).json({error: 'Pedido não encontrado.'});
  res.setHeader('Cache-Control', 'no-store');
  res.json({order: publicOrder(order)});
}));

app.post('/api/payments/checkout', paymentLimiter, publicJson, asyncRoute(async (req, res) => {
  if (!mercadoPago.configured) return res.status(503).json({error: 'Pagamento online ainda não está configurado.'});
  const orderId = cleanText(req.body?.orderId, 100);
  const checkoutToken = cleanText(req.body?.checkoutToken, 128);
  if (!orderId || !checkoutToken) return res.status(400).json({error: 'orderId e checkoutToken são obrigatórios.'});
  const order = await repo.getOrder(orderId);
  if (!order || !safeEqual(checkoutToken, order.checkoutToken)) return res.status(404).json({error: 'Pedido não encontrado.'});
  if (!paymentCanStart(order)) return res.status(409).json({error: 'Este pedido não aceita um novo pagamento.'});
  if (order.requiresShippingQuote && !config.allowPaymentWithQuotedShipping) {
    return res.status(409).json({error: 'O frete deste pedido ainda precisa ser definido antes do pagamento online.'});
  }
  const base = publicBaseUrl(req);
  if (!/^https:\/\//i.test(base)) return res.status(503).json({error: 'Configure PUBLIC_URL com HTTPS antes de habilitar o Mercado Pago.'});

  const attempt = Math.max(1, Math.min(99, Number(order.payment?.attempt || 0) + 1));
  const checkout = await mercadoPago.createCheckout(order, base, attempt);
  await repo.updateOrder(order.id, {
    status: 'awaiting_payment',
    payment: {provider: 'mercadopago', preferenceId: checkout.id, status: 'pending', statusDetail: '', attempt}
  }, {source: 'payment', note: `Pagamento Mercado Pago iniciado (tentativa ${attempt}).`});
  res.json({url: checkout.url, preferenceId: checkout.id, orderId: order.id});
}));

app.post('/api/webhooks/mercadopago', webhookLimiter, publicJson, asyncRoute(async (req, res) => {
  const dataId = req.query['data.id'] || req.body?.data?.id;
  const type = req.query.type || req.body?.type;
  if (type && type !== 'payment') return res.status(200).json({ok: true, ignored: true});
  if (!dataId) return res.status(400).json({error: 'data.id ausente.'});

  try {
    mercadoPago.validateWebhook({
      xSignature: req.headers['x-signature'],
      xRequestId: req.headers['x-request-id'],
      dataId
    });
  } catch (error) {
    if (error instanceof InvalidWebhookSignatureError) return res.status(401).json({error: 'Assinatura inválida.'});
    throw error;
  }

  const payment = await mercadoPago.getPayment(dataId);
  const orderId = cleanText(payment.external_reference || payment.metadata?.order_id, 100);
  if (!orderId) return res.status(200).json({ok: true, ignored: true});
  const order = await repo.getOrder(orderId);
  if (!order) return res.status(200).json({ok: true, ignored: true});

  // A avaliação roda DENTRO do lock do pedido (forma funcional do
  // updateOrder), sobre o estado mais recente. Sem isso haveria TOCTOU:
  // admin cancela entre a leitura e a gravação → 'approved' avaliado sobre o
  // estado antigo ressuscitaria o pedido cancelado como pago.
  let lastEvaluation = null;
  const updated = await repo.updateOrder(order.id, current => {
    const evaluation = evaluatePayment(current, payment);
    lastEvaluation = evaluation;
    if (!evaluation.shouldUpdate) return null; // aborta sem gravar
    return {
      status: evaluation.nextStatus,
      payment: {
        provider: 'mercadopago',
        preferenceId: current.payment?.preferenceId || payment.preference_id || '',
        paymentId: String(payment.id),
        status: evaluation.paymentStatus,
        statusDetail: cleanText(payment.status_detail, 160),
        approvedAt: payment.date_approved || '',
        refundedCents: Math.round(Number(payment.transaction_amount_refunded || 0) * 100)
      }
    };
  }, current => ({
    source: 'mercadopago-webhook',
    note: `Pagamento atualizado para ${lastEvaluation?.paymentStatus || payment.status || 'desconhecido'}.`
  }));

  if (lastEvaluation && !lastEvaluation.shouldUpdate) {
    // Divergência ignorada (ex.: 2º pagamento com outra preferência num pedido
    // já pago) precisa ficar VISÍVEL no pedido: pode haver dinheiro do cliente
    // retido sem registro. Grava no histórico para o admin tratar/reembolsar.
    if (lastEvaluation.warning) {
      await repo.updateOrder(order.id, {}, {
        source: 'mercadopago-webhook',
        note: `ATENÇÃO: webhook ignorado (${lastEvaluation.warning}) — pagamento ${payment.id} status ${payment.status || '?'} valor ${payment.transaction_amount ?? '?'}. Verifique se há cobrança duplicada para reembolsar.`
      }).catch(error => console.error('Falha ao registrar warning de webhook:', error?.message || error));
    }
    return res.status(200).json({ok: true, ignored: true, ...(lastEvaluation.warning ? {warning: lastEvaluation.warning} : {})});
  }

  if (updated && order.status !== updated.status && EMAIL_STATUS_EVENTS.has(updated.status)) sendOrderEmail(updated, 'status');
  res.status(200).json({ok: true});
}));

app.get('/api/admin/orders', adminLimiter, adminOrdersRead, asyncRoute(async (req, res) => {
  const status = cleanText(req.query.status, 30);
  const search = cleanText(req.query.search, 120);
  const orders = await repo.listOrders({status, search, limit: Number(req.query.limit) || 300});
  res.json({orders});
}));

app.get('/api/admin/orders/:id', adminLimiter, adminOrdersRead, asyncRoute(async (req, res) => {
  const order = await repo.getOrder(cleanText(req.params.id, 100));
  if (!order) return res.status(404).json({error: 'Pedido não encontrado.'});
  res.json({order});
}));

app.patch('/api/admin/orders/:id', adminLimiter, adminOrdersWrite, publicJson, asyncRoute(async (req, res) => {
  const orderId = cleanText(req.params.id, 100);
  const status = cleanText(req.body?.status, 30);
  if (!ORDER_STATUSES.includes(status)) return res.status(400).json({code: 'ORDER_STATUS_INVALID', error: 'Status inválido.'});
  const previous = await repo.getOrder(orderId);
  if (!previous) return res.status(404).json({error: 'Pedido não encontrado.'});
  try {
    assertOrderTransition(previous.status, status);
  } catch (error) {
    return res.status(409).json({code: error.code || 'ORDER_TRANSITION_INVALID', error: error.message});
  }
  const note = cleanText(req.body?.note, 300) || 'Status alterado pelo painel administrativo.';
  const order = await repo.updateOrder(orderId, {status}, {source: 'admin', note});
  if (previous.status !== order.status && EMAIL_STATUS_EVENTS.has(order.status)) sendOrderEmail(order, 'status');
  await auditAdmin(req, 'order_status_updated', 'order', orderId, {from: previous.status, to: order.status, note});
  res.json({order});
}));

app.patch('/api/admin/orders/:id/shipping', adminLimiter, adminOrdersWrite, publicJson, asyncRoute(async (req, res) => {
  const orderId = cleanText(req.params.id, 100);
  const order = await repo.getOrder(orderId);
  if (!order) return res.status(404).json({error: 'Pedido não encontrado.'});
  if (order.shipping?.choice !== 'delivery') return res.status(409).json({error: 'Este pedido é para retirada e não precisa de cotação de frete.'});
  if (['paid', 'preparing', 'ready', 'completed', 'refunded', 'chargeback'].includes(order.status)) {
    return res.status(409).json({error: 'O frete não pode ser alterado depois da confirmação financeira/operacional.'});
  }
  // Com pagamento em andamento, a preferência do Mercado Pago com o TOTAL
  // ANTIGO ainda está ativa: se o frete mudasse agora, o cliente poderia pagar
  // o valor antigo pela URL que já recebeu e ter o pagamento recusado pelo
  // webhook (amount_mismatch). Bloqueia até a tentativa expirar/falhar.
  if (order.status === 'awaiting_payment') {
    return res.status(409).json({error: 'Há um pagamento em andamento com o total atual. Aguarde a conclusão ou expiração da tentativa antes de alterar o frete.'});
  }
  const shippingCents = centsFromBody(req.body?.shippingCents);
  if (shippingCents == null) return res.status(400).json({error: 'Informe o frete em centavos (zero ou valor positivo).'});
  const label = cleanText(req.body?.label, 160) || 'Frete confirmado pela loja';

  // Recalcula o desconto quando o cupom depende do frete (free_shipping):
  // se o admin muda o frete, o desconto acompanha; um desconto congelado do
  // valor antigo geraria total errado.
  let discountCents = Number(order.discountCents) || 0;
  if (order.coupon?.type === 'free_shipping') {
    discountCents = shippingCents;
  }

  const totalCents = Number(order.subtotalCents || 0) + shippingCents - discountCents;
  if (totalCents <= 0) return res.status(400).json({error: 'O frete informado deixaria o total do pedido inválido.'});
  const updated = await repo.updateOrder(orderId, {
    shipping: {priceCents: shippingCents, quoted: false, label},
    shippingCents,
    discountCents,
    totalCents,
    requiresShippingQuote: false
  }, {source: 'admin', note: `Frete definido em ${shippingCents} centavos${order.coupon?.type === 'free_shipping' ? ` (cupom ${order.coupon.code}: frete grátis, desconto ajustado)` : ''}.`});
  await auditAdmin(req, 'order_shipping_updated', 'order', orderId, {shippingCents, discountCents, totalCents, label});
  res.json({order: updated});
}));

app.patch('/api/admin/orders/:id/tracking', adminLimiter, adminOrdersWrite, publicJson, asyncRoute(async (req, res) => {
  const orderId = cleanText(req.params.id, 100);
  const order = await repo.getOrder(orderId);
  if (!order) return res.status(404).json({error: 'Pedido não encontrado.'});
  if (order.shipping?.choice !== 'delivery') return res.status(409).json({error: 'Este pedido é para retirada e não possui envio.'});
  const trackingCode = cleanText(req.body?.trackingCode, 80).toUpperCase().replace(/\s+/g, '');
  const trackingCarrier = cleanText(req.body?.trackingCarrier, 80);
  let trackingUrl = cleanText(req.body?.trackingUrl, 500);
  if (trackingUrl && !/^https:\/\/[^\s]+$/i.test(trackingUrl)) return res.status(400).json({error: 'O link de rastreio precisa ser uma URL HTTPS.'});
  // Link automático correto por transportadora: etiqueta Correios (AA…BR)
  // ganha link dos Correios; código numérico (Jadlog) ganha o tracking Jadlog.
  if (!trackingUrl && trackingCode) {
    if (/^[A-Z]{2}\d{9}[A-Z]{2}$/.test(trackingCode)) {
      trackingUrl = `https://rastreamento.correios.com.br/app/index.php?objetos=${encodeURIComponent(trackingCode)}`;
    } else if (/^\d{8,14}$/.test(trackingCode)) {
      trackingUrl = `https://www.jadlog.com.br/tracking?cte=${encodeURIComponent(trackingCode)}`;
    }
  }
  const note = trackingCode
    ? `Código de rastreio informado: ${trackingCode}${trackingCarrier ? ` (${trackingCarrier})` : ''}.`
    : 'Código de rastreio removido.';
  const updated = await repo.updateOrder(orderId, {
    trackingCode,
    trackingCarrier,
    trackingUrl: trackingCode ? trackingUrl : ''
  }, {source: 'admin', note});
  // Invalida o cache de rastreio dos códigos envolvidos (antigo e novo):
  // o cliente vê os eventos certos imediatamente após a troca.
  if (order.trackingCode) trackingCache.delete(order.trackingCode);
  if (trackingCode) trackingCache.delete(trackingCode);
  if (trackingCode && updated) sendOrderEmail(updated, 'status');
  await auditAdmin(req, 'order_tracking_updated', 'order', orderId, {trackingCode, trackingCarrier, trackingUrl: trackingUrl || ''});
  res.json({order: updated});
}));

app.get('/api/admin/customers', adminLimiter, adminCustomersRead, asyncRoute(async (req, res) => {
  const search = cleanText(req.query.search, 120);
  const customers = await repo.listCustomers({search, limit: Number(req.query.limit) || 300});
  res.json({customers});
}));

app.get('/api/admin/products', adminLimiter, adminCatalogRead, asyncRoute(async (_req, res) => {
  const catalog = await repo.getCatalog();
  res.json({products: catalog.products || []});
}));

class HttpError extends Error {
  constructor(status, message, code = '') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function newId(prefix) {
  return `${prefix}-${randomUUID()}`;
}

function parseAdminMedia(req, res, next) {
  if (String(req.headers['content-type'] || '').toLowerCase().startsWith('multipart/form-data')) {
    return adminMediaRaw(req, res, next);
  }
  return adminLegacyMediaJson(req, res, next);
}

app.post(['/api/admin/media', '/api/admin/media/product-image'], adminLimiter, adminMediaWrite, parseAdminMedia, asyncRoute(async (req, res) => {
  try {
    const input = Buffer.isBuffer(req.body)
      ? parseMultipartBody(req.body, req.headers['content-type'])
      : decodeLegacyDataUrl(req.body?.dataUrl);
    const parsed = validateAndSanitizeImage(input);
    const now = new Date().toISOString();
    const id = newId('media');
    const stored = await repo.saveMedia({
      id,
      storageKey: id,
      mimeType: parsed.mimeType,
      data: parsed.data,
      size: parsed.size,
      width: parsed.width,
      height: parsed.height,
      checksum: parsed.checksum,
      originalName: parsed.originalName,
      altText: parsed.altText,
      purpose: parsed.purpose,
      uploadedBy: req.admin.email,
      processingStatus: 'ready',
      createdAt: now,
      updatedAt: now
    });
    await auditAdmin(req, 'media_uploaded', 'media', id, {
      mimeType: stored.mimeType,
      size: stored.size,
      width: stored.width,
      height: stored.height,
      checksum: stored.checksum
    });
    res.status(201).json({ok: true, media: mediaResponse(stored), ...mediaResponse(stored)});
  } catch (error) {
    if (error instanceof ImageUploadError) return res.status(error.status).json({code: error.code, error: error.message});
    throw error;
  }
}));

app.get('/api/admin/media', adminLimiter, adminCatalogRead, asyncRoute(async (req, res) => {
  const media = (await repo.listMedia({limit: Number(req.query.limit) || 100})).map(mediaResponse);
  const catalog = await repo.getCatalog();
  const withUsage = media.map(item => ({...item, references: catalogMediaReferences(catalog, item.id)}));
  res.json({media: withUsage});
}));

app.delete('/api/admin/media/:id', adminLimiter, adminMediaWrite, asyncRoute(async (req, res) => {
  const id = cleanText(req.params.id, 180);
  if (!/^(?:media|product-image)-[A-Za-z0-9-]{6,160}$/.test(id)) return res.status(404).json({error: 'Mídia não encontrada.'});
  const catalog = await repo.getCatalog();
  const references = catalogMediaReferences(catalog, id);
  if (references.length) {
    return res.status(409).json({code: 'MEDIA_IN_USE', error: 'A imagem ainda está em uso e não pode ser excluída.', references});
  }
  const deleted = await repo.deleteMedia(id);
  if (!deleted) return res.status(404).json({error: 'Mídia não encontrada.'});
  await auditAdmin(req, 'media_deleted', 'media', id);
  res.json({ok: true});
}));

app.get('/media/products/:id', readLimiter, asyncRoute(async (req, res) => {
  const id = cleanText(req.params.id, 180);
  if (!/^(?:media|product-image)-[A-Za-z0-9-]{6,160}$/.test(id)) return res.status(404).end();
  const media = await repo.getMedia(id);
  if (!media) return res.status(404).end();
  const etag = media.checksum ? `"sha256-${media.checksum}"` : `W/"${media.data.length}-${id}"`;
  if (req.headers['if-none-match'] === etag) return res.status(304).end();
  res.setHeader('Content-Type', media.mimeType);
  res.setHeader('Content-Disposition', 'inline');
  res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  res.setHeader('ETag', etag);
  res.setHeader('Content-Length', String(media.data.length));
  if (media.width) res.setHeader('X-Image-Width', String(media.width));
  if (media.height) res.setHeader('X-Image-Height', String(media.height));
  res.end(media.data);
}));

// Cria um produto novo. O corpo aceita os mesmos campos editáveis do PATCH
// e opcionalmente `variants` (subprodutos) sem id — os ids são gerados aqui.
app.post('/api/admin/products', adminLimiter, adminCatalogWrite, publicJson, asyncRoute(async (req, res) => {
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
  const name = cleanText(body.name, 160);
  if (!name) return res.status(400).json({error: 'Informe o nome do produto.'});
  const productId = newId('product');
  const now = Date.now();
  if (Array.isArray(body.variants) && body.variants.some(variant => !cleanText(variant?.name, 120))) {
    return res.status(400).json({error: 'Toda variação precisa de um nome (ex.: 750ml).'});
  }
  const variants = (Array.isArray(body.variants) ? body.variants : []).slice(0, 100).map((variant, index) => ({
    id: cleanText(variant?.id, 120) || newId('variant'),
    name: cleanText(variant?.name, 120),
    price: variant?.price,
    stock: variant?.stock ?? null,
    unit: cleanText(variant?.unit, 120),
    weightGrams: variant?.weightGrams ?? null,
    position: index + 1
  }));
  const product = {
    id: productId,
    name,
    department: cleanText(body.department, 80),
    subcategory: cleanText(body.subcategory, 100),
    brand: cleanText(body.brand, 120),
    price: body.price ?? 0,
    unit: cleanText(body.unit, 120),
    description: cleanText(body.description, 3000),
    images: Array.isArray(body.images) ? body.images : [],
    variants,
    attributes: body.attributes,
    stock: body.stock ?? null,
    minPerOrder: body.minPerOrder ?? null,
    maxPerOrder: body.maxPerOrder ?? null,
    weightGrams: body.weightGrams ?? null,
    lengthCm: body.lengthCm ?? null,
    widthCm: body.widthCm ?? null,
    heightCm: body.heightCm ?? null,
    available: body.available !== false,
    hidden: body.hidden === true,
    featured: body.featured === true,
    giftEnabled: body.giftEnabled !== false,
    created: now,
    updated: now
  };
  let next;
  try {
    next = await repo.mutateCatalog(current => {
      const products = [...(current.products || []), {...product, position: (current.products || []).length + 1}];
      return normalizeCatalog({...current, products});
    });
  } catch (error) {
    return res.status(400).json({error: error?.message || 'Produto inválido.'});
  }
  const createdProduct = next.products.find(item => item.id === productId);
  await auditAdmin(req, 'product_created', 'product', productId, {name: createdProduct?.name || name});
  res.status(201).json({ok: true, product: createdProduct});
}));

// Exclui um produto do catálogo (remoção real; pedidos já registrados
// guardam os próprios dados e não são afetados).
app.delete('/api/admin/products/:id', adminLimiter, adminCatalogWrite, asyncRoute(async (req, res) => {
  const productId = cleanText(req.params.id, 120);
  try {
    await repo.mutateCatalog(current => {
      const products = (current.products || []).filter(product => product.id !== productId);
      if (products.length === (current.products || []).length) throw new HttpError(404, 'Produto não encontrado.');
      return normalizeCatalog({...current, products});
    });
  } catch (error) {
    if (error instanceof HttpError) return res.status(error.status).json({error: error.message});
    return res.status(400).json({error: error?.message || 'Não foi possível excluir.'});
  }
  await auditAdmin(req, 'product_deleted', 'product', productId);
  res.json({ok: true});
}));

// Personalização da loja: lê e grava apenas o bloco `settings` do catálogo
// (marca, textos, contatos, visual completo). A sanitização acontece no
// normalizeCatalog — nada além do permitido entra.
app.get('/api/admin/settings', adminLimiter, adminCatalogRead, asyncRoute(async (_req, res) => {
  const catalog = await repo.getCatalog();
  res.json({settings: catalog.settings || {}});
}));

app.put('/api/admin/settings', adminLimiter, adminCatalogWrite, adminCatalogJson, asyncRoute(async (req, res) => {
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
  if (!body.settings || typeof body.settings !== 'object' || Array.isArray(body.settings)) {
    return res.status(400).json({error: 'Envie um objeto settings.'});
  }
  let next;
  try {
    next = await repo.mutateCatalog(current => normalizeCatalog({
      ...current,
      settings: {...current.settings, ...body.settings, visual: body.settings.visual ?? current.settings?.visual}
    }));
  } catch (error) {
    return res.status(400).json({error: error?.message || 'Personalização inválida.'});
  }
  await auditAdmin(req, 'settings_updated', 'catalog_settings', 'storefront');
  res.json({ok: true, settings: next.settings});
}));

app.patch('/api/admin/products/:id', adminLimiter, adminCatalogWrite, publicJson, asyncRoute(async (req, res) => {
  const productId = cleanText(req.params.id, 120);
  const patch = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
  const allowed = ['name', 'price', 'description', 'unit', 'stock', 'stockMin', 'maxPerOrder', 'minPerOrder',
    'weightGrams', 'lengthCm', 'widthCm', 'heightCm', 'available', 'hidden', 'featured', 'department', 'subcategory', 'brand',
    'position', 'images', 'attributes', 'giftEnabled', 'sku', 'country', 'region', 'imported', 'restockDate', 'preparation',
    'madeToOrder', 'seasonal'];
  let next;
  try {
    // Atômico: lê o catálogo com lock, aplica o patch sobre o estado mais
    // recente (nunca sobre um snapshot velho) e salva na mesma transação.
    next = await repo.mutateCatalog(current => {
      const index = (current.products || []).findIndex(product => product.id === productId);
      if (index < 0) throw new HttpError(404, 'Produto não encontrado.');
      const product = {...current.products[index]};
      for (const key of allowed) {
        if (key in patch) product[key] = patch[key];
      }
      if (Array.isArray(patch.variants)) {
        const existing = new Map((product.variants || []).map(variant => [variant.id, variant]));
        product.variants = patch.variants.slice(0, 100).map((variant, variantIndex) => {
          const requestedId = cleanText(variant?.id, 120);
          const currentVariant = requestedId ? existing.get(requestedId) : null;
          return {
            ...(currentVariant || {}),
            id: currentVariant?.id || newId('variant'),
            name: cleanText(variant?.name, 120),
            price: variant?.price,
            stock: variant?.stock ?? null,
            unit: cleanText(variant?.unit, 120),
            weightGrams: variant?.weightGrams ?? null,
            position: variantIndex + 1
          };
        });
      }
      const nextProducts = [...current.products];
      nextProducts[index] = product;
      return normalizeCatalog({...current, products: nextProducts});
    });
  } catch (error) {
    if (error instanceof HttpError) return res.status(error.status).json({error: error.message});
    return res.status(400).json({error: error?.message || 'Produto inválido.'});
  }
  const updatedProduct = next.products.find(item => item.id === productId);
  await auditAdmin(req, 'product_updated', 'product', productId, {fields: Object.keys(patch).slice(0, 50)});
  res.json({ok: true, product: updatedProduct});
}));

app.get('/api/admin/coupons', adminLimiter, adminCatalogRead, asyncRoute(async (_req, res) => {
  const catalog = await repo.getCatalog();
  res.json({coupons: catalog.coupons || []});
}));

app.put('/api/admin/coupons', adminLimiter, adminCatalogWrite, publicJson, asyncRoute(async (req, res) => {
  if (!Array.isArray(req.body?.coupons)) return res.status(400).json({error: 'Envie um array coupons.'});
  let next;
  try {
    next = await repo.mutateCatalog(current => normalizeCatalog({...current, coupons: req.body.coupons}));
  } catch (error) {
    return res.status(400).json({error: error?.message || 'Cupons inválidos.'});
  }
  await auditAdmin(req, 'coupons_updated', 'catalog_coupons', 'storefront', {count: next.coupons.length});
  res.json({ok: true, coupons: next.coupons});
}));

app.put('/api/admin/catalog', adminLimiter, adminCatalogWrite, adminCatalogJson, asyncRoute(async (req, res) => {
  let next;
  try {
    next = await repo.mutateCatalog(current => normalizeCatalog({
      version: 9,
      settings: req.body?.settings ?? current.settings,
      commerce: req.body?.commerce ?? req.body?.v8 ?? current.commerce,
      coupons: req.body?.coupons ?? current.coupons,
      products: req.body?.products ?? current.products
    }));
  } catch (error) {
    return res.status(400).json({error: error?.message || 'Catálogo inválido.'});
  }
  await auditAdmin(req, 'catalog_replaced', 'catalog', 'storefront', {products: next.products.length});
  res.json({ok: true, products: next.products.length, catalog: publicCatalog(next, config)});
}));

app.get('/api/admin/audit', adminLimiter, adminAuditRead, asyncRoute(async (req, res) => {
  const entries = await repo.listAudit({limit: Number(req.query.limit) || 100});
  res.json({entries});
}));

app.get(['/admin', '/admin.html'], (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow, noarchive');
  res.sendFile(path.join(publicDir, 'admin.html'));
});

// Serve o index.html com metadados absolutos em produção. Crawlers não
// executam JavaScript, portanto canonical, Open Graph e JSON-LD precisam estar
// corretos no HTML bruto retornado pelo servidor.
let indexHtmlCache = null;
async function serveIndexHtml(res, statusCode = 200) {
  const base = config.publicUrl || (config.renderExternalHostname ? `https://${config.renderExternalHostname}` : '');
  if (config.env !== 'production') res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  if (!base) return res.status(statusCode).sendFile(path.join(publicDir, 'index.html'));
  if (!indexHtmlCache) {
    const raw = await readFile(path.join(publicDir, 'index.html'), 'utf8');
    indexHtmlCache = raw
      .replace(/<meta property="og:url" content="\/"\/>/, `<meta property="og:url" content="${base}/"/>`)
      .replace(/<link rel="canonical" href="\/"\/>/, `<link rel="canonical" href="${base}/"/>`)
      .replace(/<meta (property="og:image"|name="twitter:image") content="(\/assets\/[^"]+)"\/>/g,
        (_match, attr, url) => `<meta ${attr} content="${base}${url}"/>`)
      .replace('"@id":"#organization"', `"@id":"${base}/#organization"`)
      .replace('"logo":"/assets/icons/apple-touch-icon.png"', `"url":"${base}/","logo":"${base}/assets/icons/apple-touch-icon.png"`)
      .replace('"@id":"#website"', `"@id":"${base}/#website"`)
      .replace('"name":"INTEGRALL","publisher"', `"name":"INTEGRALL","url":"${base}/","publisher"`)
      .replace('"publisher":{"@id":"#organization"}', `"publisher":{"@id":"${base}/#organization"}`);
  }
  res.status(statusCode).setHeader('Cache-Control', 'no-cache');
  res.type('html').send(indexHtmlCache);
}

app.get('/', asyncRoute(async (_req, res) => serveIndexHtml(res)));
app.get('/index.html', asyncRoute(async (_req, res) => serveIndexHtml(res)));

app.get('/robots.txt', (_req, res) => {
  const base = config.publicUrl || (config.renderExternalHostname ? `https://${config.renderExternalHostname}` : '');
  res.type('text/plain').setHeader('Cache-Control', 'public, max-age=3600');
  if (config.env !== 'production') return res.send('User-agent: *\nDisallow: /\n');
  const sitemap = base ? `Sitemap: ${base}/sitemap.xml\n` : '';
  res.send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n${sitemap}`);
});

app.get('/sitemap.xml', asyncRoute(async (_req, res) => {
  const base = config.publicUrl || (config.renderExternalHostname ? `https://${config.renderExternalHostname}` : '');
  if (!base || config.env !== 'production') {
    res.setHeader('X-Robots-Tag', 'noindex');
    return res.status(404).type('application/xml').send('<?xml version="1.0" encoding="UTF-8"?><error>Sitemap indisponível fora de produção.</error>');
  }
  const catalog = await repo.getCatalog();
  const changed = catalog?.commerce?.lastUpdated || '';
  const lastmod = /^\d{4}-\d{2}-\d{2}/.test(changed) ? `<lastmod>${changed.slice(0, 10)}</lastmod>` : '';
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${base}/</loc>${lastmod}<changefreq>weekly</changefreq><priority>1.0</priority></url></urlset>`;
  res.type('application/xml').setHeader('Cache-Control', 'public, max-age=3600');
  res.send(xml);
}));

app.use(express.static(publicDir, {
  index: 'index.html',
  etag: true,
  maxAge: 0,
  setHeaders(res, filePath) {
    if (/\/assets\//.test(filePath)) res.setHeader('Cache-Control', 'public, max-age=604800');
    else if (/\.(css|js)$/.test(filePath)) res.setHeader('Cache-Control', 'public, max-age=3600');
    else if (/admin\.html$/.test(filePath)) res.setHeader('Cache-Control', 'no-store');
    else if (/\.html$/.test(filePath)) res.setHeader('Cache-Control', 'no-cache');
  }
}));

app.use((req, res) => {
  if ((req.method === 'GET' || req.method === 'HEAD') && !req.path.startsWith('/api/')) {
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    return res.status(404).sendFile(path.join(publicDir, '404.html'));
  }
  res.status(404).json({code: 'ROUTE_NOT_FOUND', error: 'Rota não encontrada.'});
});

app.use((error, req, res, _next) => {
  if (res.headersSent) return res.end();
  let status = Number.isInteger(error?.status) ? error.status : 500;
  let code = String(error?.code || 'INTERNAL_ERROR').slice(0, 80);
  let message = error?.message || 'Erro interno do servidor.';
  if (error?.type === 'entity.too.large') {
    status = 413;
    code = 'REQUEST_TOO_LARGE';
    message = 'Corpo da requisição muito grande.';
  } else if (error instanceof SyntaxError && 'body' in error) {
    status = 400;
    code = 'INVALID_JSON';
    message = 'JSON inválido.';
  }
  if (status >= 500 && config.env === 'production') message = 'Erro interno do servidor.';
  logEvent('error', 'request_failed', {
    requestId: req.id,
    method: req.method,
    path: req.path,
    status,
    code,
    errorName: String(error?.name || 'Error').slice(0, 80),
    message: safeLogMessage(error?.message || error)
  });
  if (config.env !== 'production' && error?.stack) console.error(error.stack);
  const wantsHtml = !req.path.startsWith('/api/') && req.accepts(['html', 'json']) === 'html';
  if (wantsHtml && status >= 500) return res.status(status).sendFile(path.join(publicDir, '500.html'));
  res.status(status).json({code, error: message});
});

let expireTimer = null;
if (config.orderExpireDays > 0) {
  const sweep = () => {
    repo.expireStaleOrders(config.orderExpireDays)
      .then(expired => {
        if (!expired.length) return;
        logEvent('info', 'orders_expired', {count: expired.length, orderIds: expired.map(order => order.id)});
        // Notifica o cliente: sem isso, o pedido dele sumiria em silêncio.
        for (const order of expired) sendOrderEmail(order, 'status');
      })
      .catch(error => console.error('Falha na expiração automática de pedidos:', error?.message || error));
  };
  expireTimer = setInterval(sweep, 6 * 60 * 60 * 1000);
  expireTimer.unref();
  setTimeout(sweep, 30_000).unref();
}

const server = app.listen(config.port, () => {
  logEvent('info', 'server_started', {version: '11.0.2', port: config.port, persistence: repo.persistent ? 'postgresql' : 'local'});
  for (const warning of configWarnings()) console.warn(`[config] AVISO: ${warning}`);
});

async function shutdown(signal) {
  logEvent('info', 'server_shutdown', {signal});
  if (expireTimer) clearInterval(expireTimer);
  server.close(async () => {
    await repo.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
