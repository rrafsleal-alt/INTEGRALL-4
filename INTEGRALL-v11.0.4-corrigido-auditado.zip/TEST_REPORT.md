# TEST_REPORT — INTEGRALL v11.0.2

Ambiente desta revisão: Linux, Node.js 22.16.0, npm 10.9.2, 31/08/2026.

## Resultados realmente executados

| Comando | Resultado |
|---|---|
| `npm run check` | aprovado; 46 arquivos JavaScript verificados; exit 0 |
| `node --test tests/auth.test.js tests/default-admin.test.js` | 6/6 testes aprovados; exit 0 |
| `npm run admin:check-default` | senha `159213Rafs` autenticada com e-mail em branco; exit 0 |
| `npm run security:scan` | aprovado; exit 0; dois avisos informativos sobre o modo TLS opcional `require` |
| `npm run audit` | aprovado; assets, HTML e cliente auditados; exit 0 |
| `npm ci --ignore-scripts --no-audit --no-fund` | não concluído neste ambiente: falha de DNS `EAI_AGAIN` ao acessar o registry npm |

Os logs e códigos de saída estão em `validation/`.

## O que foi comprovado nesta correção

- O hash padrão realmente embutido em `src/config.js` corresponde à senha `159213Rafs`.
- O login aceita o campo de e-mail vazio e usa a conta interna `admin@integrall.local`.
- Senha incorreta é rejeitada.
- Uma senha personalizada continua suportada e a senha padrão pode atuar como recuperação quando `ADMIN_DEFAULT_LOGIN_ENABLED=true`.
- Os inicializadores do Windows verificam as três dependências obrigatórias: `express`, `mercadopago` e `pg`.

## Limitação desta revisão

A suíte completa (`npm test`, testes HTTP, smoke e `npm run verify`) depende da instalação das dependências. Como o ambiente de empacotamento não conseguiu acessar o registry npm, esses comandos não são declarados como executados nesta versão. No Windows, `PREPARAR-DEPENDENCIAS.bat`, `INICIAR-INTEGRALL.bat` e `VERIFICAR-PROJETO.bat` executam `npm ci` automaticamente quando detectam uma instalação ausente ou incompleta.
