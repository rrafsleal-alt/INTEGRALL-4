# CORREÇÕES — INTEGRALL v11.0.4

_Gerado em 2026-08-31T16:35:32+00:00._

## 1. Resumo executivo

A versão 11.0.4 corrige dois defeitos principais da 11.0.3: a coexistência indevida entre a credencial administrativa padrão e credenciais antigas configuradas, e a implementação dos detalhes do produto como camada/modal lateral mesmo quando o CSS os fazia parecer empilhados. O painel de detalhes foi colocado no fluxo normal e na ordem semântica do documento. A autenticação passou a trabalhar com uma única fonte de verdade por modo de operação.

## 2. Problemas relatados

- A credencial administrativa definida para a entrega não era a única aceita em todas as configurações.
- Os detalhes do produto permaneciam arquiteturalmente em uma coluna/camada lateral e não abaixo do catálogo em todas as larguras.
- A sessão, o logout, a troca de produtos e o comportamento após recarga precisavam de regressão específica.

## 3. Problemas adicionais encontrados

- Largura mínima global de 320 px incompatível com viewport de 280 px.
- Estado do produto acoplado ao gerenciador genérico de modais/overlays.
- Metadados internos ainda declaravam versão anterior.
- Logs e artefatos de execução precisavam ser excluídos ou redigidos antes do empacotamento.

## 4. Arquitetura identificada

Node.js com módulos ES; framework/servidor identificado no package.json: express, mercadopago, pg; gerenciador npm; lockfile presente.

- Entrada e scripts: `package.json`.
- Backend e configuração: diretório `src/`, quando presente.
- Frontend e assets: diretórios públicos existentes no projeto.
- Persistência: PostgreSQL por `pg`, com comportamento de fallback conforme a implementação original.
- Autenticação: validação no servidor, hash scrypt, sessão assinada, cookie HttpOnly e proteção de origem/CSRF conforme o código existente.
- Uploads, integrações e dados comerciais foram preservados.

## 5. Causa raiz da autenticação

A configuração original podia carregar simultaneamente um hash administrativo vindo do ambiente e o hash da credencial padrão como fallback. A rotina de autenticação verificava as duas fontes. Assim, uma credencial antiga podia continuar válida mesmo depois da alteração solicitada.

## 6. Causa raiz do layout lateral

O produto continuava dentro de um componente modal: posicionamento fora do fluxo, overlay, bloqueio de rolagem e gerenciamento por uma camada genérica. Uma regra de coluna alterava apenas a aparência interna, sem corrigir o DOM e o fluxo da página.

## 7. Correção aplicada na autenticação

- Uma única fonte de credencial é ativa por vez.
- No modo padrão, configuração antiga de hash não sobrescreve nem funciona como fallback.
- No modo personalizado, o modo padrão precisa estar explicitamente desativado.
- Comparação permanece sensível a maiúsculas e minúsculas.
- Login inválido não revela qual parte da credencial está errada.
- Sessão e respostas de autenticação usam política sem cache.
- Logout invalida/limpa a sessão e tolera cookie ausente, expirado ou corrompido.
- A credencial não é armazenada no localStorage/sessionStorage nem inserida no HTML público.

## 8. Correção aplicada nos produtos

- Substituição do modal legado por um único `#productDetails` inline.
- Inserção do bloco dentro do catálogo e antes do rodapé.
- Fluxo vertical em qualquer largura, inclusive desktop amplo.
- Remoção de overlay e bloqueio global de rolagem para o produto.
- Ordem do DOM correspondente à ordem visual.
- Limpeza de quantidade, imagem e variações incompatíveis ao trocar/fechar.
- Foco restaurado ao controle de origem; Escape fecha quando aplicável.
- Imagens fluidas, fallback de falha e prevenção de overflow horizontal.
- Remoção da largura mínima global de 320 px.

## 9. Arquivos alterados

Consulte `ARQUIVOS-ALTERADOS-V11.0.4.md` e `PATCH-V11.0.4.diff`.

## 10. Funções e componentes alterados

As funções concretas estão identificadas no patch. As áreas afetadas são: carregamento da configuração de autenticação, validação da credencial, criação/leitura/invalidação de sessão, abertura/fechamento/troca do produto, sincronização do produto selecionado, restauração de foco e estilos do detalhe inline.

## 11. Dependências alteradas

Nenhuma atualização ampla de framework foi realizada. O arquivo de lock foi preservado. Scripts próprios de verificação da versão foram acrescentados sem biblioteca externa.

## 12. Migrações

Não houve migração destrutiva de produtos, imagens, preços, variações ou dados administrativos. Estados antigos de autenticação incompatíveis são tratados por invalidação controlada. Nenhum dado comercial foi removido.

## 13. Impactos

- Credenciais antigas deixam de coexistir com o modo padrão.
- O produto deixa de bloquear a página como modal e passa a ocupar o fluxo vertical do catálogo.
- Links/hash de produto continuam previsíveis, mas o foco e a rolagem agora seguem o bloco inline.

## 14. Riscos residuais

Consulte `TESTES-V11.0.4.md`. Qualquer cenário não executado está explicitamente marcado, com o motivo e o procedimento de validação. A autenticação baseada em credencial padrão deve ser substituída por gestão individual de usuários em implantações públicas de maior criticidade.

## 15. Como executar

```bash
npm ci
npm run dev
```

## 16. Como gerar o build

```bash
npm run build
```

## 17. Como acessar a área administrativa

Acesse a rota/atalho de personalização existente e utilize a credencial padrão definida no termo de entrega. A credencial não é repetida neste documento para evitar exposição desnecessária em arquivos auxiliares.

## 18. Como alterar a credencial futuramente

Desative explicitamente o modo padrão e forneça o hash administrativo pela variável de ambiente indicada em `.env.example`/configuração do projeto. Não coloque a credencial em HTML, JavaScript público, logs ou repositório. Reinicie a aplicação e valide login, reload, rota protegida e logout.

## 19. Como validar o posicionamento

1. Execute a aplicação.
2. Abra um produto.
3. Confirme que existe um único `#productDetails` no DOM.
4. Confirme que `getComputedStyle(...).position` não é `fixed`, `absolute` nem `sticky`.
5. Confirme que o bloco está dentro do catálogo, antes do rodapé e abaixo da área/listagem principal.
6. Repita nas larguras documentadas em `TESTES-V11.0.4.md`.

## 20. Limitações reais

Pré-empacotamento; validação limpa será executada sobre o candidato extraído.
