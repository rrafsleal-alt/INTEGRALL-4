# DEPLOYMENT_RUNBOOK

## 1. Pré-deploy

1. Faça backup do PostgreSQL.
2. Garanta que `.env` não esteja no repositório.
3. Configure `NODE_ENV=production`, `PUBLIC_URL=https://...`, `DATABASE_URL` e `DATABASE_SSL_MODE=verify-full` quando possível.
4. Configure `ADMIN_EMAIL`, `ADMIN_PASSWORD_HASH`, `ADMIN_SESSION_SECRET` e `ADMIN_ROLE`.
5. Adicione credenciais externas somente no secret manager da plataforma.

## 2. Instalação e validação

```bash
npm ci
npm run verify
npm run build
```

## 3. Banco

```bash
npm run db:migrate
```

Migrations usam advisory lock e checksum. Se uma migration já aplicada tiver checksum diferente, o deploy deve parar.

## 4. Subida

```bash
npm start
```

Valide:

- `GET /api/health`;
- home e catálogo;
- `/admin` exige login;
- upload de imagem em ambiente de staging;
- criação de pedido de teste;
- frete/pagamento somente após credenciais de sandbox/homologação.

## 5. Rollback

1. Retorne a versão anterior do código.
2. Para migrations reversíveis, aplique o `.down.sql` correspondente somente após revisar impacto e backup.
3. Nunca execute rollback destrutivo automaticamente em produção.
4. Se houve mudança de dados comerciais, restaure do backup apenas com janela e aprovação operacional.

## 6. Health e observabilidade

Monitore status HTTP, latência, erros 5xx, falhas de provider, rejeições de webhook e falhas de upload. Preserve `X-Request-Id` nos logs da plataforma para correlação.
