import test from 'node:test';
import assert from 'node:assert/strict';
import {AdminAuth} from '../src/auth.js';

const ADMIN_ENV_KEYS = [
  'ADMIN_EMAIL',
  'ADMIN_PASSWORD_HASH',
  'ADMIN_DEFAULT_LOGIN_ENABLED',
  'ADMIN_ROLE',
  'ADMIN_SESSION_SECRET'
];

test('configuracao padrao real autentica 159213Rafs com e-mail em branco', async () => {
  const previous = new Map(ADMIN_ENV_KEYS.map(key => [key, process.env[key]]));
  try {
    for (const key of ADMIN_ENV_KEYS) delete process.env[key];
    const {config} = await import(`../src/config.js?default-admin=${Date.now()}`);
    const auth = new AdminAuth({
      email: config.adminEmail,
      passwordHash: config.adminPasswordHash,
      fallbackPasswordHash: config.adminFallbackPasswordHash,
      role: config.adminRole,
      sessionSecret: config.adminSessionSecret
    });

    assert.equal(auth.configured, true);
    assert.deepEqual(
      await auth.authenticate('', '159213Rafs'),
      {email: 'admin@integrall.local', role: 'admin'}
    );
    assert.equal(await auth.authenticate('', 'senha-incorreta'), null);
  } finally {
    for (const [key, value] of previous) {
      if (value == null) delete process.env[key];
      else process.env[key] = value;
    }
  }
});

test('senha padrão recupera acesso mesmo com ADMIN_PASSWORD_HASH antigo ou inválido', async () => {
  const previous = new Map(ADMIN_ENV_KEYS.map(key => [key, process.env[key]]));
  try {
    process.env.ADMIN_EMAIL = 'responsavel@example.com';
    process.env.ADMIN_PASSWORD_HASH = 'hash-antigo-invalido';
    process.env.ADMIN_DEFAULT_LOGIN_ENABLED = 'true';
    process.env.ADMIN_ROLE = 'admin';
    process.env.ADMIN_SESSION_SECRET = 's'.repeat(64);

    const {config} = await import(`../src/config.js?fallback-admin=${Date.now()}`);
    const auth = new AdminAuth({
      email: config.adminEmail,
      passwordHash: config.adminPasswordHash,
      fallbackPasswordHash: config.adminFallbackPasswordHash,
      role: config.adminRole,
      sessionSecret: config.adminSessionSecret
    });

    assert.deepEqual(
      await auth.authenticate('', '159213Rafs'),
      {email: 'responsavel@example.com', role: 'admin'}
    );
  } finally {
    for (const [key, value] of previous) {
      if (value == null) delete process.env[key];
      else process.env[key] = value;
    }
  }
});

