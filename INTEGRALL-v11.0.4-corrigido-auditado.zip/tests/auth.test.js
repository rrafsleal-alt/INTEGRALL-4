import test from 'node:test';
import assert from 'node:assert/strict';
import {AdminAuth, hashPassword, verifyPassword, hasPermission} from '../src/auth.js';

const PASSWORD = 'Senha-Forte-Para-Testes-2026!';

test('scrypt cria hash verificável e rejeita senha incorreta', async () => {
  const hash = await hashPassword(PASSWORD, {cost: 4096, salt: Buffer.alloc(16, 7)});
  assert.match(hash, /^scrypt\$4096\$8\$1\$/);
  assert.equal(await verifyPassword(PASSWORD, hash), true);
  assert.equal(await verifyPassword('senha-incorreta', hash), false);
  assert.equal(await verifyPassword(PASSWORD, 'inválido'), false);
});

test('sessão administrativa é assinada, expira e carrega CSRF', async () => {
  const passwordHash = await hashPassword(PASSWORD, {cost: 4096, salt: Buffer.alloc(16, 8)});
  const auth = new AdminAuth({
    email: 'Admin@Example.com', passwordHash, role: 'editor', sessionSecret: 'x'.repeat(64), sessionHours: 1
  });
  const user = await auth.authenticate('admin@example.com', PASSWORD);
  assert.deepEqual(user, {email: 'admin@example.com', role: 'editor'});
  assert.equal(await auth.authenticate('admin@example.com', 'errada'), null);
  const session = auth.createSession(user);
  assert.match(session.cookie, /^integrall_admin_session=/);
  assert.match(session.cookie, /HttpOnly/);
  assert.match(session.cookie, /SameSite=Strict/);
  const token = session.cookie.match(/^integrall_admin_session=([^;]+)/)[1];
  const payload = auth.verifyToken(token);
  assert.equal(payload.sub, 'admin@example.com');
  assert.equal(payload.role, 'editor');
  assert.ok(payload.csrf.length >= 20);
  assert.equal(auth.verifyToken(`${token}tamper`), null);
});

test('login aceita e-mail em branco e senha padrão de recuperação', async () => {
  const primaryHash = await hashPassword('Senha-Principal-2026!', {cost: 4096, salt: Buffer.alloc(16, 9)});
  const fallbackHash = await hashPassword('159213Rafs', {cost: 4096, salt: Buffer.alloc(16, 10)});
  const auth = new AdminAuth({
    email: 'admin@integrall.local',
    passwordHash: primaryHash,
    fallbackPasswordHash: fallbackHash,
    sessionSecret: 'z'.repeat(64)
  });
  assert.deepEqual(await auth.authenticate('', '159213Rafs'), {email: 'admin@integrall.local', role: 'admin'});
  assert.deepEqual(await auth.authenticate('', 'Senha-Principal-2026!'), {email: 'admin@integrall.local', role: 'admin'});
  assert.equal(await auth.authenticate('outro@example.com', '159213Rafs'), null);
});

test('papéis aplicam menor privilégio', () => {
  assert.equal(hasPermission('admin', 'catalog:write'), true);
  assert.equal(hasPermission('editor', 'catalog:write'), true);
  assert.equal(hasPermission('editor', 'orders:write'), false);
  assert.equal(hasPermission('operator', 'orders:write'), true);
  assert.equal(hasPermission('operator', 'catalog:write'), false);
});
