import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const credential = ['159213', 'Rafs'].join('');
function filesUnder(dir) {
  if (!fs.existsSync(dir)) return [];
  const out=[];
  for (const entry of fs.readdirSync(dir,{withFileTypes:true})) {
    if (['node_modules','.git','dist','build','coverage'].includes(entry.name)) continue;
    const p=path.join(dir,entry.name);
    if(entry.isDirectory()) out.push(...filesUnder(p)); else if(entry.isFile()) out.push(p);
  }
  return out;
}
function text(p){try{return fs.readFileSync(p,'utf8')}catch{return ''}}

test('versão 11.0.4 está declarada',()=>{
  const pkg=JSON.parse(text(path.join(root,'package.json')));
  assert.equal(pkg.version,'11.0.4');
});

test('credencial não está exposta nos assets públicos',()=>{
  const roots=['public','static','client','frontend','web'].map(x=>path.join(root,x));
  const leaks=roots.flatMap(filesUnder).filter(p=>text(p).includes(credential));
  assert.deepEqual(leaks,[]);
});

test('detalhes do produto usam um único bloco inline e não o modal legado',()=>{
  const html=filesUnder(root).filter(p=>/\.html?$/i.test(p)).map(p=>text(p)).join('\n');
  assert.equal((html.match(/id=["']productDetails["']/gi)||[]).length,1);
  assert.equal((html.match(/id=["']productModal["']/gi)||[]).length,0);
});

test('body não força largura mínima de 320px',()=>{
  const css=filesUnder(root).filter(p=>/\.css$/i.test(p)).map(p=>text(p)).join('\n');
  assert.doesNotMatch(css,/body\s*\{[^}]*min-width\s*:\s*320px/isu);
});

