(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const header = $('#topo');
  const catalog = $('#catalogPage');
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;

  function scrollToId(id, offset = 0) {
    const node = document.getElementById(id);
    if (!node) return;
    const top = node.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({top, behavior: reduceMotion ? 'auto' : 'smooth'});
  }

  function openCatalogPage(page = 'vitrine') {
    const app = globalThis.__integrallApp;
    if (app?.navigate) app.navigate(page, {historyMode: 'push'});
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (!catalog) return;
      const top = catalog.getBoundingClientRect().top + window.scrollY - 82;
      window.scrollTo({top, behavior: reduceMotion ? 'auto' : 'smooth'});
    }));
  }

  function bindPremiumActions() {
    $$('[data-scroll-to]').forEach(button => button.addEventListener('click', event => {
      event.preventDefault();
      $('#nav')?.classList.remove('open');
      $('#menuBtn')?.setAttribute('aria-expanded', 'false');
      scrollToId(button.dataset.scrollTo, 70);
    }));
    $$('[data-premium-page]').forEach(button => button.addEventListener('click', event => {
      event.preventDefault();
      openCatalogPage(button.dataset.premiumPage || 'vitrine');
    }));
    $$('[data-open-product]').forEach(button => button.addEventListener('click', event => {
      event.preventDefault();
      const id = button.dataset.openProduct;
      if (id && globalThis.__integrallApp?.openProduct) globalThis.__integrallApp.openProduct(id, {updateHash: true});
    }));
    $('#heroExplore')?.addEventListener('click', () => openCatalogPage('vitrine'));
    $('#showAllProducts')?.addEventListener('click', () => openCatalogPage('vitrine'));
    $('#closingExplore')?.addEventListener('click', () => openCatalogPage('vitrine'));
    $('#premiumSearchBtn')?.addEventListener('click', () => {
      openCatalogPage('vitrine');
      setTimeout(() => $('#search')?.focus(), reduceMotion ? 0 : 650);
    });
  }

  function bindHeader() {
    if (!header) return;
    let ticking = false;
    const update = () => {
      header.classList.toggle('is-scrolled', window.scrollY > 30);
      if (!reduceMotion) {
        const media = $('.premium-hero-media');
        if (media && window.scrollY < window.innerHeight * 1.15) {
          const y = Math.min(window.scrollY * .12, 80);
          media.style.translate = `0 ${y}px`;
        }
      }
      ticking = false;
    };
    update();
    addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(update); ticking = true; } }, {passive: true});
  }

  function bindReveal() {
    const nodes = $$('.reveal');
    if (!nodes.length) return;
    if (reduceMotion || !('IntersectionObserver' in window)) {
      nodes.forEach(node => node.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, {threshold: .12, rootMargin: '0px 0px -5% 0px'});
    nodes.forEach(node => observer.observe(node));
  }

  function improveNativeNavigation() {
    // Existing data-page navigation remains untouched. We only move the viewport
    // to the real collection after category navigation to make the premium home useful.
    $$('#nav [data-page]').forEach(button => {
      button.addEventListener('click', () => {
        const page = button.dataset.page;
        $('#nav')?.classList.remove('open');
        $('#menuBtn')?.setAttribute('aria-expanded', 'false');
        if (page !== 'vitrine') setTimeout(() => {
          if (!catalog) return;
          window.scrollTo({top: catalog.getBoundingClientRect().top + window.scrollY - 82, behavior: reduceMotion ? 'auto' : 'smooth'});
        }, 20);
      });
    });
  }

  function start() {
    bindPremiumActions();
    bindHeader();
    bindReveal();
    improveNativeNavigation();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once: true}); else start();
})();
