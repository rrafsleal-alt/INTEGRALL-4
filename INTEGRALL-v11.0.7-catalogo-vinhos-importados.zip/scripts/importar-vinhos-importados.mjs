// Cadastro dos VINHOS IMPORTADOS (Vinhos importados_compressed.pdf) no catálogo-fonte.
// Países: Portugal, Chile, Argentina, França, Itália, Espanha, África do Sul.
// Idempotente por nome normalizado. Preços/estoque são provisórios (PDF não informa).
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const catalogPath = join(root, 'data', 'catalog.json');
const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));

const now = Date.now();
let seq = 0;
const pid = () => `product-${now}-vi${(seq).toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
const vid = n => `variant-${now}-vi-${n}-${Math.random().toString(36).slice(2, 6)}`;

// Preços provisórios por tamanho (centavos). Ajustar no admin.
const PRICE = { '187ml': 1490, '375ml': 2690, '750ml': 4990, '1,5L': 9990, '3L': 19900, '5L': 5990 };
// Para Porto (Martha's) preços um pouco acima.
const PORT_PRICE = { '750ml-basic': 6990, '750ml-10': 12990, '750ml-20': 22990 };
const WEIGHT = { '187ml': 450, '375ml': 750, '750ml': 1300, '1,5L': 2300, '3L': 4600, '5L': 6800 };
const STOCK = 60;

function buildVariants(sizes, priceTable = PRICE) {
  return sizes.map((s, i) => ({
    id: vid(seq + '-' + i),
    name: s.name,
    price: s.price || priceTable[s.size] || PRICE['750ml'],
    stock: STOCK, unit: '', position: i + 1, weightGrams: WEIGHT[s.size] || 1300
  }));
}

// Cada item: {name, brand, sub, country, region, grape, alcohol, volume, desc, sizes:[{name,size,price?}]}
const PT = 'Portugal';
const CL = 'Chile';
const AR = 'Argentina';
const FR = 'França';
const IT = 'Itália';
const ES = 'Espanha';
const ZA = 'África do Sul';

const W = [
  // ===== PORTUGAL — Porta 6 (Vidigal, Lisboa/Verde) =====
  { brand: 'Porta 6', sub: 'Branco', country: PT, region: 'Lisboa', grape: 'Fernão Pires 40%, Arinto 30%, Sauvignon Blanc 30%', alcohol: '12,5%', volume: '750ml',
    desc: 'Porta 6 Branco, Vidigal Wines (Lisboa). Rótulo divertido inspirado numa cena de Lisboa; leve e aromático.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Porta 6', sub: 'Tinto', country: PT, region: 'Lisboa', grape: 'Aragonez 50%, Castelão 40%, Touriga Nacional 10%', alcohol: '13,5%', volume: '750ml',
    desc: 'Porta 6 Tinto, Vidigal Wines. Fenômeno português premiado (Wine Enthusiast Best Buy 2020, medalha de ouro Concours Mondial).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Porta 6', sub: 'Tinto (375ml)', country: PT, region: 'Lisboa', grape: 'Aragonez 50%, Castelão 40%, Touriga Nacional 10%', alcohol: '13,5%', volume: '375ml',
    desc: 'Porta 6 Tinto em meia-garrafa (375ml).', sizes: [{ name: '375ml', size: '375ml' }] },
  { brand: 'Porta 6', sub: 'Branco (375ml)', country: PT, region: 'Lisboa', grape: 'Fernão Pires 40%, Arinto 30%, Sauvignon Blanc 30%', alcohol: '12,5%', volume: '375ml',
    desc: 'Porta 6 Branco em meia-garrafa (375ml).', sizes: [{ name: '375ml', size: '375ml' }] },
  { brand: 'Porta 6', sub: 'Reserva Tinto', country: PT, region: 'Lisboa', grape: 'Syrah 40%, Alicante Bouschet 20%, Cabernet 20%, Touriga Nacional 20%', alcohol: '14%', volume: '750ml',
    desc: 'Porta 6 Reserva Tinto, Vidigal Wines. Encorpado e estruturado.', sizes: [{ name: '750ml', size: '750ml', price: 6490 }] },
  { brand: 'Porta 6', sub: 'Verde DOC Branco', country: PT, region: 'Vinho Verde', grape: 'Loureiro 50%, Trajadura 40%, Arinto 10%', alcohol: '9,5%', volume: '750ml',
    desc: 'Porta 6 Verde DOC Branco: fresco, leve e ligeiramente frisante.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Porta 6', sub: 'Rosé', country: PT, region: 'Lisboa', grape: 'Castelão 40%, Tinta Roriz 20%, Syrah 20%', alcohol: '12,5%', volume: '750ml',
    desc: 'Porta 6 Rosé, fresco e frutado.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Porta 6', sub: 'Espumante Brut Branco', country: PT, region: 'Lisboa', grape: 'Arinto 70%, Fernão Pires 25%, Chardonnay 5%', alcohol: '12,5%', volume: '750ml',
    desc: 'Porta 6 Espumante Brut Branco.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Porta 6', sub: 'Magnum Tinto', country: PT, region: 'Lisboa', grape: 'Aragonez 50%, Castelão 40%, Touriga Nacional 10%', alcohol: '13,5%', volume: '1,5L',
    desc: 'Porta 6 Magnum Tinto (1,5 litros).', sizes: [{ name: 'Magnum 1,5L', size: '1,5L' }] },
  { brand: 'Porta 6', sub: 'Double Magnum Tinto', country: PT, region: 'Lisboa', grape: 'Aragonez 50%, Castelão 40%, Touriga Nacional 10%', alcohol: '13,5%', volume: '3L',
    desc: 'Porta 6 Double Magnum Tinto (3 litros, em embalagem com alça).', sizes: [{ name: 'Double Magnum 3L', size: '3L' }] },

  // ===== 3 Autores (Vidigal, Douro/Verde) =====
  { brand: '3 Autores', sub: 'Verde DOC Branco', country: PT, region: 'Vinho Verde', grape: 'Loureiro 50%, Trajadura 40%, Arinto 10%', alcohol: '9,5%', volume: '750ml',
    desc: '3 Autores Verde DOC Branco (Vidigal): homenagem aos três enólogos da casa.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: '3 Autores', sub: 'Douro DOC Branco', country: PT, region: 'Douro', grape: 'Viosinho 60%, Malvasia Fina 20%, Rabigato 20%', alcohol: '11,5%', volume: '750ml',
    desc: '3 Autores Douro DOC Branco.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: '3 Autores', sub: 'Douro DOC Tinto', country: PT, region: 'Douro', grape: 'Touriga Franca 50%, Tinta Roriz 30%, Touriga Nacional 20%', alcohol: '13,5%', volume: '750ml',
    desc: '3 Autores Douro DOC Tinto.', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Vidigal =====
  { brand: 'Vidigal', sub: 'Chapéu de Praia Rosé', country: PT, region: 'Lisboa', grape: 'Aragonez 60%, Castelão 40%', alcohol: '11,5%', volume: '750ml',
    desc: 'Vidigal Chapéu de Praia Rosé.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Vidigal', sub: 'Reserva Tinto', country: PT, region: 'Lisboa', grape: 'Tinta Roriz 70%, Syrah 20%, Cabernet Sauvignon 10%', alcohol: '13%', volume: '750ml',
    desc: 'Vidigal Reserva Tinto 2021.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'NBNC', sub: 'No Branding No Cry Tinto', country: PT, region: 'Douro', grape: 'Aragonez 70%, Castelão 20%, Tinta Miúda 10%', alcohol: '13%', volume: '750ml',
    desc: 'NBNC (No Branding, No Cry) Tinto, Vidigal.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Zé do Telhado', sub: 'Tinto', country: PT, region: 'Douro', grape: 'Touriga Franca 50%, Tinta Roriz 30%, Touriga Nacional 20%', alcohol: '13,5%', volume: '750ml',
    desc: 'Zé do Telhado Tinto, Vidigal (Douro).', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Júlia Florista =====
  { brand: 'Júlia Florista', sub: 'Branco', country: PT, region: 'Lisboa', grape: 'Fernão Pires 90%, Moscatel 10%', alcohol: '12,5%', volume: '750ml',
    desc: 'Júlia Florista Branco: homenagem à fadista de Lisboa.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Júlia Florista', sub: 'Rosé', country: PT, region: 'Lisboa', grape: 'Castelão 60%, Tinta Roriz 20%, Syrah 20%', alcohol: '12%', volume: '750ml',
    desc: 'Júlia Florista Rosé.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Júlia Florista', sub: 'Tinto', country: PT, region: 'Lisboa', grape: 'Castelão 60%, Aragonez 40%', alcohol: '13%', volume: '750ml',
    desc: 'Júlia Florista Tinto.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Júlia Florista', sub: 'Reserva Tinto', country: PT, region: 'Lisboa', grape: 'Aragonez 70%, Castelão 20%, Tinta Miúda 10%', alcohol: '13%', volume: '750ml',
    desc: 'Júlia Florista Reserva Tinto.', sizes: [{ name: '750ml', size: '750ml', price: 5990 }] },
  { brand: 'Júlia Florista', sub: 'Bag in Box Branco', country: PT, region: 'Lisboa', grape: 'Fernão Pires 90%, Moscatel 10%', alcohol: '12,5%', volume: '5L',
    desc: 'Júlia Florista Bag in Box Branco (5 litros).', sizes: [{ name: 'Bag in Box 5L', size: '5L' }] },
  { brand: 'Júlia Florista', sub: 'Bag in Box Tinto', country: PT, region: 'Lisboa', grape: 'Castelão 60%, Aragonez 40%', alcohol: '13%', volume: '5L',
    desc: 'Júlia Florista Bag in Box Tinto (5 litros).', sizes: [{ name: 'Bag in Box 5L', size: '5L' }] },

  // ===== Artolas =====
  { brand: 'Artolas', sub: 'Branco', country: PT, region: 'Lisboa', grape: 'Fernão Pires 40%, Arinto 30%, Sauvignon Blanc 30%', alcohol: '12,5%', volume: '750ml',
    desc: 'Artolas Branco (White Moustache): vinho fino meio-seco, redondo e macio.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Artolas', sub: 'Rosé', country: PT, region: 'Lisboa', grape: 'Castelão 60%, Tinta Roriz 40%', alcohol: '12%', volume: '750ml',
    desc: 'Artolas Rosé (Pink Moustache).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Artolas', sub: 'Tinto', country: PT, region: 'Lisboa', grape: 'Castelão 60%, Aragonez 40%', alcohol: '13%', volume: '750ml',
    desc: 'Artolas Tinto (Black Moustache), produto de Portugal.', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Da Pipa (Bairrada/Beira Atlântico) =====
  { brand: 'Da Pipa', sub: 'Branco', country: PT, region: 'Bairrada', grape: 'Maria Gomes 80%, Bical 20%', alcohol: '12%', volume: '750ml',
    desc: 'Da Pipa Branco (Cantanhede, Bairrada). Colheita Selecionada.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Da Pipa', sub: 'Rosé', country: PT, region: 'Bairrada', grape: 'Baga 100%', alcohol: '11,5%', volume: '750ml',
    desc: 'Da Pipa Rosé (Baga).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Da Pipa', sub: 'Tinto', country: PT, region: 'Bairrada', grape: 'Touriga Nacional 40%, Baga 40%, Aragonez 20%', alcohol: '13%', volume: '750ml',
    desc: 'Da Pipa Tinto (Colheita Selecionada).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Da Pipa', sub: 'Reserva Tinto', country: PT, region: 'Bairrada', grape: 'Baga 50%, Aragonez 30%, Touriga Nacional 20%', alcohol: '13%', volume: '750ml',
    desc: 'Da Pipa Reserva Tinto.', sizes: [{ name: '750ml', size: '750ml', price: 5990 }] },
  { brand: 'Da Pipa', sub: 'Bag in Box Branco', country: PT, region: 'Bairrada', grape: 'Maria Gomes 80%, Bical 20%', alcohol: '12%', volume: '5L',
    desc: 'Da Pipa Bag in Box Branco (5 litros).', sizes: [{ name: 'Bag in Box 5L', size: '5L', price: 6490 }] },
  { brand: 'Da Pipa', sub: 'Bag in Box Rosé', country: PT, region: 'Bairrada', grape: 'Baga 100%', alcohol: '11,5%', volume: '5L',
    desc: 'Da Pipa Bag in Box Rosé (5 litros).', sizes: [{ name: 'Bag in Box 5L', size: '5L', price: 6490 }] },
  { brand: 'Da Pipa', sub: 'Bag in Box Tinto', country: PT, region: 'Bairrada', grape: 'Touriga Nacional 40%, Baga 40%, Aragonez 20%', alcohol: '13%', volume: '5L',
    desc: 'Da Pipa Bag in Box Tinto (5 litros).', sizes: [{ name: 'Bag in Box 5L', size: '5L', price: 6490 }] },

  // ===== Intimista (Amareleza, Alentejo) =====
  { brand: 'Intimista', sub: 'Branco', country: PT, region: 'Alentejo', grape: 'Roupeiro, Manteúdo, Antão Vaz e Arinto', alcohol: '12,5%', volume: '750ml',
    desc: 'Intimista Branco (Granja Amareleza, Alentejo): vinhos naturais sem aditivos.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Intimista', sub: 'Rosé', country: PT, region: 'Alentejo', grape: 'Castelão, Aragonez e Syrah', alcohol: '12,5%', volume: '750ml',
    desc: 'Intimista Rosé.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Intimista', sub: 'Tinto', country: PT, region: 'Alentejo', grape: 'Alfrocheiro, Moreto, Trincadeira e Aragonez', alcohol: '13,5%', volume: '750ml',
    desc: 'Intimista Tinto (casta Moreto nativa).', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Martha's (Vinho do Porto) =====
  { brand: "Martha's", sub: 'Classic Moscatel do Douro DOC', country: PT, region: 'Douro', grape: '100% Moscatel Galego', alcohol: '17%', volume: '750ml',
    desc: "Martha's Classic Moscatel do Douro DOC (vinho do Porto branco doce).", sizes: [{ name: '750ml', size: '750ml', price: PORT_PRICE['750ml-basic'] }] },
  { brand: "Martha's", sub: 'Porto White', country: PT, region: 'Douro', grape: 'Malvasia Fina, Viosinho, Donzelinho, Gouveio, Moscatel, Rabigato', alcohol: '19,5%', volume: '750ml',
    desc: "Martha's Porto White (branco).", sizes: [{ name: '750ml', size: '750ml', price: PORT_PRICE['750ml-basic'] }] },
  { brand: "Martha's", sub: 'Porto Ruby', country: PT, region: 'Douro', grape: 'Touriga Nacional, Touriga Franca, Tinta Barroca, Tinto Cão, Tinta Amarela, Tinta Roriz', alcohol: '19%', volume: '750ml',
    desc: "Martha's Porto Ruby (tinto).", sizes: [{ name: '750ml', size: '750ml', price: PORT_PRICE['750ml-basic'] }] },
  { brand: "Martha's", sub: 'Porto Tawny', country: PT, region: 'Douro', grape: 'Touriga Nacional, Touriga Franca, Tinta Barroca, Tinto Cão, Tinta Amarela, Tinta Roriz', alcohol: '19%', volume: '750ml',
    desc: "Martha's Porto Tawny.", sizes: [{ name: '750ml', size: '750ml', price: PORT_PRICE['750ml-basic'] }] },
  { brand: "Martha's", sub: 'Porto Tawny 10 anos', country: PT, region: 'Douro', grape: 'Touriga Nacional, Touriga Franca, Tinta Barroca, Tinto Cão, Tinta Amarela, Tinta Roriz', alcohol: '19,5%', volume: '750ml',
    desc: "Martha's Classic Porto Tawny 10 anos.", sizes: [{ name: '750ml', size: '750ml', price: PORT_PRICE['750ml-10'] }] },
  { brand: "Martha's", sub: 'Porto Tawny 20 anos', country: PT, region: 'Douro', grape: 'Touriga Nacional, Touriga Franca, Tinta Barroca, Tinto Cão, Tinta Amarela, Tinta Roriz', alcohol: '20%', volume: '750ml',
    desc: "Martha's Porto Tawny 20 anos.", sizes: [{ name: '750ml', size: '750ml', price: PORT_PRICE['750ml-20'] }] },

  // ===== CHILE — Relatos de Valpa (Valle Central) =====
  { brand: 'Relatos de Valpa', sub: 'Carménère Tinto', country: CL, region: 'Valle Central', grape: '100% Carménère', alcohol: '13,5%', volume: '750ml',
    desc: 'Relatos de Valpa Carménère (D.O. Valle Central, Chile).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Relatos de Valpa', sub: 'Cabernet Sauvignon Tinto', country: CL, region: 'Valle Central', grape: '100% Cabernet Sauvignon', alcohol: '13,5%', volume: '750ml',
    desc: 'Relatos de Valpa Cabernet Sauvignon. Também em 375ml e 187ml.', sizes: [{ name: '750ml', size: '750ml' }, { name: '375ml', size: '375ml' }, { name: '187ml', size: '187ml' }] },
  { brand: 'Relatos de Valpa', sub: 'Chardonnay Branco', country: CL, region: 'Valle Central', grape: '100% Chardonnay', alcohol: '13,5%', volume: '750ml',
    desc: 'Relatos de Valpa Chardonnay. Também em 375ml e 187ml.', sizes: [{ name: '750ml', size: '750ml' }, { name: '375ml', size: '375ml' }, { name: '187ml', size: '187ml' }] },
  { brand: 'Relatos de Valpa', sub: 'Light Edition Red Wine', country: CL, region: 'Valle Central', grape: 'Blend tinto', alcohol: '8%', volume: '750ml',
    desc: 'Relatos de Valpa Light Edition Red (8% de álcool, baixas calorias: 65 calorias por taça).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Relatos de Valpa', sub: 'Light Edition White Wine', country: CL, region: 'Valle Central', grape: 'Blend branco', alcohol: '8%', volume: '750ml',
    desc: 'Relatos de Valpa Light Edition White (8% de álcool, 61 calorias por taça).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Relatos de Valpa', sub: 'Light Edition Rosé', country: CL, region: 'Valle Central', grape: 'Blend rosé', alcohol: '8%', volume: '750ml',
    desc: 'Relatos de Valpa Light Edition Rosé (8% de álcool, 65 calorias por taça).', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Chile — Castillo de Andrade (vegano) =====
  { brand: 'Castillo de Andrade', sub: 'Merlot Tinto', country: CL, region: 'Valle Central', grape: 'Merlot 100%', alcohol: '13%', volume: '750ml',
    desc: 'Castillo de Andrade Merlot (100% vegano).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Castillo de Andrade', sub: 'Malbec Tinto', country: CL, region: 'Valle Central', grape: 'Malbec 100%', alcohol: '13%', volume: '750ml',
    desc: 'Castillo de Andrade Malbec (vegano).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Castillo de Andrade', sub: 'Carménère Tinto', country: CL, region: 'Valle Central', grape: 'Carménère 100%', alcohol: '13%', volume: '750ml',
    desc: 'Castillo de Andrade Carménère (vegano).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Castillo de Andrade', sub: 'Cabernet Sauvignon Tinto', country: CL, region: 'Valle Central', grape: 'Cabernet Sauvignon 100%', alcohol: '13%', volume: '750ml',
    desc: 'Castillo de Andrade Cabernet Sauvignon (vegano).', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Chile — Isla Negra (Cono Sur) =====
  { brand: 'Isla Negra', sub: 'Reserva Cabernet Sauvignon', country: CL, region: 'Valle Central', grape: 'Cabernet Sauvignon 100%', alcohol: '12%', volume: '750ml',
    desc: 'Isla Negra Reserva Cabernet Sauvignon (Bodega Cono Sur).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Isla Negra', sub: 'Reserva Carménère', country: CL, region: 'Valle Central', grape: 'Carménère 100%', alcohol: '12%', volume: '750ml',
    desc: 'Isla Negra Reserva Carménère.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Isla Negra', sub: 'Reserva Merlot', country: CL, region: 'Valle Central', grape: 'Merlot 100%', alcohol: '12,5%', volume: '750ml',
    desc: 'Isla Negra Reserva Merlot.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Isla Negra', sub: 'Reserva Sauvignon Blanc', country: CL, region: 'Valle Central', grape: 'Sauvignon Blanc 100%', alcohol: '12%', volume: '750ml',
    desc: 'Isla Negra Reserva Sauvignon Blanc.', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== Chile — Paso de los Andes (Bodega Kinast) =====
  { brand: 'Paso de los Andes', sub: 'Moskato Branco Suave', country: CL, region: 'Valle Central', grape: 'Sauvignon Blanc, Semelion e Moscatel', alcohol: '12%', volume: '750ml',
    desc: 'Paso de los Andes Moskato Branco Suave.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Paso de los Andes', sub: 'Moskato Tinto Suave', country: CL, region: 'Valle Central', grape: 'Cabernet Sauvignon, País, Carignan', alcohol: '12%', volume: '750ml',
    desc: 'Paso de los Andes Moskato Tinto Suave.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Paso de los Andes', sub: 'Varietal Sauvignon Blanc', country: CL, region: 'Valle Central', grape: 'Sauvignon Blanc 100%', alcohol: '12,5%', volume: '750ml',
    desc: 'Paso de los Andes Varietal Sauvignon Blanc.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Paso de los Andes', sub: 'Varietal Rosé', country: CL, region: 'Valle Central', grape: 'Cabernet Sauvignon 100%', alcohol: '13%', volume: '750ml',
    desc: 'Paso de los Andes Varietal Rosé.', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== ARGENTINA — New Roads (Bodega RPB, Mendoza) =====
  { brand: 'New Roads', sub: 'Branco', country: AR, region: 'Mendoza', grape: 'Ugni Blanc 40%, Chenin 30%, Pedro Giménez 30%', alcohol: '12,5%', volume: '750ml',
    desc: 'New Roads Branco (Bodega RPB, Mendoza).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'New Roads', sub: 'Tinto Red Wine', country: AR, region: 'Mendoza', grape: 'Malbec 20%, Tempranillo 40%, Bonarda 20%, Bonamico 20%', alcohol: '13,2%', volume: '750ml',
    desc: 'New Roads Tinto "Red Wine Smooth & Fruity" (Bodega RPB).', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== FRANÇA — Rabbit Family (Languedoc Roussillon) =====
  { brand: 'Spring Rabbit', sub: 'Sauvignon Blanc Branco', country: FR, region: 'Languedoc-Roussillon', grape: 'Sauvignon Blanc 100%', alcohol: '13%', volume: '750ml',
    desc: 'Spring Rabbit Branco Sauvignon Blanc.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Charming Rabbit', sub: 'Chardonnay Branco', country: FR, region: 'Languedoc-Roussillon', grape: 'Chardonnay 100%', alcohol: '13%', volume: '750ml',
    desc: 'Charming Rabbit Branco Chardonnay.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Pink Rabbit', sub: 'Rosé', country: FR, region: 'Languedoc-Roussillon', grape: 'Grenache 70%, Syrah 30%', alcohol: '12,5%', volume: '750ml',
    desc: 'Pink Rabbit Rosé (Grenache/Syrah).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Mrs. Rabbit', sub: 'Pinot Noir Tinto', country: FR, region: 'Languedoc-Roussillon', grape: 'Pinot Noir 100%', alcohol: '13%', volume: '750ml',
    desc: 'Mrs. Rabbit Tinto Pinot Noir.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Mr. Rabbit', sub: 'Cabernet Sauvignon Tinto', country: FR, region: 'Languedoc-Roussillon', grape: 'Cabernet Sauvignon 100%', alcohol: '13%', volume: '750ml',
    desc: 'Mr. Rabbit Tinto Cabernet Sauvignon.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Master Rabbit', sub: 'Syrah Tinto', country: FR, region: 'Languedoc-Roussillon', grape: 'Syrah 100%', alcohol: '13%', volume: '750ml',
    desc: 'Master Rabbit Tinto Syrah.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Dirty Rabbit', sub: 'Petit Verdot Tinto', country: FR, region: 'Côtes du Rhône', grape: 'Petit Verdot 100%', alcohol: '14%', volume: '750ml',
    desc: 'Dirty Rabbit Tinto Petit Verdot.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Chatelain Valmont', sub: 'Côtes du Rhône Tinto', country: FR, region: 'Côtes du Rhône', grape: 'Grenache 80%, Syrah 20%', alcohol: '14%', volume: '750ml',
    desc: 'Chatelain Valmont Côtes du Rhône Tinto.', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== ITÁLIA — Torre Romanica (Cantine Galasso, Abruzzo) =====
  { brand: 'Torre Romanica', sub: 'Rosso Tinto', country: IT, region: 'Abruzzo', grape: 'Blend Montepulciano, Syrah e Cabernet', alcohol: '12%', volume: '750ml',
    desc: 'Torre Romanica Rosso (Cantine Galasso).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Torre Romanica', sub: 'Sangiovese Tinto', country: IT, region: 'Abruzzo', grape: '100% Sangiovese', alcohol: '12,5%', volume: '750ml',
    desc: 'Torre Romanica Sangiovese.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Torre Romanica', sub: 'Primitivo Tinto', country: IT, region: 'Abruzzo', grape: 'Primitivo 100%', alcohol: '13%', volume: '750ml',
    desc: 'Torre Romanica Primitivo.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Torre Romanica', sub: 'Montepulciano Premium Tinto', country: IT, region: 'Montepulciano d’Abruzzo', grape: 'Montepulciano 100%', alcohol: '13%', volume: '750ml',
    desc: 'Torre Romanica Montepulciano Premium (d’Abruzzo).', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== ESPANHA — La Vache Espagnole (Bodegas López Morenas) =====
  { brand: 'La Vache Espagnole', sub: 'Branco', country: ES, region: 'Extremadura', grape: 'Macabeo 100%', alcohol: '12%', volume: '750ml',
    desc: 'La Vache Espagnole Branco (Bodegas López Morenas, D.O.P. Ribera del Guadiana).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'La Vache Espagnole', sub: 'Tinto', country: ES, region: 'Extremadura', grape: 'Tempranillo 90%, Monastrell 10%', alcohol: '14%', volume: '750ml',
    desc: 'La Vache Espagnole Tinto.', sizes: [{ name: '750ml', size: '750ml' }] },

  // ===== ÁFRICA DO SUL — Stormhoek (Western Cape) =====
  { brand: 'Stormhoek', sub: 'Pinot Grigio Branco', country: ZA, region: 'Western Cape', grape: 'Pinot Grigio', alcohol: '13%', volume: '750ml',
    desc: 'Stormhoek Pinot Grigio (África do Sul).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Stormhoek', sub: 'Chardonnay Branco', country: ZA, region: 'Western Cape', grape: 'Chardonnay', alcohol: '13%', volume: '750ml',
    desc: 'Stormhoek Chardonnay.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Stormhoek', sub: 'Sauvignon Blanc Branco', country: ZA, region: 'Western Cape', grape: 'Sauvignon Blanc', alcohol: '13%', volume: '750ml',
    desc: 'Stormhoek Sauvignon Blanc.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Stormhoek', sub: 'Cabernet Sauvignon Merlot Tinto', country: ZA, region: 'Western Cape', grape: 'Cabernet Sauvignon e Merlot', alcohol: '13,5%', volume: '750ml',
    desc: 'Stormhoek Cabernet Sauvignon / Merlot.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Stormhoek', sub: 'Pinotage Tinto', country: ZA, region: 'Western Cape', grape: 'Pinotage', alcohol: '13,5%', volume: '750ml',
    desc: 'Stormhoek Pinotage (uva emblemática sul-africana).', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Stormhoek', sub: 'Pinotage Malbec Tinto', country: ZA, region: 'Western Cape', grape: 'Pinotage / Malbec', alcohol: '13,5%', volume: '750ml',
    desc: 'Stormhoek Pinotage Malbec.', sizes: [{ name: '750ml', size: '750ml' }] },
  { brand: 'Stormhoek', sub: 'Syrah Tinto', country: ZA, region: 'Western Cape', grape: 'Syrah', alcohol: '13,5%', volume: '750ml',
    desc: 'Stormhoek Syrah.', sizes: [{ name: '750ml', size: '750ml' }] }
];

const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const existing = new Set(catalog.products.map(p => norm(p.name)));
let position = Math.max(0, ...catalog.products.map(p => Number(p.position) || 0));
let added = 0;

for (const w of W) {
  const fullName = w.brand.includes(' ') || w.brand.includes("'") ? `${w.brand} ${w.sub}` : `${w.brand} ${w.sub}`;
  const name = `${w.brand} ${w.sub}`;
  if (existing.has(norm(name))) { console.log('já existe, pulando:', name); continue; }
  position += 1; seq += 1;
  const ts = now + added;
  const vars = buildVariants(w.sizes);
  catalog.products.push({
    id: pid(),
    name,
    department: 'vinhos',
    subcategory: w.sub,
    brand: w.brand,
    sku: '',
    imported: true,
    country: w.country,
    region: w.region,
    price: vars[0]?.price || PRICE['750ml'],
    unit: w.volume ? `Garrafa ${w.volume}` : 'Garrafa 750ml',
    description: w.desc,
    images: [],
    variants: vars,
    attributes: {
      wineType: w.sub,
      grape: w.grape,
      alcohol: w.alcohol,
      volume: w.volume,
      region: `${w.region} (${w.country})`,
      serving: '12° a 14°C'
    },
    stock: null,
    stockMin: 3,
    maxPerOrder: null,
    restockDate: '',
    preparation: '',
    available: true,
    featured: false,
    madeToOrder: false,
    seasonal: false,
    giftEnabled: true,
    position,
    created: ts,
    updated: ts,
    deletedAt: null,
    weightGrams: WEIGHT[w.sizes[0].size] || 1300,
    lengthCm: 9, widthCm: 9, heightCm: 33,
    boxes: [{ variantId: null, units: 6, weightGrams: 8200, lengthCm: 31, widthCm: 27, heightCm: 20 }]
  });
  added++;
}

writeFileSync(catalogPath, JSON.stringify(catalog, null, 2) + '\n', 'utf8');
console.log(`\nTotal de produtos agora: ${catalog.products.length} (vinhos importados adicionados: ${added})`);
