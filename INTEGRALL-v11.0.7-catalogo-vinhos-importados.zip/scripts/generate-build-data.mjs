// Gera o snapshot público estático (<script id="buildData">) do public/index.html
// a partir do catálogo-fonte data/catalog.json, eliminando a duplicação manual
// dos dados entre o catálogo e o HTML.
//
// Uso:
//   node scripts/generate-build-data.mjs            # escreve no public/index.html
//   node scripts/generate-build-data.mjs --check    # apenas verifica (falha se divergente)
//
// Em modo --check o script compara o blob atual do HTML com o que seria gerado
// (ignorando o timestamp generatedAt, que é o único valor dependente do relógio
// do build) e sai com código 1 se houver divergência — usado pelo CI/build para
// garantir que o HTML nunca fique defasado em relação ao data/catalog.json.

import {readFileSync, writeFileSync, statSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, join} from 'node:path';
import {buildPublicSnapshot} from '../src/public-snapshot.js';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const catalogPath = join(root, 'data', 'catalog.json');
const indexPath = join(root, 'public', 'index.html');

const CHECK_ONLY = process.argv.includes('--check');

const OPEN = '<script id="buildData" type="application/json">';
const CLOSE = '</script>';

// Timestamp determinístico: usa a data de modificação do catálogo-fonte, assim
// builds idênticos geram bytes idênticos (sem ruído de relógio no diff).
function generatedAtForCatalog() {
  const mtime = statSync(catalogPath).mtime;
  const pad = n => String(n).padStart(2, '0');
  return `${mtime.getFullYear()}-${pad(mtime.getMonth() + 1)}-${pad(mtime.getDate())}T${pad(mtime.getHours())}:${pad(mtime.getMinutes())}:${pad(mtime.getSeconds())}-03:00`;
}

function stripTimestamp(snapshot) {
  // eslint-disable-next-line no-unused-vars
  const {generatedAt, ...rest} = snapshot;
  return rest;
}

function main() {
  const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));
  const html = readFileSync(indexPath, 'utf8');

  const openIdx = html.indexOf(OPEN);
  const closeIdx = html.indexOf(CLOSE, openIdx);
  if (openIdx === -1 || closeIdx === -1) {
    console.error('FALHA: bloco <script id="buildData"> não encontrado em public/index.html.');
    process.exit(1);
  }

  const generated = buildPublicSnapshot(catalog, {generatedAt: generatedAtForCatalog()});
  const newBlob = JSON.stringify(generated);

  const currentBlob = html.slice(openIdx + OPEN.length, closeIdx);
  let currentParsed = null;
  try {
    currentParsed = JSON.parse(currentBlob);
  } catch {
    currentParsed = null;
  }

  // Comparação semântica (ignora o timestamp e a ordem de chaves).
  const currentData = currentParsed ? stripTimestamp(currentParsed) : currentBlob;
  const generatedData = stripTimestamp(generated);
  const inSync = currentParsed !== null &&
    JSON.stringify(currentData) === JSON.stringify(generatedData);

  if (CHECK_ONLY) {
    if (!inSync) {
      console.error('FALHA: o #buildData embutido no public/index.html diverge de data/catalog.json.');
      console.error('Execute: npm run build:data para regenerar o snapshot público.');
      process.exit(1);
    }
    console.log(`BUILD DATA OK — #buildData sincronizado com data/catalog.json (${generated.products.length} produto(s)).`);
    return;
  }

  if (inSync && currentParsed?.generatedAt === generated.generatedAt) {
    console.log(`BUILD DATA — já sincronizado (${generated.products.length} produto(s)); nenhuma alteração.`);
    return;
  }

  const nextHtml = html.slice(0, openIdx + OPEN.length) + newBlob + html.slice(closeIdx);
  writeFileSync(indexPath, nextHtml);
  console.log(`BUILD DATA — #buildData regenerado a partir de data/catalog.json (${generated.products.length} produto(s)).`);
}

main();
