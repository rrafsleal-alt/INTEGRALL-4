// Cadastro dos sucos Marqués de Mendonça (catálogo Sucos.pdf) no catálogo-fonte.
// Executado uma vez para este lote; idempotente (não duplica por nome normalizado).
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const catalogPath = join(root, 'data', 'catalog.json');
const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));

const now = Date.now();
const pid = () => { let s = `product-${now}-`; for (let i = 0; i < 6; i++) s += 'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 36)]; return s; };
const vid = n => `variant-${now}-${n}-${Math.random().toString(36).slice(2, 8)}`;

// PREÇOS: o PDF não informa preços. Usamos, como referência temporária e editável,
// os mesmos valores do suco de uva já cadastrado (300ml = R$ 11,50; 1L = R$ 23,90),
// para a loja ficar funcional. O lojista deve ajustar no admin.
const P_300 = 1150;
const P_1L = 2390;
const STOCK = 60; // estoque de referência (o PDF não informa); ajustar no admin.

// Cada suco: nome, subcategoria, descrição, atributos, edição limitada?
const sucos = [
  {
    name: 'Suco Integral de Uva Branco',
    subcategory: 'Uva Branco',
    desc: 'Suco 100% integral de uva branca Marqués de Mendonça, sem adição de açúcar, água ou corantes. Leve, refrescante e naturalmente doce, rico em vitaminas e com notas frutadas delicadas. Uma opção clara e hidratante da vinícola, elaborada com uvas selecionadas. Disponível em garrafas de 300ml e 1 litro.',
    flavor: 'Uva Branco'
  },
  {
    name: 'Suco Integral de Tangerina',
    subcategory: 'Tangerina',
    desc: 'Suco integral de tangerina Marqués de Mendonça, elaborado com as variedades Clemenules e Ortanique. A Clemenules é doce e suculenta; a Ortanique, mais ácida e intensa — a combinação resulta num suco equilibrado, refrescante e cheio de sabor. Rico em vitamina C. Elaborado com aproximadamente 25 tangerinas por litro. Garrafas de 300ml e 1 litro.',
    flavor: 'Tangerina (Clemenules e Ortanique)'
  },
  {
    name: 'Suco Integral de Maçã',
    subcategory: 'Maçã',
    desc: 'Suco 100% integral de maçã Marqués de Mendonça, saboroso e rico em nutrientes essenciais, vitaminas (destaque para a vitamina C), potássio, magnésio e antioxidantes como flavonoides e polifenóis. Sem adição de açúcar. Elaborado com aproximadamente 15 maçãs por litro. Disponível em garrafas de 300ml e 1 litro.',
    flavor: 'Maçã'
  },
  {
    name: 'Suco Pink Lemonade (Edição Limitada)',
    subcategory: 'Pink Lemonade',
    desc: 'Suco misto Pink Lemonade Marqués de Mendonça — Edição Limitada. Combinação delicada e refrescante de limão e morango, com equilíbrio entre acidez, doçura e aroma natural. Leve, vibrante e cheio de personalidade, ideal bem gelado. Contém aromatizante natural (7% suco; bebida mista de limão e morango adoçada). Garrafas de 300ml e 1 litro.',
    flavor: 'Limão com Morango',
    limited: true
  },
  {
    name: 'Suco Integral de Goiaba',
    subcategory: 'Goiaba',
    desc: 'Suco misto de goiaba Marqués de Mendonça: elaborado com 40% de suco de goiaba integral e 60% de suco de maçã integral, buscando a melhor expressão de sabor e refrescância. A goiaba vermelha traz seu gosto marcante; a maçã equilibra a textura. A goiaba é rica em vitamina C (de 4 a 5 vezes mais que a laranja) e antioxidantes. Elaborado com aproximadamente 10 goiabas por litro. Garrafas de 300ml e 1 litro.',
    flavor: 'Goiaba Vermelha (com maçã)'
  },
  {
    name: 'Suco Integral de Laranja',
    subcategory: 'Laranja',
    desc: 'Suco 100% integral de laranja Marqués de Mendonça, elaborado exclusivamente com laranjas selecionadas e colhidas no ponto ideal de maturação. Sabor fresco, doce na medida e aroma natural; rico em vitamina C, sem adição de açúcar. Perfeito para o café da manhã e para momentos de pausa. Disponível em garrafas de 300ml e 1 litro.',
    flavor: 'Laranja'
  },
  {
    name: 'Suco Condimentado de Tomate',
    subcategory: 'Tomate',
    desc: 'Suco condimentado de tomate Marqués de Mendonça: combinação marcante e equilibrada, feita com tomates selecionados e um toque especial de especiarias, com notas aromáticas envolventes. Rico em licopeno, potássio e vitamina C. Ideal gelado, puro, ou para usar em drinks. Garrafas de 300ml e 1 litro.',
    flavor: 'Tomate com Especiarias'
  }
];

const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const existing = new Set(catalog.products.map(p => norm(p.name)));

let added = 0;
let position = Math.max(0, ...catalog.products.map(p => Number(p.position) || 0));

for (const s of sucos) {
  if (existing.has(norm(s.name))) { console.log('já existe, pulando:', s.name); continue; }
  position += 1;
  const ts = now + added;
  catalog.products.push({
    id: pid() + added,
    name: s.name,
    department: 'sucos',
    subcategory: s.subcategory,
    brand: 'Marqués de Mendonça',
    sku: '',
    imported: false,
    country: '',
    region: '',
    price: P_1L,
    unit: 'Garrafa de 1L e 300ml',
    description: s.desc,
    images: [], // sem foto ainda; o site usa placeholder até o upload pelo admin
    variants: [
      { id: vid('300'), name: '300ml', price: P_300, stock: STOCK, unit: '', position: 1, weightGrams: 520 },
      { id: vid('1l'),  name: '1L',    price: P_1L,  stock: STOCK, unit: '', position: 2, weightGrams: 1500 }
    ],
    attributes: {
      flavor: s.flavor,
      volume: '1L e 300ml',
      kind: s.limited ? 'Bebida mista (Edição Limitada)' : '100% Integral',
      sugar: 'Sem adição de açúcar e adoçantes',
      storage: 'Pasteurizado'
    },
    stock: null,
    stockMin: 3,
    maxPerOrder: null,
    restockDate: '',
    preparation: '',
    available: true,
    featured: false,
    madeToOrder: false,
    seasonal: Boolean(s.limited),
    giftEnabled: true,
    position,
    created: ts,
    updated: ts,
    deletedAt: null,
    // dimensões/peso de frete (não vão ao HTML público; usados no servidor)
    weightGrams: 1500,
    lengthCm: 9,
    widthCm: 9,
    heightCm: 32,
    boxes: [
      { variantId: null, units: 6, weightGrams: 9300, lengthCm: 30, widthCm: 26, heightCm: 18 }
    ]
  });
  added++;
  console.log('adicionado:', s.name);
}

writeFileSync(catalogPath, JSON.stringify(catalog, null, 2) + '\n', 'utf8');
console.log(`\nTotal de produtos agora: ${catalog.products.length} (adicionados: ${added})`);
