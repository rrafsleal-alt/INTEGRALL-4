#!/usr/bin/env node
// Verificação estática da entrega v11.0.4.
// Confirma os dois resultados inegociáveis (senha e detalhes abaixo) e que o
// modal lateral legado foi removido — sem usar execução dinâmica de código.
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const ROOT = process.cwd();
// A senha padrão é mantida fora do bundle: referenciamos apenas o hash.
const DEFAULT_HASH_MARKER = 'scrypt$32768$8$1$';
const skipDirs = new Set(['node_modules', '.git', 'coverage', '.cache', 'dist', 'build', 'docs']);
const textExt = new Set(['.js', '.mjs', '.cjs', '.json', '.html', '.htm', '.css', '.svg', '.sh', '.bat']);

function walk(dir) {
  const out = [];
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (skipDirs.has(ent.name)) continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) out.push(...walk(p));
    else if (ent.isFile() && textExt.has(path.extname(ent.name).toLowerCase())) out.push(p);
  }
  return out;
}
const read = p => { try { return fs.readFileSync(p, 'utf8'); } catch { return ''; } };
const rel = p => path.relative(ROOT, p).split(path.sep).join('/');

const files = walk(ROOT);
const failures = [];
const passes = [];
function check(cond, label, detail = '') {
  if (cond) { passes.push(label); console.log(`APROVADO — ${label}`); }
  else { failures.push(`${label}${detail ? `: ${detail}` : ''}`); console.error(`REPROVADO — ${label}${detail ? `: ${detail}` : ''}`); }
}

// 1) Versão do pacote
const pkg = JSON.parse(read(path.join(ROOT, 'package.json')) || '{}');
check(pkg.version === '11.0.4', 'versão do pacote é 11.0.4');

// 2) O hash padrão da senha existe na configuração do servidor (não a senha em texto puro).
const configSrc = read(path.join(ROOT, 'src', 'config.js'));
check(configSrc.includes(DEFAULT_HASH_MARKER), 'hash scrypt da senha padrão está presente em src/config.js (sem texto puro)');

// 3) Nenhum asset público (loja/admin) contém a senha em texto puro.
const publicFiles = files.filter(p => /(^|[\\/])public([\\/]|$)/i.test(rel(p)));
const publicLeaks = publicFiles.filter(p => {
  const t = read(p);
  // Procura pela senha literal completa (junção das duas metades para não escrevê-la aqui).
  const secret = ['159213', 'Rafs'].join('');
  return t.includes(secret);
});
check(publicLeaks.length === 0, 'senha padrão ausente de todo o bundle público (HTML/CSS/JS)', publicLeaks.map(rel).join(', '));

// 4) Existe exatamente um bloco semântico #productDetails e nenhum #productModal.
const htmlFiles = files.filter(p => /\.html?$/i.test(rel(p)));
const detailHosts = htmlFiles.filter(p => /id=["']productDetails["']/i.test(read(p)));
const legacyModals = htmlFiles.filter(p => /id=["']productModal["']/i.test(read(p)));
check(detailHosts.length === 1, 'existe exatamente um bloco semântico #productDetails', detailHosts.map(rel).join(', '));
check(legacyModals.length === 0, 'modal lateral legado #productModal foi removido', legacyModals.map(rel).join(', '));

// 5) Os detalhes estão antes do rodapé na ordem do DOM.
if (detailHosts.length === 1) {
  const html = read(detailHosts[0]);
  const detailsAt = html.search(/id=["']productDetails["']/i);
  const footerAt = html.search(/<footer\b/i);
  check(footerAt < 0 || detailsAt < footerAt, 'bloco de detalhes aparece antes do rodapé na ordem do DOM');
}

// 6) O bloco de detalhes não usa posicionamento que o tire do fluxo do documento.
const cssFiles = files.filter(p => /\.css$/i.test(rel(p)));
let unsafePosition = [];
for (const p of cssFiles) {
  const css = read(p);
  for (const m of css.matchAll(/([^{}]*#productDetails[^{}]*)\{([^{}]*)\}/gisu)) {
    if (/position\s*:\s*(fixed|absolute|sticky)/i.test(m[2])) unsafePosition.push(rel(p));
  }
}
check(unsafePosition.length === 0, '#productDetails permanece no fluxo normal do documento (sem fixed/absolute/sticky)', unsafePosition.join(', '));

// 7) O body não força min-width que cause rolagem horizontal em telas pequenas.
const allCss = cssFiles.map(p => read(p)).join('\n');
check(!/body\s*\{[^}]*min-width\s*:\s*320px/isu.test(allCss), 'body não força min-width global de 320px');

// 8) A senha não é persistida em localStorage/sessionStorage no cliente.
const storageLeaks = files.filter(p => {
  const t = read(p);
  return /(localStorage|sessionStorage)/.test(t) && /setItem\s*\([^)]*(password|senha|credential)/i.test(t);
});
check(storageLeaks.length === 0, 'credencial não é persistida em localStorage/sessionStorage', storageLeaks.map(rel).join(', '));

console.log(`\nResumo: ${passes.length} aprovado(s), ${failures.length} reprovado(s).`);
if (failures.length) process.exit(1);
