// Cadastro dos vinhos nacionais (Vinhos Nacionais_compressed.pdf) no catálogo-fonte.
// Região: Serra Gaúcha-RS (Brasil). Idempotente por nome normalizado.
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const catalogPath = join(root, 'data', 'catalog.json');
const catalog = JSON.parse(readFileSync(catalogPath, 'utf8'));

const now = Date.now();
const seq = { p: 0 };
const pid = () => `product-${now}-vn${(seq.p++).toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
const vid = n => `variant-${now}-vn-${n}-${Math.random().toString(36).slice(2, 6)}`;

// PREÇOS PROVISÓRIOS por tamanho (o PDF não informa preços). Ajustar no admin.
const PRICE = { '375ml': 2150, '660ml': 2490, '750ml': 2990, '1L': 3490, '1,5L': 4990, '4,5L': 11990 };
const STOCK = 60;
const WEIGHT = { '375ml': 700, '660ml': 1100, '750ml': 1300, '1L': 1600, '1,5L': 2300, '4,5L': 6800 };

// v: [{name, size}]
function variants(list) {
  return list.map((v, i) => ({
    id: vid(i),
    name: v.name,
    price: PRICE[v.size] || 2990,
    stock: STOCK,
    unit: '',
    position: i + 1,
    weightGrams: WEIGHT[v.size] || 1300
  }));
}

// Cada item: name, brand, sub, grape, alcohol, volume, harvest, desc, sizes
const W = [
  // ---- Linha CAVE (vinhos finos) ----
  { brand: 'Marqués de Mendonça', name: 'Vinho Cave Cabernet Sauvignon', sub: 'Tinto Seco',
    grape: '100% Cabernet Sauvignon', alcohol: '12,5%', volume: '750ml e 375ml', harvest: 'Safra 2022',
    sizes: [{ name: '750ml', size: '750ml' }, { name: '375ml', size: '375ml' }],
    desc: 'Vinho fino tinto seco Cave Cabernet Sauvignon, Casa Narducci (Serra Gaúcha-RS). De corpo médio e taninos sedosos, encanta com aromas de frutas vermelhas e um toque sutil de especiarias. Servir a 12° a 14°C.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Cave Merlot', sub: 'Tinto Seco',
    grape: '100% Merlot', alcohol: '12,4%', volume: '750ml e 375ml', harvest: 'Safra 2022',
    sizes: [{ name: '750ml', size: '750ml' }, { name: '375ml', size: '375ml' }],
    desc: 'Vinho fino tinto seco Cave Merlot, Casa Narducci (Serra Gaúcha-RS). De corpo médio, taninos suaves e textura aveludada, com aromas de ameixa e frutas vermelhas maduras e delicadas notas de especiarias.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Cave Cabernet Franc', sub: 'Tinto Seco',
    grape: '100% Cabernet Franc', alcohol: '12,6%', volume: '750ml', harvest: 'Safra 2023',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho fino tinto seco Cave Cabernet Franc, Casa Narducci. De corpo médio, taninos finos e acidez vivaz, com aromas de framboesa, cereja e violeta, notas herbáceas de pimentão verde e especiarias. Elegante, fresco e de final agradável.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Cave Tannat', sub: 'Tinto Seco',
    grape: '100% Tannat', alcohol: '12,5%', volume: '750ml', harvest: 'Safra 2023',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho fino tinto seco Cave Tannat, Casa Narducci. Encorpado, de taninos robustos e acidez marcante, com aromas intensos de amora, mirtilo e ameixa negra, notas de chocolate amargo, tabaco e especiarias. Potente, estruturado e de final longo.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Cave Equilíbrio', sub: 'Tinto Seco',
    grape: '50% Cabernet Sauvignon · 50% Merlot', alcohol: '12,5%', volume: '750ml', harvest: 'Safra 2023',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho fino tinto seco Cave Equilíbrio (blend), Casa Narducci. De corpo médio a encorpado, taninos aveludados e acidez equilibrada, com aromas de cassis, ameixa e cereja, notas de pimentão, cedro e baunilha. Harmonioso, macio e de final elegante.' },
  // ---- Linha Clássico (vinhos finos) ----
  { brand: 'Marqués de Mendonça', name: 'Vinho Clássico Moscato', sub: 'Branco Seco',
    grape: '100% Moscato', alcohol: '11,0%', volume: '750ml', harvest: 'Safra 2024',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho fino branco seco Clássico Moscato, Casa Narducci. Leve e aromático, com aromas intensos de lichia, pêssego, flor de laranjeira e mel. Acidez vibrante, corpo leve e final fresco com delicado dulçor residual.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Clássico Rosé', sub: 'Rosé Seco',
    grape: '100% Cabernet Sauvignon', alcohol: '12,6%', volume: '750ml', harvest: 'Safra 2024',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho fino rosé seco Clássico, Casa Narducci. Leve e refrescante, com aromas de frutas vermelhas e um delicado toque floral, oferecendo um paladar equilibrado e agradável.' },
  // ---- Varietais de Mesa (Marqués de Mendonça) ----
  { brand: 'Marqués de Mendonça', name: 'Vinho Bordô (Seco e Suave)', sub: 'Tinto de Mesa',
    grape: '100% Bordô', alcohol: 'Seco 10,9% · Suave 10,6%', volume: '375ml, 750ml e 4,5L', harvest: '',
    sizes: [{ name: 'Seco 375ml', size: '375ml' }, { name: 'Suave 375ml', size: '375ml' }, { name: 'Seco 750ml', size: '750ml' }, { name: 'Suave 750ml', size: '750ml' }, { name: 'Seco 4,5L (Garrafão)', size: '4,5L' }, { name: 'Suave 4,5L (Garrafão)', size: '4,5L' }],
    desc: 'Vinho tinto de mesa Bordô, Marqués de Mendonça (Serra Gaúcha-RS), elaborado com uvas Bordô. Disponível nas versões Seco (10,9%) e Suave (10,6%), em garrafas de 375ml e 750ml e no garrafão de 4,5 litros.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Lorena Seco', sub: 'Branco Seco',
    grape: '100% Lorena', alcohol: '11,0%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho branco de mesa seco Lorena, Marqués de Mendonça. Elaborado com 100% uvas Lorena, leve e aromático. Serra Gaúcha-RS.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Niágara (Seco e Suave)', sub: 'Branco de Mesa',
    grape: '100% Niágara', alcohol: 'Seco 10,9% · Suave 10,6%', volume: '750ml e 4,5L', harvest: '',
    sizes: [{ name: 'Seco 750ml', size: '750ml' }, { name: 'Suave 750ml', size: '750ml' }, { name: 'Seco 4,5L (Garrafão)', size: '4,5L' }, { name: 'Suave 4,5L (Garrafão)', size: '4,5L' }],
    desc: 'Vinho branco de mesa Niágara, Marqués de Mendonça, elaborado com 100% uvas Niágara. Versões Seco (10,9%) e Suave (10,6%), em garrafa de 750ml e garrafão de 4,5 litros.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Rosé de Mesa Seco', sub: 'Rosé Seco',
    grape: '100% Bordô', alcohol: '10,9%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho rosé de mesa seco, Marqués de Mendonça, elaborado com 100% uvas Bordô. Leve e refrescante. Serra Gaúcha-RS.' },
  { brand: 'Marqués de Mendonça', name: 'Vinho Tinto de Mesa (Seco e Suave)', sub: 'Tinto de Mesa',
    grape: '60% Bordô · 40% Isabel', alcohol: 'Seco 10,9% · Suave 10,6%', volume: '1L', harvest: '',
    sizes: [{ name: 'Seco 1L', size: '1L' }, { name: 'Suave 1L', size: '1L' }],
    desc: 'Vinho tinto de mesa em garrafa de 1 litro, Marqués de Mendonça. Corte de 60% Bordô e 40% Isabel, nas versões Seco (10,9%) e Suave (10,6%). Serra Gaúcha-RS.' },
  // ---- Nobel ----
  { brand: 'Nobel', name: 'Vinho Nobel Tinto Seco', sub: 'Tinto Seco',
    grape: 'Uvas tintas de mesa', alcohol: '10,8%', volume: '750ml e 1,5L', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }, { name: '1,5L (Galão)', size: '1,5L' }],
    desc: 'Vinho tinto seco Nobel, Serra Gaúcha-RS. Disponível em garrafa de 750ml e no galão de 1,5 litro.' },
  { brand: 'Nobel', name: 'Vinho Nobel Tinto Suave', sub: 'Tinto Suave',
    grape: 'Uvas tintas de mesa', alcohol: '10,6%', volume: '750ml e 1,5L', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }, { name: '1,5L (Galão)', size: '1,5L' }],
    desc: 'Vinho tinto suave Nobel, Serra Gaúcha-RS, macio e adocicado. Em garrafa de 750ml e galão de 1,5 litro.' },
  { brand: 'Nobel', name: 'Vinho Nobel Branco Seco', sub: 'Branco Seco',
    grape: 'Uvas brancas de mesa', alcohol: '10,8%', volume: '750ml e 1,5L', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }, { name: '1,5L (Galão)', size: '1,5L' }],
    desc: 'Vinho branco seco Nobel, Serra Gaúcha-RS. Leve e fresco. Em garrafa de 750ml e galão de 1,5 litro.' },
  // ---- Courmayeur (espumantes & frisantes) ----
  { brand: 'Courmayeur', name: 'Espumante Courmayeur Moscatel', sub: 'Espumante',
    grape: 'Moscato', alcohol: '7,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante moscatel Courmayeur, Serra Gaúcha-RS. Doce e aromático, com notas de frutas e flores; 7,5% de álcool.' },
  { brand: 'Courmayeur', name: 'Espumante Courmayeur Prosecco Brut', sub: 'Espumante Branco',
    grape: 'Prosecco (Glera)', alcohol: '11,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante branco brut Prosecco Courmayeur, Serra Gaúcha-RS. Fresco, com perlage fina e acidez vibrante; 11,5%.' },
  { brand: 'Courmayeur', name: 'Espumante Courmayeur Rosé Moscatel', sub: 'Espumante Rosé',
    grape: 'Moscato', alcohol: '7,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante rosé moscatel Courmayeur, Serra Gaúcha-RS. Delicado e adocicado, com aromas frutados; 7,5%.' },
  { brand: 'Courmayeur', name: 'Espumante Courmayeur Branco Brut', sub: 'Espumante Branco',
    grape: 'Uvas brancas', alcohol: '11,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante branco brut Courmayeur, Serra Gaúcha-RS. Seco, cremoso e refrescante; 11,5%.' },
  { brand: 'Courmayeur', name: 'Espumante Courmayeur Brut Rosé', sub: 'Espumante Rosé',
    grape: 'Uvas tintas', alcohol: '11,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante brut rosé Courmayeur, Serra Gaúcha-RS. Estruturado, com aromas de frutas vermelhas; 11,5%.' },
  { brand: 'Courmayeur', name: 'Espumante Courmayeur Demi-Sec', sub: 'Espumante Branco',
    grape: 'Uvas brancas', alcohol: '11,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante branco demi-sec Courmayeur, Serra Gaúcha-RS. Meio-doce, macio e fácil de beber; 11,5%.' },
  { brand: 'Courmayeur', name: 'Lambrusco Courmayeur', sub: 'Frisante Tinto',
    grape: 'Uvas tintas', alcohol: '11,5%', volume: '660ml', harvest: '',
    sizes: [{ name: '660ml', size: '660ml' }],
    desc: 'Lambrusco frisante tinto Courmayeur, Serra Gaúcha-RS. Frisante, leve e frutado; 660ml, 11,5%.' },
  // ---- Tevere ----
  { brand: 'Tevere', name: 'Espumante Tevere Moscatel', sub: 'Espumante',
    grape: 'Moscato', alcohol: '7,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante moscatel Tevere, Serra Gaúcha-RS. Doce, aromático e refrescante; 7,5%.' },
  { brand: 'Tevere', name: 'Espumante Tevere Brut', sub: 'Espumante Branco',
    grape: 'Uvas brancas', alcohol: '12,0%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante branco brut Tevere, Serra Gaúcha-RS. Seco e encorpado, com boa persistência; 12,0%.' },
  // ---- Serra Gaúcha ----
  { brand: 'Serra Gaúcha', name: 'Espumante Serra Gaúcha Branco Brut', sub: 'Espumante Branco',
    grape: 'Uvas brancas', alcohol: '11,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante branco brut Serra Gaúcha, Serra Gaúcha-RS. Seco e refrescante; 11,5%.' },
  { brand: 'Serra Gaúcha', name: 'Espumante Serra Gaúcha Moscatel Branco', sub: 'Espumante',
    grape: 'Moscato', alcohol: '7,5%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Vinho moscatel espumante branco Serra Gaúcha, Serra Gaúcha-RS. Doce e aromático; 7,5%.' },
  { brand: 'Serra Gaúcha', name: 'Espumante Serra Gaúcha Zero Álcool', sub: 'Sem Álcool',
    grape: 'Uvas brancas', alcohol: '0,0%', volume: '750ml', harvest: '',
    sizes: [{ name: '750ml', size: '750ml' }],
    desc: 'Espumante Serra Gaúcha Zero Álcool, Serra Gaúcha-RS. Toda a experiência de um espumante sem álcool (0,0%).' },
  // ---- Frisantes (Weindorf / Del Sole) ----
  { brand: 'Weindorf', name: 'Frisante Weindorf Branco Suave', sub: 'Frisante Branco',
    grape: 'Uvas brancas', alcohol: '10,5%', volume: '660ml', harvest: '',
    sizes: [{ name: '660ml', size: '660ml' }],
    desc: 'Frisante branco suave Weindorf, Serra Gaúcha-RS. Leve, gaseificado e adocicado; 660ml, 10,5%.' },
  { brand: 'Del Sole', name: 'Frisante Del Sole Branco Filtrado', sub: 'Frisante Branco',
    grape: 'Uvas brancas', alcohol: '11%', volume: '660ml', harvest: '',
    sizes: [{ name: '660ml', size: '660ml' }],
    desc: 'Frisante branco filtrado Del Sole, Serra Gaúcha-RS. Leve e refrescante; 660ml, 11%.' },
  { brand: 'Del Sole', name: 'Frisante Del Sole Rosé Filtrado', sub: 'Frisante Rosé',
    grape: 'Uvas tintas', alcohol: '11%', volume: '660ml', harvest: '',
    sizes: [{ name: '660ml', size: '660ml' }],
    desc: 'Frisante rosé filtrado Del Sole, Serra Gaúcha-RS. Frutado e leve; 660ml, 11%.' }
];

const norm = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const existing = new Set(catalog.products.map(p => norm(p.name)));
let position = Math.max(0, ...catalog.products.map(p => Number(p.position) || 0));
let added = 0;

for (const w of W) {
  if (existing.has(norm(w.name))) { console.log('já existe, pulando:', w.name); continue; }
  position += 1;
  const ts = now + added;
  const vars = variants(w.sizes);
  catalog.products.push({
    id: pid(),
    name: w.name,
    department: 'vinhos',
    subcategory: w.sub,
    brand: w.brand,
    sku: '',
    imported: false,
    country: 'Brasil',
    region: 'Serra Gaúcha-RS',
    price: vars[0]?.price || 2990,
    unit: w.volume ? `Garrafa ${w.volume}` : 'Garrafa 750ml',
    description: w.desc,
    images: [],
    variants: vars,
    attributes: {
      wineType: w.sub,
      grape: w.grape,
      alcohol: w.alcohol,
      volume: w.volume,
      region: 'Serra Gaúcha-RS',
      ...(w.harvest ? { harvest: w.harvest } : {}),
      serving: '12° a 14°C'
    },
    stock: null,
    stockMin: 3,
    maxPerOrder: null,
    restockDate: '',
    preparation: '',
    available: true,
    featured: false,
    madeToOrder: false,
    seasonal: false,
    giftEnabled: true,
    position,
    created: ts,
    updated: ts,
    deletedAt: null,
    weightGrams: WEIGHT[w.sizes[0].size] || 1300,
    lengthCm: 9,
    widthCm: 9,
    heightCm: 33,
    boxes: [{ variantId: null, units: 6, weightGrams: 8200, lengthCm: 31, widthCm: 27, heightCm: 20 }]
  });
  added++;
  console.log('adicionado:', w.name);
}

writeFileSync(catalogPath, JSON.stringify(catalog, null, 2) + '\n', 'utf8');
console.log(`\nTotal de produtos agora: ${catalog.products.length} (vinhos nacionais adicionados: ${added})`);
