# Segurança — INTEGRALL v11.0

## Administração

O painel `/admin` usa autenticação real no backend. A senha padrão solicitada para primeiro acesso é validada por hash scrypt no servidor e nunca é embutida em texto puro no JavaScript do navegador.

Configure em ambiente seguro:

- `ADMIN_EMAIL`;
- `ADMIN_PASSWORD_HASH` (gere com `npm run admin:hash -- "senha-forte"`);
- `ADMIN_DEFAULT_LOGIN_ENABLED=false` depois de confirmar a nova senha, caso queira desativar a credencial padrão;
- `ADMIN_SESSION_SECRET` com pelo menos 32 caracteres aleatórios e persistentes (sem ele, o processo gera um segredo temporário e encerra as sessões a cada reinício);
- `ADMIN_ROLE=admin|editor|operator`.

**Em produção (`NODE_ENV=production`) o processo se recusa a iniciar** caso não exista um `ADMIN_PASSWORD_HASH` próprio ou caso a senha padrão ainda esteja habilitada (`ADMIN_DEFAULT_LOGIN_ENABLED` precisa estar explicitamente `false`). Trata-se de um bloqueio de boot, não apenas de um aviso, para evitar que um deploy de produção permaneça com a credencial de primeiro acesso.

A sessão é assinada, possui expiração, cookie `HttpOnly`, `SameSite` e `Secure` em HTTPS. Alterações administrativas exigem token CSRF e as permissões são revalidadas no backend. O login possui rate limiting e mensagens genéricas para reduzir enumeração de usuários.

## Content-Security-Policy e clickjacking

A proteção contra clickjacking (`frame-ancestors 'self'` e `X-Frame-Options: SAMEORIGIN`) é aplicada via **header HTTP** (`src/security.js`), que é o único meio válido para a diretiva `frame-ancestors`. A `<meta http-equiv="Content-Security-Policy">` do HTML não declara `frame-ancestors` (diretivas de enquadramento são ignoradas em meta); o restante da CSP permanece na meta como defesa em profundidade.

## Snapshot público do catálogo (`#buildData`)

O snapshot embutido no `public/index.html` é **gerado no build** a partir do `data/catalog.json` (`npm run build:data`; `npm run check:data` falha o build/CI se houver divergência). Ele é saneado para o público: não inclui dados de logística/embalagem (peso e dimensões usados no frete) nem textos/configurações sensíveis do comércio — esses dados ficam no servidor e são entregues, quando necessário, via `GET /api/catalog`.

## Upload de imagens

Uploads administrativos usam `multipart/form-data` e são validados no servidor. O backend:

- aceita JPG, PNG e WebP por allowlist;
- verifica assinatura/magic bytes, não apenas extensão;
- limita o arquivo a 10 MB;
- limita dimensões a 8.000 px por lado e 40 milhões de pixels;
- valida integridade estrutural dos formatos suportados;
- remove metadados EXIF/XMP/COM desnecessários quando possível;
- gera identificadores aleatórios com UUID;
- registra checksum SHA-256, tamanho, dimensões, alt text, finalidade e autor;
- impede exclusão de mídia ainda referenciada pelo catálogo;
- nunca usa o nome fornecido pelo usuário como caminho de armazenamento.

SVG é rejeitado por padrão. O endpoint legado de Data URL permanece somente como compatibilidade de migração e passa pela mesma validação binária; a interface principal utiliza upload real de arquivo.

## Pedidos, preços e estoque

O navegador envia IDs, quantidades, variante, presente e dados do cliente/entrega. O servidor consulta o catálogo persistido e recalcula preço unitário, subtotal, frete, descontos e total. Valores monetários enviados pelo navegador não são confiáveis.

`clientOrderId` possui unicidade para idempotência. Cada pedido recebe `checkoutToken` aleatório de alta entropia, comparado em tempo constante. A máquina de estados de pedido bloqueia regressões e transições inválidas.

## Mercado Pago

Quando `MERCADO_PAGO_ACCESS_TOKEN` estiver ativo em produção, `MERCADO_PAGO_WEBHOOK_SECRET` é obrigatório. O webhook é validado, o pagamento é consultado no provedor e valor/moeda/preferência são conferidos no backend antes da alteração de estado. Reenvios não provocam baixa de estoque duplicada.

Nunca armazene número completo de cartão ou CVV. O projeto utiliza o fluxo tokenizado/hospedado do provedor.

## Banco de dados

Migrations versionadas ficam em `migrations/` e são aplicadas com advisory lock e checksum. Faça backup antes de qualquer migration em banco real.

Em produção, prefira `DATABASE_SSL_MODE=verify-full`. O modo `require` existe apenas para provedores que não forneçam cadeia de CA verificável e deve ser tratado como exceção documentada.

## Headers, logs e erros

O servidor desabilita `X-Powered-By`, aplica headers de segurança/CSP, usa request ID, evita stack traces públicos e redige padrões sensíveis dos logs. Não registre senhas, tokens, CVV ou dados pessoais sem necessidade operacional.

## Segredos

Nunca versione `.env`, `DATABASE_URL`, credenciais do Mercado Pago, SMTP, Correios/Jadlog ou segredos administrativos. Use `.env.example` somente como modelo sem valores reais e um secret manager no ambiente de produção.
