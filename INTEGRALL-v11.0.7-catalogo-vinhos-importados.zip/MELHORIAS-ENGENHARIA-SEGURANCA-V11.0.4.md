# MELHORIAS DE ENGENHARIA E SEGURANÇA — INTEGRALL v11.0.4 (endurecimento)

Após a entrega da v11.0.4 (correção da senha admin e dos detalhes do produto
abaixo da vitrine), foram aplicadas três melhorias de engenharia/segurança,
**sem alterar framework, identidade visual, produtos, dados ou fluxos**. Nenhuma
delas afrouxa validação existente; pelo contrário, acrescentam garantias.

## 1. CSP — diretiva inválida na `<meta>` removida; proteção mantida no header HTTP

- **Problema:** o `public/index.html` declarava uma `<meta http-equiv="Content-Security-Policy">`
  contendo `frame-ancestors 'self'`. A diretiva `frame-ancestors` **não é suportada
  em `<meta>`** — ela só é válida como **header HTTP** — e é silenciosamente
  ignorada quando vem na meta, dando falsa sensidade de proteção.
- **Correção:** removida a diretiva `frame-ancestors` da meta CSP. A proteção real
  contra clickjacking continua sendo aplicada pelo **header HTTP** em `src/security.js`
  (`Content-Security-Policy: frame-ancestors 'self'` **e** `X-Frame-Options: SAMEORIGIN`),
  que é o lugar correto e válido. Verificado por teste automatizado
  (`tests/visual-editor.test.js` exige `frame-ancestors` no header e a sua **ausência** na meta).

## 2. Produção recusa subir com senha padrão ativa ou sem hash próprio

- **Problema:** o aviso de "senha padrão ativa" era apenas um *warning* no log; um
  deploy de produção podia, por engano, continuar com a senha de primeiro acesso.
- **Correção:** `src/config.js` → `assertProductionConfig()` agora **interrompe o
  boot em produção** (`NODE_ENV=production`) quando:
  1. não existe `ADMIN_PASSWORD_HASH` próprio (hash scrypt da senha real do lojista); e/ou
  2. `ADMIN_DEFAULT_LOGIN_ENABLED` não está explicitamente `false` (senha padrão ligada).
- Fora de produção (desenvolvimento) nada muda: o primeiro acesso continua funcional.
- Coberto por `tests/production-config.test.js` (4 casos): padrão ativa é recusada;
  sem hash é recusado; configuração correta passa; fora de produção não exige nada.
- Verificado por execução real: o processo recusa boot com mensagem objetiva listando
  o que falta, e sobe normalmente quando `DATABASE_URL`/`PUBLIC_URL`/`ADMIN_PASSWORD_HASH`
  estão definidos e `ADMIN_DEFAULT_LOGIN_ENABLED=false`.

## 3. CI com GitHub Actions + suíte E2E Playwright versionada no repositório

- **Novo:** `.github/workflows/ci.yml` com dois jobs:
  - **test:** `npm ci` → `check` → `npm test` (unitários) → `security:scan` →
    `build` → `check:data` (sincronia do embed) → `verify:v11.0.4`.
  - **e2e:** `npm ci` → `npx playwright install --with-deps chromium` → `npm run test:e2e`,
    com upload do relatório Playwright como artefato.
- **Nova suíte E2E** (`@playwright/test` como **devDependency** de teste, única
  dependência nova — não vai para produção):
  - `playwright.config.js` — sobe o servidor (`PORT=… node server.js`) e aguarda
    `/api/health`; três viewports (mobile Pixel 5, iPad, desktop Chrome).
  - `e2e/produto-detalhes.spec.js` — 7 testes do requisito central (detalhes ABAIXO
    da vitrine, sem modal/overlay/lock, sem scroll horizontal, coluna única em 1920px,
    mobile 320px sem corte, troca de produto sem dado residual, Escape fecha,
    reload com `#product=` mantém aberto, adicionar à sacola abre a gaveta).
  - `e2e/admin-auth.spec.js` — 3 testes (senha errada recusada / correta autentica;
    sessão persiste após reload e logout bloqueia; `/api/admin/products` responde
    401 sem sessão). **A senha nunca é literal no teste** — vem da env `ADMIN_PASSWORD`
    com fallback para o ambiente de desenvolvimento.
- A suíte foi **executada de verdade** neste ambiente (Chromium 149) e passa
  integralmente (30/30). Em CI o Playwright baixa o navegador por `playwright install`.

## 4. O `#buildData` embutido no HTML passa a ser gerado a partir de `data/catalog.json`

- **Problema:** o snapshot público embutido no `<script id="buildData">` do
  `public/index.html` era mantido **à mão**, duplicando os dados do catálogo-fonte.
  A auditoria constatou que ele estava **defasado**: descrições de produto vazias no
  HTML enquanto o catálogo as tinha, e estoques "1000" no HTML enquanto o catálogo
  trazia os valores reais (ex.: 60/48/30/40/24). Era exatamente o risco de divergência.
- **Correção:**
  - `src/public-snapshot.js` — `buildPublicSnapshot(catalog)` deriva o snapshot público
    do catálogo-fonte, aplicando de forma **explícita e única** o saneamento estático:
    remove do produto os campos de logística/embalagem (`lengthCm`, `widthCm`,
    `heightCm`, `boxes`, `weightGrams`, `minPerOrder`) e da variante o `weightGrams`,
    e zera no `commerce` os textos/configurações sensíveis (política, termos, trocas,
    CNPJ, e-mails, nome empresarial) que o runtime recebe via `GET /api/catalog`.
  - `scripts/generate-build-data.mjs` — gera o blob e o injeta no `index.html`
    (`npm run build:data`); o modo `--check` (`npm run check:data`) **falha o build/CI**
    se o HTML estiver defasado em relação ao `data/catalog.json`. O timestamp
    `generatedAt` é derivado do mtime do catálogo, gerando saída determinística.
  - `npm run build` agora executa `check && build:data && audit`, mantendo o embed
    sempre sincronizado.
- **Segurança preservada:** o snapshot continua sem os dados de frete/embalagem e sem
  os textos legais no HTML; esses dados seguem vindo do servidor. Os estoques e
  descrições que passaram a aparecer no snapshot **já eram entregues ao cliente pelo
  `/api/catalog`** em runtime — não há exposição nova de informação.
- Coberto por `tests/public-snapshot.test.js` (7 casos, incluindo a garantia de que o
  embed no HTML é exatamente o snapshot derivado do catálogo).

## 5. Resultado dos gates (execução real)

- `npm run check` (sintaxe): **OK** — 51 arquivos.
- `npm test` (unitários): **114/114 passando** (eram 103 na v11.0.4 inicial).
- `npm run security:scan`: **OK** — 35 arquivos.
- `npm run audit` (catálogo): **AUDIT OK** — 5 produtos, assets presentes.
- `npm run verify:v11.0.4`: **9/9 aprovados**.
- `npm run build` (check + build:data + audit): **OK**.
- `npm run check:data`: **OK** — `#buildData` sincronizado com `data/catalog.json`.
- `npm run test:e2e` (Playwright, Chromium 149): **30/30 passando**.
- `npm audit --omit=dev`: **0 vulnerabilidades** em produção.

## 6. Dependências

- Adicionada **apenas** `@playwright/test` (devDependency, escopo de teste/E2E).
  Nenhuma dependência de produção foi adicionada, removida ou atualizada.
- O `package-lock.json` foi regenerado para incluir a nova devDependency; `npm ci`
  continua funcionando a partir do lockfile.

## 7. Limitações que permanecem

- Os E2E foram executados em **Chromium headless** neste ambiente Linux. No CI do
  GitHub também usa-se Chromium; Firefox/WebKit não fazem parte da matriz (evitado
  para manter a matriz enxuta), mas os recursos usados são padrão.
- Mercado Pago, Correios/Jadlog e SMTP seguem dependentes de credenciais e não são
  exercitados ao vivo (desligados sem configuração).
