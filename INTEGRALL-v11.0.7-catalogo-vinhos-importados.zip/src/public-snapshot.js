// Snapshot público ESTÁTICO embutido no <script id="buildData"> do index.html.
//
// O front da loja (public/js/store/catalog.js) usa este blob como estado
// inicial e, em seguida, tenta sincronizar com o servidor via GET /api/catalog
// (ver public/js/store/app.js). Se a API responder, os dados do servidor
// prevalecem; se a API estiver indisponível (abertura do arquivo local,
// hospedagem puramente estática sem backend, queda momentânea) a loja continua
// funcionando com o snapshot embutido.
//
// DIFERENÇA ENTRE OS DOIS CAMINHOS:
//  - /api/catalog usa publicCatalog() (src/catalog.js), que recebe o config do
//    servidor e expõe o que o runtime precisa (inclusive dimensões usadas no
//    cálculo de frete, pois o cálculo pesado acontece no SERVIDOR).
//  - Este snapshot vai para o HTML entregue ao navegador, portanto NÃO deve
//    carregar dados de logística/embalagem (peso e dimensões) nem informações
//    sensíveis do comércio que não são necessários à renderização estática.
//
// Para eliminar a duplicação/divergência entre o catálogo-fonte (data/catalog.json)
// e o blob no HTML, este módulo deriva o snapshot do catálogo-fonte. A regra de
// saneamento é explícita e única; o script scripts/generate-build-data.mjs a
// aplica e injeta o resultado no index.html durante o build.

// Campos removidos do PRODUTO no snapshot estático: dados de embalagem/logística
// (peso e dimensões usados no cálculo de frete no servidor) e o pedido mínimo,
// que não são usados pela renderização estática da vitrine e não devem ir para
// o HTML público. O runtime recebe esses campos via /api/catalog quando precisa.
const PRODUCT_FIELDS_STRIPPED = [
  'lengthCm', 'widthCm', 'heightCm', 'boxes', // dimensões/embalagem (frete)
  'weightGrams',                              // peso unitário (frete)
  'minPerOrder'                               // regra operacional de pedido mínimo
];

// Campos removidos de cada VARIANTE no snapshot estático (peso para frete).
const VARIANT_FIELDS_STRIPPED = ['weightGrams'];

// Campos do objeto `commerce` que NÃO são expostos no snapshot estático.
// O runtime os recebe (e sanitiza) via /api/catalog; no HTML entregue eles
// ficam vazios para não vazar textos legais/configurações que o back controla.
const COMMERCE_PUBLIC_FIELDS = new Set([
  'retentionDays', 'pixKey', 'paymentLink', 'paymentMethods',
  'apiBaseUrl', 'apiMode', 'lastUpdated'
]);

// String default para campos de texto do commerce no snapshot estático.
const COMMERCE_BLANK = '';

function stripFields(value, fields) {
  if (!value || typeof value !== 'object') return value;
  const clone = Array.isArray(value) ? value.slice() : {...value};
  for (const field of fields) {
    if (field in clone) delete clone[field];
  }
  return clone;
}

/**
 * Constrói o snapshot público estático a partir do catálogo-fonte (o mesmo
 * objeto gravado em data/catalog.json).
 *
 * @param {object} catalog Catálogo cru normalizável (version/settings/products/commerce).
 * @param {object} [options]
 * @param {string} [options.generatedAt] Timestamp ISO de geração (determinístico no build).
 * @returns {object} Blocos de dados para embutir no <script id="buildData">.
 */
export function buildPublicSnapshot(catalog, {generatedAt} = {}) {
  const source = catalog && typeof catalog === 'object' ? catalog : {};
  const settings = source.settings && typeof source.settings === 'object' ? source.settings : {};
  const rawProducts = Array.isArray(source.products) ? source.products : [];
  const rawCommerce = source.commerce && typeof source.commerce === 'object' ? source.commerce : {};

  // Produtos: remove itens ocultos/excluídos e saneia cada entrada e suas variantes.
  const products = rawProducts
    .filter(product => product && product.hidden !== true && !product.deletedAt)
    .map(product => {
      const clean = stripFields(product, PRODUCT_FIELDS_STRIPPED);
      if (Array.isArray(clean.variants)) {
        clean.variants = clean.variants.map(variant => stripFields(variant, VARIANT_FIELDS_STRIPPED));
      }
      return clean;
    });

  // Commerce: mantém apenas os campos públicos; textos/configurações sensíveis
  // são zerados no HTML (o runtime os busca na API).
  const commerce = {};
  // Preserva a forma completa do objeto com strings vazias para os campos
  // reservados, e os campos públicos efetivos.
  for (const key of Object.keys(rawCommerce)) {
    commerce[key] = COMMERCE_PUBLIC_FIELDS.has(key) ? rawCommerce[key] : COMMERCE_BLANK;
  }
  // Garante os campos públicos mesmo que ausentes no catálogo-fonte.
  if (!('retentionDays' in commerce)) commerce.retentionDays = 90;
  if (!('paymentMethods' in commerce)) commerce.paymentMethods = {whatsapp: false, pix: false, card: false};
  if (!('apiBaseUrl' in commerce)) commerce.apiBaseUrl = '';
  if (!('apiMode' in commerce)) commerce.apiMode = 'required';
  if (!('pixKey' in commerce)) commerce.pixKey = '';
  if (!('paymentLink' in commerce)) commerce.paymentLink = '';

  return {
    publicBuild: true,
    version: source.version ?? 10,
    ...(generatedAt ? {generatedAt} : {}),
    settings,
    products,
    commerce
  };
}
