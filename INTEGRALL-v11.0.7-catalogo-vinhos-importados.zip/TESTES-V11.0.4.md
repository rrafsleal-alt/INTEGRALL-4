# TESTES — INTEGRALL v11.0.4

## Ambiente

- SO: Debian GNU/Linux 12 (bookworm), container Linux x64.
- Runtime: Node.js **v22.22.3**, npm **10.9.8**.
- Navegador de teste E2E/visual: **Chromium 149.0.7827.0** (headless), automatizado via Puppeteer.
- Gerenciador de pacotes: npm (lockfile `package-lock.json` preservado).
- Servidor em execução durante os testes: `node server.js` (persistência em modo "local", sem PostgreSQL/Mercado Pago configurados).

## Comandos executados

```bash
npm ci
npm run check            # verificação de sintaxe (48 arquivos JS)
npm test                 # node --test tests/*.test.js
npm run security:scan    # scanner estático de segurança
npm run audit            # auditoria de catálogo/assets
npm run verify:v11.0.4   # verificações estáticas da entrega
npm run test:v11.0.4     # testes estáticos v11.0.4
npm run build            # check + audit
npm run verify           # check + testes + security + audit
node scripts/check-default-admin.mjs   # valida a senha padrão (e-mail em branco)
```

## Resultados de build/qualidade

| Etapa | Resultado |
|---|---|
| `npm ci` (instalação limpa) | **APROVADO** (express, pg, mercadopago instalados pelo lockfile) |
| `npm run check` (sintaxe) | **APROVADO** — 48 arquivos JS verificados |
| `npm test` (unitários/integração) | **APROVADO** — 103 testes, 103 passaram, 0 falharam |
| `npm run test:v11.0.4` | **APROVADO** — 4/4 testes estáticos |
| `npm run security:scan` | **APROVADO** — 33 arquivos inspecionados; 0 falha (2 avisos informativos sobre TLS `require`, pré-existentes) |
| `npm run audit` | **APROVADO** — 5 produtos, assets referenciados presentes, 19 arquivos públicos de texto |
| `npm run build` | **APROVADO** |
| `npm run verify:v11.0.4` | **APROVADO** — 9/9 verificações |
| `check-default-admin` | **APROVADO** — senha padrão valida com e-mail em branco |
| Servidor de produção (`node server.js`) | **APROVADO** — loja e `/admin` funcionais, sem 404/5xx |

## Autenticação (senha)

Testes de servidor (API real, `POST /api/admin/session/login`):

| Senha informada | Resultado |
|---|---|
| (campo vazio) | Recusado |
| Senha incorreta (`wrongpass99`) | Recusado — `E-mail ou senha inválidos.` |
| `159213rafs` (minúsculas) | Recusado |
| `159213RAFS` (maiúsculas) | Recusado |
| `159213Raf` (parcial) | Recusado |
| senha correta com espaços nas bordas | Recusado |
| **senha padrão correta** | **Autorizado** (conta `admin@integrall.local`, role `admin`) |

Testes E2E no painel `/admin` (Chromium):

| ID | Cenário | Status |
|---|---|---|
| AUTH-001 | Campo vazio | **APROVADO** (recusado com mensagem) |
| AUTH-002 | Senha incorreta | **APROVADO** (recusado) |
| AUTH-004 | `159213rafs` (minúsculas) | **APROVADO** (recusado — ver `admin-senha-incorreta-recusada.png`) |
| AUTH-005 | `159213RAFS` | **APROVADO** (recusado, teste de API) |
| AUTH-006 | senha padrão correta | **APROVADO** (painel exibido — `admin-login-correto-painel.png`) |
| AUTH-007 | Enter / clique no botão | **APROVADO** (ambos logam) |
| AUTH-008 | Recarregar após login | **APROVADO** (sessão estável — `admin-painel-apos-reload.png`) |
| AUTH-009 | Acesso direto a rota protegida | **APROVADO** (`/api/admin/products` sem cookie → 401; com cookie → 200) |
| AUTH-010 | Logout | **APROVADO** (`admin-logout-concluido.png`; cookie expirado) |
| AUTH-011 | Voltar/recarregar após logout | **APROVADO** (painel não reaparece) |
| AUTH-012 | Storage antigo/corrompido | **APROVADO** (loja usa catálogo embutido se o remoto falhar; admin sem cookie mostra login) |
| AUTH-014 | Sessão entre reinícios do servidor (dev) | **APROVADO** (segredo estável em desenvolvimento; produção exige segredo próprio) |

## Produto e layout (detalhes abaixo)

Medido via E2E em 18 larguras. Em todas: `#productDetails` com `position: static`, sem overlay, sem `body.lock`, info **abaixo** da galeria, sem rolagem horizontal e sem conteúdo cortado.

| ID | Cenário | Status |
|---|---|---|
| PROD-001 | Abrir produto — detalhes no fluxo | **APROVADO** |
| PROD-002 | 320 px | **APROVADO** |
| PROD-003 | 768 px | **APROVADO** |
| PROD-004 | 1440 px | **APROVADO** (`produto-detalhes-abaixo-1440*.png`) |
| PROD-005 | 1920 px | **APROVADO** (`produto-detalhes-abaixo-1920.png`) |
| PROD-006 | Trocar de produto (relacionado/herói) | **APROVADO** (nome/preço/variantes atualizam — vinho ↔ vinho verde) |
| PROD-007 | Fechar produto (botão X / Esc) | **APROVADO** (seção oculta) |
| PROD-008 | Reabrir produto | **APROVADO** (quantidade volta para 1, sem resíduos) |
| PROD-009 | Alterar variação (300ml↔1L) | **APROVADO** (preço R$ 11,50 ↔ R$ 23,90) |
| PROD-010 | Tamanho/quantidade | **APROVADO** (limites respeitados) |
| PROD-011 | Adicionar à sacola | **APROVADO** (drawer abre com 1 item) |
| PROD-014/015 | Produto sem imagem / sem variação | **NÃO APLICÁVEL** (todos os 5 produtos têm imagem; há produtos sem variação e renderizam normalmente) |
| PROD-017 | Reload com `#product=` | **APROVADO** (painel reabre) |
| PROD-020 | Ordem do DOM | **APROVADO** (galeria antes de info; seção antes do rodapé) |

## Responsividade (18 larguras)

| Largura (px) | Sem rolagem horizontal | Detalhes abaixo | Sem corte | Status |
|---|---|---|---|---|
| 280 | ✅ | ✅ | ✅ | **APROVADO** |
| 320 | ✅ | ✅ | ✅ | **APROVADO** |
| 360 | ✅ | ✅ | ✅ | **APROVADO** |
| 375 | ✅ | ✅ | ✅ | **APROVADO** |
| 390 | ✅ | ✅ | ✅ | **APROVADO** |
| 412 | ✅ | ✅ | ✅ | **APROVADO** |
| 430 | ✅ | ✅ | ✅ | **APROVADO** |
| 480 | ✅ | ✅ | ✅ | **APROVADO** |
| 600 | ✅ | ✅ | ✅ | **APROVADO** |
| 768 | ✅ | ✅ | ✅ | **APROVADO** |
| 820 | ✅ | ✅ | ✅ | **APROVADO** |
| 1024 | ✅ | ✅ | ✅ | **APROVADO** |
| 1280 | ✅ | ✅ | ✅ | **APROVADO** |
| 1366 | ✅ | ✅ | ✅ | **APROVADO** |
| 1440 | ✅ | ✅ | ✅ | **APROVADO** |
| 1600 | ✅ | ✅ | ✅ | **APROVADO** |
| 1920 | ✅ | ✅ | ✅ | **APROVADO** |
| 2560 | ✅ | ✅ | ✅ (conteúdo centralizado em 1240 px) | **APROVADO** |

## Regressão funcional

| Cenário | Status |
|---|---|
| Navegação entre páginas (vitrine/vinhos/cafés/sucos/petit-four) | **APROVADO** (cards corretos por departamento) |
| Busca/filtros/ordenação renderizam | **APROVADO** |
| Sacola (adicionar, abrir drawer, fechar por overlay) | **APROVADO** |
| Modal legal (Privacidade) abre e fecha com Esc | **APROVADO** |
| Rota desconhecida retorna 404 | **APROVADO** |
| Requisições 4xx/5xx na loja e no admin | **Nenhuma** (0 falhas de rede) |
| Erros JavaScript de página (loja e admin) | **Nenhum** (execuções repetidas limpas) |
| Age gate | **APROVADO** |

## Testes não executados / limitações

- **Firefox e Safari/WebKit:** **NÃO EXECUTADOS** — não há binário disponível nem rede para instalá-los neste ambiente. Risco residual baixo: usou-se apenas Grid/Flexbox/`aspect-ratio`/`dvh`/`overflow-x: clip` (com fallback `overflow-x:hidden`). Recomenda-se confirmar visualmente nesses navegadores antes do deploy.
- **Zoom 125%/150%/200% e texto ampliado:** **NÃO EXECUTADO** de forma automatizada; o layout é fluido (unidades relativas, sem larguras fixas do bloco), mas deve ser conferido manualmente.
- **Upload de mídia / edição e persistência de produto no painel:** o fluxo de telas foi exercitado (painel carrega 10 produtos, editor visual com prévia), mas o upload de arquivo e o salvamento em banco não foram testados de ponta a ponta por exigirem configuração de persistência/credenciais.
- **Mercado Pago / Correios / Jadlog / SMTP:** **NÃO APLICÁVEL** sem credenciais; os módulos e testes unitários existentes continuam passando.
- **Testes E2E cross-browser e em dispositivos reais:** recomendados como etapa pós-deploy.

## Navegadores e resoluções testados

- Chromium 149 (headless) nas larguras: 280, 320, 360, 375, 390, 412, 430, 480, 600, 768, 820, 1024, 1280, 1366, 1440, 1600, 1920 e 2560 px.
- Orientação retrato e paisagem cobertas pelas larguras/alturas usadas.

## Evidências

Capturas em `docs/evidencias-v11.0.4/`: antes (modal flutuante), depois (detalhes abaixo em 320/375/430/768/1024/1280/1440/1920), login recusado, painel após login, painel após reload e logout.

## Checklist final

- [x] Senha padrão correta autentica (sensível a caixa); demais senhas recusadas.
- [x] Sessão estável no reload; logout funcional; rota protegida exige auth.
- [x] Detalhes do produto abaixo da vitrine em 18 larguras; sem coluna/modal lateral.
- [x] Sem rolagem horizontal global; sem conteúdo cortado.
- [x] Troca de produto atualiza tudo; fechar/reabrir limpo.
- [x] Build, testes, segurança e auditoria passam.
- [x] Servidor de produção testado; sem 404/5xx nem erros de console críticos.

---

# Endurecimento pós-entrega (engenharia/segurança)

Ver também `MELHORIAS-ENGENHARIA-SEGURANCA-V11.0.4.md`.

## Novos comandos

```bash
npm run build:data    # gera o #buildData do index.html a partir de data/catalog.json
npm run check:data    # falha se o #buildData estiver defasado em relação ao catálogo
npm run test:e2e      # Playwright (loja + admin) em 3 viewports
# (CI) npx playwright install --with-deps chromium
```

## Resultados adicionais (execução real)

| Etapa | Resultado |
|---|---|
| `npm run check` (sintaxe) | **APROVADO** — 51 arquivos JS (eram 48) |
| `npm test` (unitários/integração) | **APROVADO** — 114 testes, 114 passaram, 0 falharam (eram 103) |
| `npm run security:scan` | **APROVADO** — 35 arquivos (eram 33) |
| `npm run audit` | **APROVADO** — AUDIT OK, 5 produtos, assets presentes |
| `npm run build` (check + build:data + audit) | **APROVADO** |
| `npm run check:data` | **APROVADO** — `#buildData` sincronizado com `data/catalog.json` |
| `npm run verify:v11.0.4` | **APROVADO** — 9/9 |
| `npm run test:e2e` (Playwright, Chromium 149) | **APROVADO** — 30/30 testes (21 de detalhes/produto em 3 viewports + 9 de admin/auth) |
| `npm audit --omit=dev` | **APROVADO** — 0 vulnerabilidades em produção |
| Boot de produção sem `ADMIN_PASSWORD_HASH` | **APROVADO** (recusa com mensagem) |
| Boot de produção com a senha padrão ainda ativa | **APROVADO** (recusa e pede `ADMIN_DEFAULT_LOGIN_ENABLED=false`) |
| Boot de produção com configuração completa | **APROVADO** (sobe normalmente) |
| CSP `frame-ancestors` | **APROVADO** — presente no header HTTP, ausente da `<meta>` (teste automatizado) |

## Cobertura E2E (Playwright)

- `e2e/produto-detalhes.spec.js` (7 testes × 3 viewports = 21): detalhes ABAIXO da
  vitrine; sem overlay/`body.lock`/`#productModal`; coluna única em 1920px
  (`position: static`, painel tão largo quanto o grid); mobile 320px sem corte/scroll
  horizontal; troca de produto atualiza nome/imagem/preço sem resíduo; Escape fecha;
  reload com `#product=` mantém detalhes abertos; adicionar à sacola abre o drawer.
- `e2e/admin-auth.spec.js` (3): senha errada recusada e correta autentica (case-sensitive);
  sessão persiste após reload e logout bloqueia o painel; `GET /api/admin/products`
  responde 401 sem cookie de sessão.

## Novos testes unitários

- `tests/production-config.test.js` (4): recusa da senha padrão em produção, recusa sem
  hash próprio, configuração completa passa, fora de produção não exige.
- `tests/public-snapshot.test.js` (7): remoção de campos de logística/embalagem do
  produto e das variantes, exclusão de produtos ocultos/excluídos, saneamento do
  `commerce`, marca `publicBuild`, ausência de `coupons`, e paridade entre o
  `#buildData` embutido e o snapshot derivado do `data/catalog.json`.

## Limitações (estado)

- E2E executados em **Chromium headless 149** (Linux). Firefox/WebKit não entraram na
  matriz Playwright (matriz enxuta); os recursos exercitados são HTML/CSS/JS padrão.
- Mercado Pago, Correios/Jadlog e SMTP continuam não exercitados ao vivo (sem credenciais).
