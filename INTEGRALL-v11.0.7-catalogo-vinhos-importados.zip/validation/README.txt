VALIDAÇÃO AUTOMÁTICA — INTEGRALL v11.0.4
=========================================

Logs e códigos de saída gerados por execução real (Node v22.22.3, Debian 12).

Arquivo *.exit = código de saída (0 = sucesso).
Arquivo *.log  = saída completa do comando.

- syntax.exit/log          : npm run check        (verificação de sintaxe, 48 arquivos)
- auth-tests.exit/log      : npm test             (suíte node --test; 103 testes)
- default-admin.exit/log   : node scripts/check-default-admin.mjs (senha padrão)
- security.exit/log        : npm run security:scan
- audit.exit/log           : npm run audit
- verify-v11.0.4.exit/log  : npm run verify:v11.0.4 (9 verificações estáticas)

Todos os códigos de saída são 0 (APROVADO).

Evidências visuais (capturas de navegador Chromium 149) em:
  docs/evidencias-v11.0.4/

Relatórios:
  CORRECOES-V11.0.4.md / TESTES-V11.0.4.md / ARQUIVOS-ALTERADOS-V11.0.4.md
