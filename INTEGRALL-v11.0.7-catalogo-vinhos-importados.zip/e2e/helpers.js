// Helpers compartilhados da suíte E2E.
// Seletores verificados contra o DOM real de public/index.html + public/js/store/catalog.js
// (cards `.card` com [data-details]; busca #search; gaveta #cartDrawer;
//  detalhes #productDetails com #modalName/#modalImage/#modalPrice/#modalAdd).

export async function acceptAgeGate(page) {
  const gate = page.locator('#ageGate');
  if (await gate.count()) {
    await page.locator('#ageGateYes').click().catch(() => {});
    await gate.waitFor({state: 'hidden', timeout: 5000}).catch(() => {});
  }
  await page.waitForLoadState('networkidle').catch(() => {});
}

// Abre o primeiro produto da vitrine e espera o painel de detalhes aparecer.
export async function openFirstProduct(page) {
  const card = page.locator('.card [data-details]').first();
  await card.waitFor({state: 'visible', timeout: 10000});
  await card.scrollIntoViewIfNeeded();
  await card.click();
  await page.waitForSelector('#productDetails:not([hidden])', {timeout: 5000});
  await page.waitForFunction(() => {
    const el = document.querySelector('#modalName');
    return el && el.textContent.trim().length > 0;
  }, null, {timeout: 5000});
}

// Lê as métricas de layout do painel de detalhes e do grid.
export async function detailsMetrics(page) {
  return page.evaluate(() => {
    const details = document.querySelector('#productDetails');
    const grid = document.querySelector('#productGrid');
    const r = details.getBoundingClientRect();
    const g = grid.getBoundingClientRect();
    return {
      hidden: details.hidden || getComputedStyle(details).display === 'none',
      position: getComputedStyle(details).position,
      top: r.top, bottom: r.bottom, left: r.left, right: r.right, height: r.height,
      // Largura efetiva da coluna de conteúdo do painel.
      width: r.width,
      gridWidth: g.width,
      // O painel deve ficar ABAIXO do grid (topo do painel >= base do grid).
      belowGrid: r.top >= g.bottom - 4,
      bodyOverflowX: document.documentElement.scrollWidth > document.documentElement.clientWidth + 1
    };
  });
}
