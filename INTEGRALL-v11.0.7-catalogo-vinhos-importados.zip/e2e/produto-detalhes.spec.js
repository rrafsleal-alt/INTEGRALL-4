// E2E — Correção central v11.0.4: os detalhes do produto abrem numa seção do
// fluxo normal do documento, ABAIXO da área principal (vitrine), em coluna
// única, em qualquer largura — sem modal, overlay, ou body.lock.
import {test, expect} from '@playwright/test';
import {acceptAgeGate, openFirstProduct, detailsMetrics} from './helpers.js';

test.describe('Detalhes do produto no fluxo (abaixo da vitrine)', () => {
  test.beforeEach(async ({page}) => {
    await page.goto('/');
    await acceptAgeGate(page);
  });

  test('abre o produto com detalhes ABAIXO, sem modal/overlay/lock e sem scroll horizontal', async ({page}) => {
    await openFirstProduct(page);

    // Os detalhes são uma seção visível no fluxo (não um modal oculto).
    const metrics = await detailsMetrics(page);
    expect(metrics.hidden).toBe(false);
    expect(metrics.belowGrid).toBe(true);          // painel abaixo da vitrine
    expect(metrics.bodyOverflowX).toBe(false);      // sem scroll horizontal

    // NÃO há camada flutuante para os detalhes: overlay fechado e body sem lock.
    const overlayOpen = await page.locator('#overlay.open').count();
    const bodyLocked = await page.evaluate(() => document.body.classList.contains('lock'));
    expect(overlayOpen).toBe(0);
    expect(bodyLocked).toBe(false);

    // O bloco antigo de modal não deve existir/estar ativo.
    expect(await page.locator('#productModal').count()).toBe(0);
  });

  test('não existe coluna lateral em largura desktop larga (1920)', async ({page}) => {
    await page.setViewportSize({width: 1920, height: 1080});
    await openFirstProduct(page);

    const metrics = await detailsMetrics(page);
    // Em desktop largo o painel de detalhes é uma seção de coluna única tão
    // larga quanto (ou mais que) o grid de produtos — NÃO uma coluna lateral
    // estreita. position: static confirma que está no fluxo normal do documento.
    expect(metrics.width).toBeGreaterThanOrEqual(metrics.gridWidth - 1);
    expect(metrics.position).toBe('static');
    expect(metrics.belowGrid).toBe(true);
  });

  test('mobile 320px: detalhes abaixo e sem corte/scroll horizontal', async ({page}) => {
    await page.setViewportSize({width: 320, height: 700});
    await openFirstProduct(page);

    const metrics = await detailsMetrics(page);
    expect(metrics.belowGrid).toBe(true);
    expect(metrics.bodyOverflowX).toBe(false);
    // O painel não é mais largo que a viewport (nada cortado).
    expect(metrics.right).toBeLessThanOrEqual(await page.evaluate(() => document.documentElement.clientWidth) + 1);
  });

  test('trocar de produto atualiza nome, imagem e preço (sem dado residual)', async ({page}) => {
    await openFirstProduct(page);
    const firstName = (await page.locator('#modalName').textContent()).trim();
    const firstImg = await page.locator('#modalImage').getAttribute('src');

    // Abre o segundo produto da vitrine (botão de imagem do 2º card — cada
    // card tem 3 botões [data-details], por isso usamos o .card-image do card).
    const second = page.locator('.card').nth(1).locator('.card-image');
    await second.scrollIntoViewIfNeeded();
    await second.click();
    await page.waitForFunction((prev) => {
      const el = document.querySelector('#modalName');
      return el && el.textContent.trim() && el.textContent.trim() !== prev;
    }, firstName, {timeout: 5000});

    const secondName = (await page.locator('#modalName').textContent()).trim();
    const secondImg = await page.locator('#modalImage').getAttribute('src');
    expect(secondName).not.toBe(firstName);
    expect(secondImg).not.toBe(firstImg);
  });

  test('Escape fecha o bloco de detalhes', async ({page}) => {
    await openFirstProduct(page);
    expect(await page.locator('#productDetails:not([hidden])').count()).toBe(1);

    await page.keyboard.press('Escape');
    await page.waitForSelector('#productDetails', {state: 'hidden', timeout: 5000});
    const metrics = await detailsMetrics(page);
    expect(metrics.hidden).toBe(true);
  });

  test('reload com #product= mantém os detalhes abertos', async ({page}) => {
    await openFirstProduct(page);
    const name = (await page.locator('#modalName').textContent()).trim();
    const url = page.url();
    expect(url).toContain('#product=');

    await page.reload();
    await acceptAgeGate(page);
    await page.waitForSelector('#productDetails:not([hidden])', {timeout: 8000});
    await expect(page.locator('#modalName')).toContainText(name.slice(0, 12));
  });

  test('adicionar à sacola abre a gaveta e incrementa o contador', async ({page}) => {
    await openFirstProduct(page);
    const before = parseInt((await page.locator('#cartCount').textContent()).trim() || '0', 10);

    // Se houver seletor de variante, escolhe a primeira opção.
    const variant = page.locator('#modalVariant option').nth(1);
    if (await variant.count()) await variant.dispatchEvent('change').catch(() => {});

    await page.locator('#modalAdd').click();
    await page.waitForSelector('#cartDrawer.open', {timeout: 5000});
    await expect(page.locator('#cartCount')).not.toHaveText(String(before));
  });
});
