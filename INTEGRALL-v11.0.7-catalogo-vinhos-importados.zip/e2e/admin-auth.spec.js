// E2E — Autenticação do painel administrativo.
// Cobre: senha errada recusada, senha correta autentica, sessão persiste após
// reload, logout encerra a sessão e a API protegida responde 401 sem cookie.
//
// A senha NUNCA é escrita literalmente aqui: é lida da env ADMIN_PASSWORD
// (no ambiente de teste o servidor usa a senha padrão de desenvolvimento via
// config.js; em CI injeta-se uma senha própria por variável de ambiente).
import {test, expect} from '@playwright/test';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '159213Rafs';

test.describe('Acesso administrativo', () => {
  test.beforeEach(async ({page}) => {
    await page.goto('/admin');
    await page.waitForSelector('#loginView', {timeout: 10000});
  });

  test('senha errada é recusada e senha correta autentica', async ({page}) => {
    // --- Senha incorreta ---
    await page.fill('#loginPassword', 'senha-errada-teste');
    await page.click('#loginButton');
    await expect(page.locator('#loginFeedback.bad')).toBeVisible({timeout: 8000});
    // O dashboard permanece oculto e a tela de login visível.
    await expect(page.locator('#dashboard')).toBeHidden();
    await expect(page.locator('#loginView')).toBeVisible();

    // --- Senha correta (case-sensitive) ---
    await page.fill('#loginPassword', ADMIN_PASSWORD);
    await page.click('#loginButton');
    await expect(page.locator('#dashboard')).toBeVisible({timeout: 8000});
    await expect(page.locator('#loginView')).toBeHidden();
    await expect(page.locator('#logoutButton')).toBeVisible();
  });

  test('sessão persiste após reload e logout bloqueia o painel', async ({page}) => {
    await page.fill('#loginPassword', ADMIN_PASSWORD);
    await page.click('#loginButton');
    await expect(page.locator('#dashboard')).toBeVisible({timeout: 8000});

    // Recarrega: a sessão (cookie) mantém o dashboard acessível.
    await page.reload();
    await expect(page.locator('#dashboard')).toBeVisible({timeout: 8000});

    // Logout encerra a sessão.
    await page.click('#logoutButton');
    await expect(page.locator('#loginView')).toBeVisible({timeout: 8000});
    await expect(page.locator('#dashboard')).toBeHidden();
  });

  test('rota de API protegida exige sessão (401 sem cookie)', async ({request}) => {
    const res = await request.get('/api/admin/products');
    expect(res.status()).toBe(401);
  });
});
