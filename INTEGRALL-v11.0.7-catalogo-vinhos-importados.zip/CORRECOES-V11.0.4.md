# CORREÇÕES — INTEGRALL v11.0.4

## 1. Resumo executivo

A versão 11.0.3 foi recebida com dois problemas relatados:

1. A senha da **área de personalização (admin)** não aceitava a credencial padrão esperada.
2. Os **detalhes do produto abriam num modal flutuante (sobreposto)** em vez de aparecerem abaixo da vitrine — inclusive em desktop.

Esta versão (11.0.4) foi auditada, os dois pontos foram corrigidos na causa raiz e um conjunto de problemas adicionais de robustez e responsividade foi tratado, sem remover funcionalidades nem redesenhar a identidade visual.

Resultados verificados por execução real (não apenas análise):

- A senha padrão **autentica com diferenciação de maiúsculas/minúsculas** e qualquer outra senha é recusada (testes de API e E2E).
- Os detalhes do produto agora **fluem no documento, abaixo da vitrine**, em coluna única, em **todas as larguras** (280 a 2560 px), sem overlay, sem travar o scroll e sem painel lateral.
- Build, testes unitários, scanner de segurança, auditoria de catálogo e verificação estática v11.0.4 passam.

## 2. Problemas relatados

- **P0 — Acesso administrativo:** a senha padrão da área de personalização deveria ser exatamente a senha padrão definida para a área de personalização (valor informado em canal seguro ao responsável), sensível a caixa, com sessão estável (reload, navegação, logout).
- **P1 — Layout do produto:** ao abrir/selecionar um produto, todas as informações deveriam aparecer **abaixo** da área do produto, nunca em coluna/modal lateral, em qualquer resolução.

## 3. Problemas adicionais encontrados

Durante a auditoria foram encontrados e corrigidos:

- **P2 — `body { min-width: 320px }` forçava rolagem horizontal em telas de 280–319 px.** Removido e adicionado `overflow-x: clip` na superfície para conter o drawer da sacola transladado para fora da tela.
- **P3 — Segredo de sessão aleatório a cada boot em desenvolvimento.** `ADMIN_SESSION_SECRET` era gerado com `randomBytes` a cada inicialização, o que invalidava todas as sessões ao reiniciar o servidor (sintoma de "logout/loop" após reload em desenvolvimento). Em desenvolvimento agora o segredo é **estável e derivado**; em produção continua **obrigatório** um segredo próprio via variável de ambiente.
- **P3 — Erro intermitente `Cannot read properties of null (reading 'append')` no painel admin.** Causado por carregamentos assíncronos (`Promise.all`) sem tratamento e por `bind()` sem proteções de elemento. Os renderizadores passaram a verificar a existência dos elementos e o carregamento usa `Promise.allSettled`, além de um tratamento global de rejeições não capturadas.
- **P3 — Script `verify-v11.0.4.mjs` continha uma string `eval(` literal** que disparava falso positivo no scanner de segurança. O script foi reescrito com verificações reais e sem execução dinâmica.
- **P2 — O `#productModal` legado era um `<section role="dialog">` flutuante** com `position: fixed`, overlay e `body.lock`, tanto para a loja quanto para as rotas.

## 4. Arquitetura identificada

- **Stack:** Node.js (ESM), Express 5, sem bundler. A "loja" é um site estático servido estaticamente (`public/`) e o painel admin é `public/admin.html` + `public/js/admin.js`.
- **Autenticação:** servidor (`src/auth.js`, `src/config.js`, rotas em `server.js`) com hash **scrypt** (nunca texto puro no código), sessão assinada por **HMAC-SHA256** em cookie **HttpOnly, SameSite=Strict**, token CSRF e rate limiting. O cliente apenas envia e-mail/senha e recebe o cookie.
- **Catálogo:** embed estático em `public/index.html` (`#buildData`) e, quando há backend, `GET /api/catalog`; persistência local em `data/` (modo "local") ou PostgreSQL (produção).
- **Front da loja:** JavaScript vanilla em `public/js/store/*.js` (catálogo, sacola, checkout, frete, idade) e CSS em `public/css/*.css` (com uma camada visual "premium" `premium-v104.*`).
- **Detalhes do produto (antes):** um modal flutuante `#productModal` reutilizado por `public/js/store/catalog.js` via um controlador de "camadas" (`layers`) que também governa o drawer da sacola.

## 5. Causa raiz da senha

A cadeia de autenticação **servidora já estava correta** no código recebido:

- `src/config.js` guarda apenas um hash **scrypt** da senha padrão (`DEFAULT_ADMIN_PASSWORD_HASH`).
- `src/auth.js` compara com `verifyPassword` (scrypt + `timingSafeEqual`) e exige o e-mail padrão quando o campo fica em branco.
- O login cria um cookie HMAC HttpOnly; o logout limpa o cookie; rotas `/api/admin/*` são protegidas por `requireSession/requirePermission` com CSRF.

Confirmou-se por execução real que o hash corresponde exatamente à senha padrão esperada e que variações de caixa (`159213rafs`, `159213RAFS`), senha parcial, vazia e com espaços são recusadas. O que comprometia a **estabilidade da sessão** em desenvolvimento era o segredo de sessão aleatório a cada boot (corrigido — ver §7). Não existe fallback de senha antiga: quando um `ADMIN_PASSWORD_HASH` próprio é configurado, o hash padrão deixa de ser aceito (`ADMIN_DEFAULT_LOGIN_ENABLED=false`).

## 6. Causa raiz do layout lateral

Os detalhes do produto eram um **modal flutuante** (`public/index.html` → `<section class="modal" id="productModal">`), posicionado com `position: fixed; left:50%; top:50%`, sobre um overlay (`#overlay.open`) e com o scroll da página travado (`body.lock`). O controlador `layers.open()` adicionava `.open`, overlay e prisão de foco. Por isso, em qualquer largura, o conteúdo aparecia **sobreposto** e não no fluxo do documento.

## 7. Correção aplicada na autenticação

- `src/config.js`: segredo de sessão **estável em desenvolvimento** (HMAC derivado de sal fixo de dev) e **efêmero + obrigatório em produção** (o `assertProductionConfig()` continua exigindo `ADMIN_SESSION_SECRET` próprio). A flag `adminUsesBuiltInSessionSecret` só sinaliza "temporário" em produção.
- `public/js/admin.js`: proteções de nulidade nos renderizadores (`renderOrders`, `renderCustomers`, `renderMetrics`, `bind`) e troca de `Promise.all` por `Promise.allSettled` no carregamento, além de tratamento global de rejeições — eliminando o erro intermitente de console e deixando o painel resiliente durante reload/logout.
- A senha padrão continua sendo apenas o hash scrypt em `src/config.js`; **nenhuma** senha em texto puro é enviada ao bundle público (verificado por script e por teste).

## 8. Correção aplicada no produto

- `public/index.html`: o bloco de detalhes foi **movido no DOM** de um modal no fim do `<body>` para uma seção **no fluxo**, dentro da área do catálogo, logo abaixo da grade de produtos e antes do rodapé. Tornou-se `<section class="product-details" id="productDetails" hidden aria-labelledby="modalName">`. Todos os `id` dos controles (`modalImage`, `modalName`, `modalVariant`, `modalQty`, `modalAdd`, etc.) foram **preservados**, então a lógica existente continua funcionando. O `#productModal` legado foi removido.
- `public/js/store/catalog.js`:
  - Separou-se o controle do **drawer da sacola** (`layers`, com overlay/lock/foco) do **painel de detalhes** (novo `productPanel`), que apenas revela/oculta a seção, rola suavemente até ela (respeitando `prefers-reduced-motion`) e move o foco para o título — sem overlay, sem travar scroll, sem prender foco.
  - `openProduct` passou a abrir `productPanel`; adicionou-se `closeProduct`; ao **trocar de produto** os estados são re-renderizados (nome, imagem, preço, variantes, quantidade volta para 1); ao **trocar de página** o painel fecha; o `popstate` e o hash `#product=` continuam funcionando.
  - O botão de fechar do bloco é `.close-product` (o `.close-ui`/overlay ficou só para o drawer).
- `public/css/store.css`:
  - `.product-details` é `position: static`, largura fluida (`min(100% - 56px, 1240px)`), uma coluna, sem `fixed/absolute/sticky`.
  - `.product-modal-grid` (galeria + info) em **coluna única** com `grid-template-columns: 1fr`; a galeria fica acima e as informações abaixo, centralizadas com largura máximas coerentes.
  - Removido `body{min-width:320px}` e adicionado `overflow-x: clip` em `.catalog-surface` (com `overflow-x:hidden` de segurança no body) para eliminar rolagem horizontal até em 280 px.
  - Ajustes responsivos em `@media (max-width:900px)` e `(max-width:620px)`.

## 9. Arquivos alterados

- `public/index.html` — bloco de detalhes movido/transformado em seção in-flow.
- `public/css/store.css` — estilos da seção in-flow e correções de rolagem horizontal.
- `public/js/store/catalog.js` — painel de detalhes no fluxo; drawer separado; fechamento/troca de produto.
- `public/js/admin.js` — robustez (nulidade, `allSettled`, tratamento de erros).
- `src/config.js` — segredo de sessão estável em dev; obrigatório em produção.
- `scripts/verify-v11.0.4.mjs` — verificações reais, sem `eval`.
- `tests/v11.0.4-static.test.mjs` — testes estáticos do bloco in-flow (já existia; continua verde).
- Documentação e evidências adicionadas (ver `ARQUIVOS-ALTERADOS-V11.0.4.md`).

## 10. Funções alteradas

- `src/config.js`: montagem de `DEFAULT_ADMIN_SESSION_SECRET` e `adminUsesBuiltInSessionSecret`.
- `public/js/store/catalog.js`: `layers` (agora só drawer), novo `productPanel`/`prefersReducedMotion`, `openProduct`, nova `closeProduct`, `applyPage`, handlers de `popstate`/overlay/Escape/fechar.
- `public/js/admin.js`: `renderOrders`, `renderCustomers`, `renderMetrics` (+`setMetric`), `loadAll` (`allSettled`), `bind`, `init` e tratamento global de rejeição.

## 11. Dependências alteradas

Nenhuma dependência de produção foi adicionada, removida ou atualizada. Não houve mudança de `package-lock.json`.

## 12. Migrações

Nenhuma migração de banco de dados foi necessária. Não houve mudança no formato dos dados do catálogo/pedidos. O estado local antigo do navegador (carrinho/checkout em `localStorage`/`sessionStorage`) continua compatível; a chave de confirmação de idade (`integrall_age_verified_v1`) não foi alterada.

## 13. Impactos

- A experiência de detalhes do produto deixa de ser um modal e passa a ser uma seção da página: melhora leitura, acessibilidade e uso em mobile/desktop.
- O drawer da sacola, os modais legais e o restante da loja permanecem inalterados.
- Em desenvolvimento a sessão admin sobrevive a reinícios do servidor; em produção nada muda (segredo próprio continua obrigatório).

## 14. Riscos residuais

- É uma aplicação com backend real; a senha padrão ainda é habilitada por padrão para o primeiro acesso. **Em produção** recomenda-se definir `ADMIN_PASSWORD_HASH` (via `npm run admin:hash`), `ADMIN_SESSION_SECRET`, `ADMIN_EMAIL` e `ADMIN_DEFAULT_LOGIN_ENABLED=false`.
- O segredo de desenvolvimento é fixo apenas para conveniência local e nunca é usado quando `NODE_ENV=production`.
- O `overflow-x: clip` é suportado em navegadores modernos; há `overflow-x: hidden` no `body` como rede de segurança.

## 15. Como executar

```bash
npm ci
cp .env.example .env   # ajuste PORT se desejar (padrão 3000)
npm start              # ou: npm run dev (com --watch)
# Loja:    http://localhost:3000/
# Admin:   http://localhost:3000/admin
```

## 16. Como gerar build

Este projeto não usa bundler: o "build" é a verificação de sintaxe + auditoria de catálogo:

```bash
npm run build    # = npm run check && npm run audit
npm run verify   # check + testes + security:scan + audit
```

## 17. Como acessar a área administrativa

Abra `/admin`, deixe o **e-mail em branco** e informe a senha padrão. (A senha não é escrita nesta documentação; consulte o responsável ou o arquivo de distribuição.) O login diferencia maiúsculas/minúsculas. O atalho alternativo é clicar 3x sobre a marca no rodapé da loja.

## 18. Como alterar a senha futuramente

```bash
npm run admin:hash     # informe a nova senha; copia o ADMIN_PASSWORD_HASH=...
```
Defina no ambiente: `ADMIN_EMAIL`, `ADMIN_PASSWORD_HASH` (hash gerado), `ADMIN_SESSION_SECRET` (segredo próprio ≥32 caracteres) e, após validar, `ADMIN_DEFAULT_LOGIN_ENABLED=false`. Nunca armazene a senha em texto puro.

## 19. Como validar o posicionamento dos detalhes

Abra um produto e confirme que: imagem/galeria → nome → preço → variantes → quantidade → personalização → entrega → descrição/especificações → ações aparecem **na página, abaixo da vitrine**, em coluna única, sem sobreposição e sem rolagem horizontal — em 320, 375, 430, 768, 1024, 1280, 1440 e 1920 px. Verifique também com `npm run verify:v11.0.4`.

## 20. Limitações reais

- Os testes E2E/visuais foram executados em **Chromium headless 149** neste ambiente Linux. Firefox e Safari/WebKit não puderam ser executados aqui (sem binário/rede para instalá-los); porém só foram usados CSS/JS padrão (Grid, Flexbox, `aspect-ratio`, `dvh`, `overflow-x: clip`) amplamente suportados.
- O Mercado Pago, Correios/Jadlog e SMTP dependem de credenciais e não foram exercitados ao vivo (estão desligados sem configuração).
- Não há service worker/PWA registrado na loja.
