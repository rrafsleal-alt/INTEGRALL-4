import {defineConfig, devices} from '@playwright/test';

// Servidor de teste: sobe a aplicação em uma porta dedicada para os E2E.
const PORT = Number(process.env.E2E_PORT || 4173);
const BASE_URL = process.env.E2E_BASE_URL || `http://127.0.0.1:${PORT}`;

export default defineConfig({
  testDir: './e2e',
  timeout: 30_000,
  fullyParallel: false,
  workers: 1,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? [['list'], ['html', {open: 'never'}]] : 'line',
  use: {
    baseURL: BASE_URL,
    trace: 'on-first-retry',
    // Permite apontar para um Chromium já instalado (em ambientes sem acesso à
    // CDN de download do Playwright). Em CI normal isso fica indefinido e o
    // Playwright usa o navegador baixado por `npx playwright install`.
    ...(process.env.E2E_CHROMIUM_PATH ? {launchOptions: {executablePath: process.env.E2E_CHROMIUM_PATH}} : {})
  },
  projects: [
    {name: 'mobile', use: {...devices['Pixel 5']}},
    {name: 'tablet', use: {...devices['iPad']}},
    {name: 'desktop', use: {...devices['Desktop Chrome']}}
  ],
  webServer: process.env.E2E_BASE_URL
    ? undefined
    : {
        command: `PORT=${PORT} node server.js`,
        url: `${BASE_URL}/api/health`,
        reuseExistingServer: !process.env.CI,
        timeout: 30_000
      }
});
