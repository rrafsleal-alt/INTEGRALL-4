// Testes do snapshot público estático (#buildData) derivado do catálogo-fonte.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, join} from 'node:path';
import {buildPublicSnapshot} from '../src/public-snapshot.js';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

const SAMPLE_CATALOG = {
  version: 10,
  settings: {brand: 'INTEGRALL', catalogTitle: 'Teste'},
  products: [
    {
      id: 'p1', name: 'Vinho Tinto', price: 2699, available: true, hidden: false,
      description: 'Tinto seco', weightGrams: 1200, lengthCm: 30, widthCm: 8, heightCm: 8,
      boxes: [{units: 6, weightGrams: 7200, lengthCm: 30, widthCm: 26, heightCm: 18}],
      minPerOrder: 2, maxPerOrder: 10,
      variants: [{id: 'v1', name: '750ml', price: 2699, stock: 48, weightGrams: 1200, position: 1}]
    },
    {id: 'p2', name: 'Oculto', price: 1000, hidden: true},
    {id: 'p3', name: 'Excluído', price: 1000, deletedAt: '2026-01-01T00:00:00.000Z'}
  ],
  commerce: {
    businessName: 'INTEGRALL | Boutique Gourmet', privacyText: 'texto legal longo',
    termsText: 'termos', returnsText: 'trocas', supportEmail: 'a@b.c', taxId: '000',
    retentionDays: 90, pixKey: 'chave-pix', paymentMethods: {whatsapp: false, pix: true, card: false},
    apiBaseUrl: 'https://api', apiMode: 'optional', lastUpdated: '2026-08-12T00:00:00.000Z'
  }
};

test('snapshot remove dimensões/peso/embalagem/pedido-mínimo do produto', () => {
  const snap = buildPublicSnapshot(SAMPLE_CATALOG);
  const p = snap.products.find(x => x.id === 'p1');
  for (const field of ['lengthCm', 'widthCm', 'heightCm', 'boxes', 'weightGrams', 'minPerOrder']) {
    assert.equal(field in p, false, `campo ${field} deveria ter sido removido`);
  }
  // Mantém campos de vitrine.
  assert.equal(p.name, 'Vinho Tinto');
  assert.equal(p.maxPerOrder, 10);
  assert.equal(p.description, 'Tinto seco');
});

test('snapshot remove peso (weightGrams) das variantes', () => {
  const snap = buildPublicSnapshot(SAMPLE_CATALOG);
  const variant = snap.products.find(x => x.id === 'p1').variants[0];
  assert.equal('weightGrams' in variant, false);
  assert.equal(variant.id, 'v1');
  assert.equal(variant.price, 2699);
});

test('snapshot exclui produtos ocultos e excluídos', () => {
  const snap = buildPublicSnapshot(SAMPLE_CATALOG);
  const ids = snap.products.map(p => p.id);
  assert.deepEqual(ids, ['p1']);
});

test('snapshot zera textos/configurações sensíveis do commerce, mantendo os campos públicos', () => {
  const snap = buildPublicSnapshot(SAMPLE_CATALOG);
  assert.equal(snap.commerce.businessName, '');
  assert.equal(snap.commerce.privacyText, '');
  assert.equal(snap.commerce.termsText, '');
  assert.equal(snap.commerce.returnsText, '');
  assert.equal(snap.commerce.supportEmail, '');
  assert.equal(snap.commerce.taxId, '');
  // Campos públicos permanecem.
  assert.equal(snap.commerce.retentionDays, 90);
  assert.equal(snap.commerce.pixKey, 'chave-pix');
  assert.deepEqual(snap.commerce.paymentMethods, {whatsapp: false, pix: true, card: false});
  assert.equal(snap.commerce.apiMode, 'optional');
});

test('snapshot marca publicBuild e preserva versão/settings', () => {
  const snap = buildPublicSnapshot(SAMPLE_CATALOG, {generatedAt: '2026-08-31T12:00:00-03:00'});
  assert.equal(snap.publicBuild, true);
  assert.equal(snap.version, 10);
  assert.equal(snap.settings.brand, 'INTEGRALL');
  assert.equal(snap.generatedAt, '2026-08-31T12:00:00-03:00');
});

test('snapshot nunca contém coupons', () => {
  const snap = buildPublicSnapshot({...SAMPLE_CATALOG, coupons: [{code: 'PROMO'}]});
  assert.equal('coupons' in snap, false);
});

test('o #buildData embutido no index.html é exatamente o snapshot derivado do catálogo-fonte', () => {
  // Esta é a garantia anti-divergência: o HTML não pode mais ficar defasado
  // manualmente em relação ao data/catalog.json.
  const catalog = JSON.parse(readFileSync(join(root, 'data', 'catalog.json'), 'utf8'));
  const html = readFileSync(join(root, 'public', 'index.html'), 'utf8');
  const match = html.match(/<script id="buildData" type="application\/json">([\s\S]*?)<\/script>/);
  assert.ok(match, '#buildData deve existir no index.html');
  const embedded = JSON.parse(match[1]);

  const generated = buildPublicSnapshot(catalog);
  // Ignora o timestamp (dependente do instante do build).
  const {generatedAt: _e, ...embeddedData} = embedded;
  assert.deepEqual(embeddedData, generated);
  assert.equal(embedded.publicBuild, true);
});
