import test from 'node:test';
import assert from 'node:assert/strict';

// assertProductionConfig só deve disparar em NODE_ENV=production. Em produção a
// senha padrão de primeiro acesso precisa estar desligada e um hash próprio
// configurado; caso contrário o servidor deve falhar no boot.
const PROD_ENV = {
  NODE_ENV: 'production',
  DATABASE_URL: 'postgres://u:p@localhost:5432/db',
  DATABASE_SSL_MODE: 'require',
  PUBLIC_URL: 'https://loja.example.com',
  ADMIN_EMAIL: 'responsavel@example.com',
  ADMIN_PASSWORD_HASH: 'scrypt$32768$8$1$kl5XPhtAyxTz2pU0MBydlg$3LcI-tTNygXiOaULs-bPEXuEyYF4X5DTuuWfVv8oX6H1mXF1e_E7tK7_aO7CIvskjY_tKnA3LDw_3GRzbBa-ng',
  ADMIN_SESSION_SECRET: 's'.repeat(64),
  ADMIN_ROLE: 'admin'
};

const KEYS = [...Object.keys(PROD_ENV), 'ADMIN_DEFAULT_LOGIN_ENABLED'];

async function loadAssert() {
  const mod = await import(`../src/config.js?prod-assert=${Date.now()}-${Math.random()}`);
  return mod.assertProductionConfig;
}

test('produção com senha padrão ativa deve ser recusada no boot', async () => {
  const previous = new Map(KEYS.map(k => [k, process.env[k]]));
  try {
    for (const [k, v] of Object.entries(PROD_ENV)) process.env[k] = v;
    process.env.ADMIN_DEFAULT_LOGIN_ENABLED = 'true'; // inseguro
    const assertProductionConfig = await loadAssert();
    assert.throws(() => assertProductionConfig(), /ADMIN_DEFAULT_LOGIN_ENABLED=false/);
  } finally {
    for (const [k, v] of previous) { if (v == null) delete process.env[k]; else process.env[k] = v; }
  }
});

test('produção sem ADMIN_PASSWORD_HASH próprio deve ser recusada', async () => {
  const previous = new Map(KEYS.map(k => [k, process.env[k]]));
  try {
    for (const [k, v] of Object.entries(PROD_ENV)) process.env[k] = v;
    delete process.env.ADMIN_PASSWORD_HASH;
    process.env.ADMIN_DEFAULT_LOGIN_ENABLED = 'false';
    const assertProductionConfig = await loadAssert();
    assert.throws(() => assertProductionConfig(), /ADMIN_PASSWORD_HASH/);
  } finally {
    for (const [k, v] of previous) { if (v == null) delete process.env[k]; else process.env[k] = v; }
  }
});

test('produção configurada corretamente (hash próprio + login padrão desligado) passa', async () => {
  const previous = new Map(KEYS.map(k => [k, process.env[k]]));
  try {
    for (const [k, v] of Object.entries(PROD_ENV)) process.env[k] = v;
    process.env.ADMIN_DEFAULT_LOGIN_ENABLED = 'false';
    const assertProductionConfig = await loadAssert();
    assert.doesNotThrow(() => assertProductionConfig());
  } finally {
    for (const [k, v] of previous) { if (v == null) delete process.env[k]; else process.env[k] = v; }
  }
});

test('fora de produção a função não exige nada', async () => {
  const previous = new Map(KEYS.map(k => [k, process.env[k]]));
  try {
    for (const k of KEYS) delete process.env[k];
    process.env.NODE_ENV = 'development';
    const assertProductionConfig = await loadAssert();
    assert.doesNotThrow(() => assertProductionConfig());
  } finally {
    for (const [k, v] of previous) { if (v == null) delete process.env[k]; else process.env[k] = v; }
  }
});
